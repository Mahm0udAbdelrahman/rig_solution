@extends('layouts.app')

@section('header-bottom')
<style>
    .staff-performance-grid {
        display: grid;
        grid-template-columns: repeat(12, minmax(0, 1fr));
        gap: 16px;
    }
    .staff-performance-card {
        border: 1px solid #e8ecf5;
        border-radius: 14px;
        background: #fff;
        box-shadow: 0 8px 24px rgba(22, 34, 51, 0.06);
    }
    .staff-performance-head {
        padding: 16px 18px;
        border-bottom: 1px solid #eef2fb;
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 10px;
        flex-wrap: wrap;
    }
    .staff-performance-body {
        padding: 18px;
    }
    .staff-performance-title {
        margin: 0;
        font-size: 1.05rem;
        font-weight: 700;
        color: #24314d;
    }
    .staff-performance-subtitle {
        margin: 4px 0 0;
        color: #7a88a1;
        font-size: .84rem;
    }
    .staff-hero {
        grid-column: span 12;
        background: linear-gradient(135deg, #ffffff 0%, #f5f8ff 55%, #fdfcff 100%);
        border-color: #dfe7ff;
    }
    .staff-toolbar {
        display: flex;
        justify-content: space-between;
        align-items: flex-end;
        gap: 12px;
        flex-wrap: wrap;
    }
    .scope-switch {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
    }
    .scope-btn {
        border: 1px solid #dce4fa;
        background: #f8faff;
        color: #44527a;
        border-radius: 999px;
        padding: 5px 10px;
        font-size: .76rem;
        font-weight: 700;
        text-decoration: none !important;
    }
    .scope-btn.is-active {
        background: #5a46d6;
        border-color: #5a46d6;
        color: #fff;
    }
    .staff-filter-form {
        display: flex;
        gap: 12px;
        flex-wrap: wrap;
        align-items: flex-end;
    }
    .staff-filter-form label {
        display: block;
        margin-bottom: 4px;
        color: #71809d;
        font-size: .78rem;
        font-weight: 700;
    }
    .staff-summary-grid {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 12px;
        margin-top: 16px;
    }
    .staff-summary-card {
        border: 1px solid #e5ebfb;
        border-radius: 12px;
        background: #fbfcff;
        padding: 14px;
    }
    .staff-summary-label {
        display: block;
        color: #7382a0;
        font-size: .76rem;
        text-transform: uppercase;
        letter-spacing: .03em;
        font-weight: 700;
    }
    .staff-summary-value {
        display: block;
        margin-top: 6px;
        color: #26345a;
        font-size: 1.45rem;
        font-weight: 800;
        line-height: 1.05;
    }
    .staff-summary-hint {
        display: block;
        margin-top: 5px;
        color: #8390a8;
        font-size: .76rem;
    }
    .span-12 { grid-column: span 12; }
    .span-8 { grid-column: span 8; }
    .span-4 { grid-column: span 4; }
    .staff-chip-list {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
    }
    .staff-chip {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        border: 1px solid #e7edf9;
        border-radius: 999px;
        background: #fbfcff;
        padding: 6px 10px;
        font-size: .82rem;
        color: #32415f;
        font-weight: 600;
    }
    .snapshot-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 10px;
    }
    .snapshot-item {
        border: 1px solid #ebf0ff;
        border-radius: 10px;
        background: #fbfcff;
        padding: 10px 12px;
    }
    .snapshot-label {
        display: block;
        color: #7a88a1;
        font-size: .75rem;
        font-weight: 700;
    }
    .snapshot-value {
        display: block;
        margin-top: 5px;
        color: #2d3959;
        font-size: .92rem;
        font-weight: 700;
    }
    @media (max-width: 1199.98px) {
        .span-8, .span-4, .staff-summary-grid {
            grid-column: span 12;
        }
        .staff-summary-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
        }
    }
    @media (max-width: 767.98px) {
        .staff-summary-grid,
        .snapshot-grid {
            grid-template-columns: 1fr;
        }
    }
</style>
@endsection

@section('content')
<section class="users-list-wrapper">
    <div class="users-list">
        <div class="staff-performance-grid">
            <div class="staff-performance-card staff-hero">
                <div class="staff-performance-head">
                    <div>
                        <h4 class="staff-performance-title">Staff Performance</h4>
                        <p class="staff-performance-subtitle">Super-admin analytics for employee activity across JCF creation and inspection report production.</p>
                    </div>
                    <span class="badge badge-primary">{{ ($jcf_count ?? 0) + ($report_count ?? 0) }} total activity</span>
                </div>
                <div class="staff-performance-body">
                    <div class="staff-toolbar">
                        <div class="scope-switch">
                            @foreach($window_options as $windowKey => $windowMeta)
                                <a href="{{ route('organization.staffPerformance', ['window' => $windowKey, 'user_id' => $selected_user_id, 'section' => $selected_section]) }}" class="scope-btn {{ $selected_window === $windowKey ? 'is-active' : '' }}">{{ $windowMeta['label'] }}</a>
                            @endforeach
                        </div>
                        <form method="GET" class="staff-filter-form">
                            <input type="hidden" name="window" value="{{ $selected_window }}">
                            <div>
                                <label for="staff-performance-user-id">Employee</label>
                                <select id="staff-performance-user-id" class="form-control form-control-sm" name="user_id" onchange="this.form.submit()">
                                    <option value="0">All Employees</option>
                                    @foreach($creators as $creator)
                                        <option value="{{ $creator['id'] }}" @selected($selected_user_id === (int) $creator['id'])>{{ $creator['name'] }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div>
                                <label for="staff-performance-section">Inspection Section</label>
                                <select id="staff-performance-section" class="form-control form-control-sm" name="section" onchange="this.form.submit()">
                                    <option value="all">All Sections</option>
                                    @foreach($section_options as $sectionOption)
                                        <option value="{{ $sectionOption['key'] }}" @selected($selected_section === $sectionOption['key'])>{{ $sectionOption['label'] }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </form>
                    </div>

                    <div class="staff-summary-grid">
                        <div class="staff-summary-card">
                            <span class="staff-summary-label">JCFs In Window</span>
                            <span class="staff-summary-value">{{ $jcf_count }}</span>
                            <span class="staff-summary-hint">New job control forms created in the selected period.</span>
                        </div>
                        <div class="staff-summary-card">
                            <span class="staff-summary-label">Inspection Reports</span>
                            <span class="staff-summary-value">{{ $report_count }}</span>
                            <span class="staff-summary-hint">Non-duplicated inspection reports created in the selected period.</span>
                        </div>
                        <div class="staff-summary-card">
                            <span class="staff-summary-label">Top Employee</span>
                            <span class="staff-summary-value">{{ $top_employee['name'] ?? '-' }}</span>
                            <span class="staff-summary-hint">{{ $top_employee['total_activity'] ?? 0 }} total activity</span>
                        </div>
                        <div class="staff-summary-card">
                            <span class="staff-summary-label">Top Inspection Section</span>
                            <span class="staff-summary-value">{{ $top_section['label'] ?? '-' }}</span>
                            <span class="staff-summary-hint">{{ $top_section['count'] ?? 0 }} report(s)</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="staff-performance-card span-8">
                <div class="staff-performance-head">
                    <div>
                        <h4 class="staff-performance-title">Top Employees</h4>
                        <p class="staff-performance-subtitle">Combined employee activity across JCFs and inspection reports.</p>
                    </div>
                </div>
                <div class="staff-performance-body">
                    <div class="table-responsive">
                        <table class="table table-striped mb-0">
                            <thead>
                                <tr>
                                    <th>Employee</th>
                                    <th>JCFs</th>
                                    <th>Reports</th>
                                    <th>Total</th>
                                    <th>Top Section</th>
                                    <th>Top Type</th>
                                    <th>Latest</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($employee_rows as $row)
                                    <tr>
                                        <td>{{ $row['name'] }}</td>
                                        <td>{{ $row['jcf_count'] }}</td>
                                        <td>{{ $row['report_count'] }}</td>
                                        <td><strong>{{ $row['total_activity'] }}</strong></td>
                                        <td>{{ $row['top_section'] }}</td>
                                        <td>{{ $row['top_type'] }}</td>
                                        <td>{{ optional($row['last_activity_at'])->diffForHumans() ?: '-' }}</td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="7" class="text-center text-muted">No staff activity in selected window.</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="staff-performance-card span-4">
                <div class="staff-performance-head">
                    <div>
                        <h4 class="staff-performance-title">Filters Snapshot</h4>
                        <p class="staff-performance-subtitle">Current analytics scope.</p>
                    </div>
                </div>
                <div class="staff-performance-body">
                    <div class="snapshot-grid">
                        <div class="snapshot-item">
                            <span class="snapshot-label">Window Start</span>
                            <span class="snapshot-value">{{ optional($window_started_at)->format('d-m-Y H:i') ?: '-' }}</span>
                        </div>
                        <div class="snapshot-item">
                            <span class="snapshot-label">Window End</span>
                            <span class="snapshot-value">{{ optional($window_ends_at)->format('d-m-Y H:i') ?: '-' }}</span>
                        </div>
                        <div class="snapshot-item">
                            <span class="snapshot-label">Employee Filter</span>
                            <span class="snapshot-value">{{ $selected_user_id > 0 ? (collect($creators)->firstWhere('id', $selected_user_id)['name'] ?? 'Selected') : 'All Employees' }}</span>
                        </div>
                        <div class="snapshot-item">
                            <span class="snapshot-label">Section Filter</span>
                            <span class="snapshot-value">{{ $selected_section === 'all' ? 'All Sections' : (collect($section_options)->firstWhere('key', $selected_section)['label'] ?? 'Selected') }}</span>
                        </div>
                        <div class="snapshot-item">
                            <span class="snapshot-label">Active JCF Employees</span>
                            <span class="snapshot-value">{{ $active_jcf_employees }}</span>
                        </div>
                        <div class="snapshot-item">
                            <span class="snapshot-label">Active Inspection Employees</span>
                            <span class="snapshot-value">{{ $active_inspection_employees }}</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="staff-performance-card span-4">
                <div class="staff-performance-head">
                    <div>
                        <h4 class="staff-performance-title">Inspection Sections</h4>
                        <p class="staff-performance-subtitle">Report distribution by section.</p>
                    </div>
                </div>
                <div class="staff-performance-body">
                    <div class="staff-chip-list">
                        @forelse($section_rows as $row)
                            <span class="staff-chip">{{ $row['label'] }} <span class="badge badge-light border">{{ $row['count'] }}</span></span>
                        @empty
                            <span class="text-muted">No section breakdown available.</span>
                        @endforelse
                    </div>
                </div>
            </div>

            <div class="staff-performance-card span-4">
                <div class="staff-performance-head">
                    <div>
                        <h4 class="staff-performance-title">Top Inspection Types</h4>
                        <p class="staff-performance-subtitle">Most produced inspection report types.</p>
                    </div>
                </div>
                <div class="staff-performance-body">
                    <div class="staff-chip-list">
                        @forelse($type_rows as $row)
                            <span class="staff-chip">{{ $row['type'] }} <span class="badge badge-light border">{{ $row['count'] }}</span></span>
                        @empty
                            <span class="text-muted">No inspection type breakdown available.</span>
                        @endforelse
                    </div>
                </div>
            </div>

            <div class="staff-performance-card span-4">
                <div class="staff-performance-head">
                    <div>
                        <h4 class="staff-performance-title">Top JCF Subjects</h4>
                        <p class="staff-performance-subtitle">Most common job subjects/work scopes.</p>
                    </div>
                </div>
                <div class="staff-performance-body">
                    <div class="staff-chip-list">
                        @forelse($jcf_subject_rows as $row)
                            <span class="staff-chip">{{ \Illuminate\Support\Str::limit($row['subject'], 36, '..') }} <span class="badge badge-light border">{{ $row['count'] }}</span></span>
                        @empty
                            <span class="text-muted">No JCF subject breakdown available.</span>
                        @endforelse
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection
