<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        @page {
            size: A4;
            margin: 5mm 5mm 5mm 5mm;
        }

        *{ box-sizing: border-box; }
        html, body{ height: 100%; }
        body {
            font-family: DejaVu Sans, sans-serif;
            font-size: 9.5px;
            margin: 0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            page-break-inside: avoid;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        tr {
            page-break-inside: avoid;
        }
        
        .fixed-hieght td {
            height: 50px;
            vertical-align: middle;
            text-align: center;
        }

        
        thead {
            display: table-header-group;
        }

        .border {
            border: 1px solid #000;
        }

        .dark {
            background: #d9d9d9;
            font-weight: bold;
        }

        .center {
            text-align: center;
        }

        .right {
            text-align: right;
        }

        .title {
            font-size: 25px;
            font-weight: bold;
            line-height: 35px;
        }
                    
        .footer {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            font-size: 8px;
        }
        
        .page-number:after {
            content: "Page " counter(page);
        }
    </style>
</head>
<body>

{{-- ================= HEADER ================= --}}
@foreach($subCollections as $r)
<table>
    <tr>
        <td width="30%">
            @if ($model->inspection_logo)
                <img src="{{ asset('storage/'.$model->inspection_logo) }}">
            @else
                <img src="{{ asset('app-assets/images/logo/combined-logo.png') }}">
            @endif
        </td>

        <td width="40%" class="center">
            <div class="title">{{ $page_name }}</div>
            <div>{{ $page_text }}</div>
        </td>

        <td width="30%" class="right" style="ont-size: 14px !important; font-weight: bold;">
            <div>Head Office: Block 3053 | Hamdy Ramadan St.</div>
            <div>2nd Floor #2 |El-Mearag City|Maadi|Cairo|Egypt</div>
            <div><i class="ft-phone"></i> : +20 2 24477058 | <i class="ft-smartphone"></i> : +20 1032703368</div>
            <div>rse@rigsolutionz.com</div>
            <div>www.rigsolutionz.com</div>
        </td>
    </tr>
</table>

<br>

{{-- ================= INFO ================= --}}
<table>
    <tr>
        <td class="border dark" width="16%">Client Name</td>
        <td class="border" width="52%">{{ $job->client->name }}</td>
        <td class="border dark" width="16%">Register No.</td>
        <td class="border" width="16%">{{ $job->code }} / {{ $code }}</td>
    </tr>
</table>

<table>
    <tr>
        <td class="border dark" width="16%">Rig / Location</td>
        <td class="border" width="20%">{{ $job->deploc }}</td>
        <td class="border dark" width="16%">Color Code</td>
        <td class="border" width="16%">{{ $color }}</td>
        <td class="border dark" width="16%">Date</td>
        <td class="border" width="16%">{{ $date }}</td>
    </tr>
</table>



{{-- ================= MAIN TABLE ================= --}}

    <table>
        <thead>
        <tr class="center">
            <th class="border dark" width="10%">ID</th>
            <th class="border dark" width="20%">Equipment Description</th>
            <th class="border dark" width="8%">SWL</th>
            <th class="border dark" width="5%">Gross</th>

            <td colspan="3" width="21%" class="border dark">
                <table width="100%">
                    <tr>
                        <td class=" dark">Manufacturer / Test Certificate Details</td>
                    </tr>
                </table>
                <table width="100%">
                    <tr>
                        <td class="border dark" style="width: 33%;">Cert. No</td>
                        <td class="border dark" style="width: 26%;">Test Date</td>
                        <td class="border dark" style="width: 39.7%;">Tested By</td>
                    </tr>
                </table>
            </td>
            
            <td colspan="3" width="18%" class="border dark">
                <table width="100%">
                    <tr>
                        <td class="dark" style="font-size: 98%;">Current Certificate Details</td>
                    </tr>
                </table>
                <table width="100%">
                    <tr>
                        <td class="border dark" style="width: 36%;font-size: 91%;">Report #</td>
                        <td class="border dark" style="width: 32%;">Exam. date</td>
                        <td class="border dark" style="width: 32%;">Due Date</td>
                    </tr>
                </table>
            </td>
            
            <th class="border dark" width="10%">Attached or location</th>
            <th class="border dark" width="3%">Accept</th>
        </tr>
        </thead>
        <tbody class="center fixed-hieght">
        @foreach($r as $row)
            <tr>
                <td class="border" width="10%">
                    {{$row->reportable->lcr_12}}
                    {{$row->reportable->locr_12}}
                    {{$row->reportable->lfr_12}}
                    @if($row->reportable->lter_10 != null)
                        {{$row->reportable->lter_10['pop1']}}
                    @endif
                </td>
                <td class="border" width="20%">
                    {{$row->reportable->lcr_10}}
                    {{$row->reportable->locr_10}}
                    {{$row->reportable->lfr_10}}
                    @if($row->reportable->lter_10 != null)
                        {{$row->reportable->lter_10['pop20']}}
                    @endif    
                </td>
                <td class="border" width="8%">
                    {{$row->reportable->lcr_15}}
                    {{$row->reportable->locr_15}}
                    {{$row->reportable->lfr_15}}
                    @if($row->reportable->lter_10 != null)
                        {{$row->reportable->lter_10['pop4']}}
                    @endif
                </td>
                <td class="border" width="5%">{{$row->reportable->lter_19}}</td>
                <td class="border">
                    {{$row->reportable->lcr_23}}
                    {{$row->reportable->locr_23}}
                    {{$row->reportable->lfr_17}}
                    {{$row->reportable->lter_21}}    
                </td>
                <td class="border">
                    {{$row->reportable->lcr_22}}
                    {{$row->reportable->locr_22}}
                    {{$row->reportable->lfr_16}}
                    {{$row->reportable->lter_22}}
                </td>
                <td class="border">
                    {{$row->reportable->lcr_24}}
                    {{$row->reportable->locr_24}}
                    {{$row->reportable->lfr_18}}
                    {{$row->reportable->lter_20}}
                </td>
                <td class="border">{{$row->job_request->code}} / {{$row->reportable->code}}</td>
                <td class="border">
                    {{$row->reportable->lcr_6}}
                    {{$row->reportable->locr_6}}
                    {{$row->reportable->lfr_6}}
                    {{$row->reportable->lter_6}}    
                </td>
                <td class="border">
                    {{$row->reportable->lcr_7}}
                    {{$row->reportable->locr_7}}
                    {{$row->reportable->lfr_7}}
                    {{$row->reportable->lter_7}}
                </td>
                <td class="border">{{ $row->reportable->lter_15 }}</td>
                <td class="border">
                    @if(strstr($row->reportable->lcr_46, '_y') || strstr($row->reportable->locr_44, '_y') || strstr($row->reportable->lfr_33, '_y') || strstr($row->reportable->lter_51, '_y'))
                        YES
                    @else
                        NO
                    @endif
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>



{{-- ================= FOOTER ================= --}}
<table>
    <tr>
        <td class="border dark">Form No</td>
        <td class="border">{{ $model->footer_values->form_no }}</td>
        <td class="border dark">Issue No</td>
        <td class="border">{{ $model->footer_values->issue_no }}</td>
        <td class="border dark">Issue Date</td>
        <td class="border">{{ $model->footer_values->issue_date }}</td>
        <td class="border dark">Revision No</td>
        <td class="border">{{ $model->footer_values->revision_no }}</td>
        <td class="border dark">Revision Date</td>
        <td class="border">{{ $model->footer_values->revision_date }}</td>
        <td class="border dark">Page No.</td>
        <!--<td class="border page-number">{PAGE_NUM} / {PAGE_COUNT}</td>-->
        <td class="border page-number"></td>
    </tr>
    <!--<tr>-->
    <!--    <td><img src="{{asset('app-assets/images/footer-v2.png')}}" /></td>-->
    <!--</tr>-->
</table>
    {{-- Page break for next chunk --}}
    @if(!$loop->last)
        <div style="page-break-after: always;"></div>
    @endif
@endforeach

<script type="text/php">
if (isset($pdf)) {
    $pdf->page_text(
        520,
        820,
        "Page {PAGE_NUM} of {PAGE_COUNT}",
        null,
        8
    );
}
</script>

</body>
</html>
