@extends('layouts.app')

@section('header-bottom')
<style>
  .lregister-page-shell .donw {
    max-width: 1150px;
    margin: 0 auto 1rem;
  }

  .lregister-page-shell .card.donw {
    border-radius: 0;
    box-shadow: none;
  }
</style>
@endsection

@section('content')
<div class="lregister-page-shell">
  @php $index = 1; @endphp
  @foreach($subCollections as $subCollection)
    @include('layouts.inspection.lifting.lregister.pdf.pdf-page', [
      'r' => $subCollection,
      'page_number' => 'Page '.$index.' of '.$total,
      'id' => 'page_'.$index
    ])
    @php $index++; @endphp
  @endforeach

  <div class="card no-print mt-2">
    <div class="card-content">
      <div class="card-body">
        <div class="row" style="direction: rtl;">
          @can('create', App\Models\WorkFlow\MailCenter::class)
          <a class="btn btn-info btn-print btn-lg ml-1" href="{{ route('mailCenter.compose.related', ['relatedType' => 'inspection_report', 'relatedId' => $for_approve_url]) }}">Send via Rig MailCenter <i class="la la-envelope-o mr-50"></i></a>
          @endcan
          @if ($pdf_exists)
          <button type="button" id="print" class="btn btn-secondary btn-print btn-lg ml-1">Print Page <i class="la la-paper-plane-o mr-50"></i></button>
          <a class="btn btn-primary btn-print btn-lg ml-1" target="_blank" href="{{ $pdf_download_url }}">Download PDF <i class="la la-paper-plane-o mr-50"></i></a>
          @endif
          <button type="button" id="uploadpdf" class="btn btn-dark btn-print btn-lg">Upload / Update PDF <i class="la la-paper-plane-o"></i></button>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection

@section('footer')
<script>
  const pdfDownloadUrl = @json($pdf_download_url);

  function setUploadState(isBusy) {
    $('#uploadpdf').prop('disabled', isBusy);
    $('#uploadpdf i').toggleClass('la-paper-plane-o', !isBusy).toggleClass('la-refresh spinner', isBusy);
  }

  function uploadPdf() {
    const formData = new FormData();
    formData.append('source', 'server_register');
    @if(!empty($for_approve_url))
    formData.append('report_id', '{{$for_approve_url}}');
    @endif

    return new Promise(function (resolve, reject) {
      $.ajax({
        headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
        type: 'POST',
        url: "{{route('report.generatePdf')}}",
        cache: false,
        data: formData,
        processData: false,
        contentType: false,
        success: function (data) {
          resolve(data);
        },
        error: function (xhr) {
          reject(new Error((xhr.responseJSON && (xhr.responseJSON.message || xhr.responseJSON.error)) || 'The pdf failed to upload.'));
        }
      });
    });
  }

  function print_pdf() {
    const printWindow = window.open(pdfDownloadUrl);
    if (printWindow) {
      printWindow.window.print();
    }
  }

  $(document).on('click', '#uploadpdf', function () {
    setUploadState(true);
    uploadPdf()
      .then(function (data) {
        toastr.info('Good Job !', data.success, { positionClass: 'toast-bottom-left', showMethod: 'slideDown', hideMethod: 'slideUp', progressBar: true, timeOut: 1000, fadeOut: 1000, onHidden: function () { window.location.reload(); } });
      })
      .catch(function (error) {
        toastr.error('Upload failed', error.message || 'Unable to build the full PDF', { positionClass: 'toast-bottom-left', showMethod: 'slideDown', hideMethod: 'slideUp', progressBar: true, timeOut: 3000, fadeOut: 1000 });
      })
      .finally(function () {
        setUploadState(false);
      });
  });

  $(document).on('click', '#print', function () {
    print_pdf();
  });
</script>
@endsection
