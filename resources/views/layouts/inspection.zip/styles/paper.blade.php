@section('header-bottom')
<style>
		* {
				-webkit-print-color-adjust: exact !important;   /* Chrome, Safari, Edge */
				color-adjust: exact !important;                 /*Firefox*/
		}
		label{ font-size: 0.8rem; }
		.app-content .wizard.wizard-circle > .steps > ul > li.current ~ li:before, .app-content .wizard.wizard-circle > .steps > ul > li.current ~ li:after, .app-content .wizard.wizard-circle > .steps > ul > li.current:after{ background-color: #fff; }
		p { letter-spacing: inherit; margin-bottom: 0 !important; }
		.custom-control-label{ margin-bottom: 5px;}
		.custom-control-label::after{ top: 0 !important; }
		.skin-square label{ margin-bottom: auto; }
		.bg-dark{ background-color: #d9d9d9 !important; }
		.white{ color: #000 !important;}
		.logo-top{max-width: 95%;}
		.border-dark{ /*padding-top: 3px !important; padding-bottom: 3px !important;*/ }
		.card-body{ padding: 1rem 2rem; }
		.middle{ display: flex; align-items: center; }
		.mid11{ display: flex; align-items: center; }
		.just{ justify-content: center; }
		.noncheckedfrom{ background: url({{asset('app-assets/vendors/css/forms/icheck/square/purple.png')}}) -1px -1px no-repeat; display: inline-block; margin-right: 0.6rem; width: 17px; height: 17px; border: 1px solid #d9d9d9;}
		.noncheckedradiofrom{ background: url({{asset('app-assets/vendors/css/forms/icheck/square/purple.png')}}) -1px -1px no-repeat; display: inline-block; margin-right: 0.6rem; width: 17px; height: 17px; border: 1px solid #d9d9d9; border-radius: 15px;}
		.checked{ background-position: -51px -3px; border-color: #6a5a8c; }
		.mid{ vertical-align: middle; display: flex; padding-top: 3px; padding-bottom: 3px; }
		.text-16, .skin-square label{ font-size: 16px; }
		p.bnew{font-size: 22px !important; font-weight: 600 !important;}
		h1, h2, h3, h4, h5, h6, .h1, .h2, .h3, .h4, .h5, .h6{ color: #000 !important; }
		.h-90{ height: 130px; }
		.h-80{ height: 120px; }
		.h-70{ height: 100px; }
		.h-130{ height: 150px;}
		.h-175{ height: 310px; }
		.card{ page-break-before: always; counter-increment: page; }
		.inc:after{ content: counter(page) " of " counter(pages); }
		.donw{ max-width: 1150px; height: 1664px; margin: auto; border-radius: 0; box-shadow: none; padding-left: 10px; padding-right: 15px;}
		.emadnew{ font-size: 11px !important; }
		@page{  margin: 0 !important; padding: 0 !important; size: a4;  /* margin-right: 5mm !important; margin-left: 5mm !important;*/ }
</style>
@endsection

@section('content')
		@if(isset($have_edit) && count($have_edit) > 1 )
			<div class="card no-print">
				<div class="card-content">
					<div class="card-body">
						<div class="row">
							<div class="col-12">
								<h5>All Versions</h5>
							</div>
						</div>
						<hr />
						<div class="row">				
							@foreach($have_edit as $key => $edit_report)
								<div class="col-3 mb-1" data-type="versions" data-number="{{$edit_report['id']}}">
									<a href="{{$edit_report['route']}}" class="btn btn-warning btn-print btn-lg waves-effect waves-light">REV{{++$key}}: AT-{{$edit_report['edit_at']}} BY: {{$edit_report['edit_by']}}</a>
								</div>
							@endforeach
						</div>
					</div>
				</div>
			</div>
		@endif
		<section class="validation mb-1">
				<div class="card donw">
						<div class="card-content">
								<div class="card-body">
										<div class="row header-top mb-1" style="padding-top: 15px;">
												<div class="col-2 pl-0">
													@if (isset($invoice) && $invoice->invoice_company_type == \App\Models\WorkFlow\Invoice::$INVOICE_LTD_TYPE)
														<img src="{{asset('app-assets/images/logo/ltd-logo.png')}}" class="logo-top" style="max-width: none; width: 14em; margin-top: -10px; margin-left: -10px;"/>
													@else
														<img src="{{asset('app-assets/images/logo/logo.png')}}" class="logo-top" />
													@endif
												</div>
												<div class="col-7">
														@if (!str_contains($page_text, 'Invoice'))
																@if (str_contains($page_name, 'Crane'))
																		<h3 class="text-bold-600 text-center mb-0 mt-3">{{$page_name ?? ''}}</h3>
																@else
																		<h1 class="text-bold-600 text-center mb-0 mt-3">{{$page_name ?? ''}}</h1>
																@endif
																<p class="text-center text-bold-600 emadnew" style="margin-bottom: 5px;
																		@if (str_contains($page_name, 'Crane'))
																			font-size: 14px !important;
																		@endif
																">{{$page_text ?? ''}}</p>
														@else
																<h1 class="text-bold-600 text-center white" style="font-size: 5.5rem; margin-bottom: 0;" >{{strtoupper($page_name) ?? ''}}</h1>
																<p class="text-bold-600 text-center mb-0 white" style="font-size: 1.8rem !important;">{{$page_text ?? ''}}</p>
														@endif
												</div>
												<div class="col-3 pr-0 text-right address" >
														<p class="text-bold-700 white">3053 Mahmoud Madkor st; 2nd Floor #11
														El-Maerag City, Cairo</p>
														<p class="text-bold-700 white" >Phone/Fax: +20 2 24477058</p>
														<p class="text-bold-700 white">Cell phone: +20 1032703368</p>
														<p class="text-bold-700 white">Email: rse@rigsolutionz.com</p>
														<p class="text-bold-700 white">Website: www.rigsolutionz.com</p>
														@if (str_contains($page_text, 'Invoice'))
																@if ($invoice->invoice_company_type == \App\Models\WorkFlow\Invoice::$INVOICE_LTD_TYPE)
																	<p class="text-bold-700 white" style="font-size: 1.37rem;">Tax ID No.: 709-320-108</p>
																@else
																	<p class="text-bold-700 white" style="font-size: 1.37rem;">Tax ID No.: 210-838-655</p>
																@endif
														@endif
												</div>
										</div>
										@stack('page_content')
										<div class="row mt-1">
												<div class="col-4 text-bold-600 pl-0">
														{{$iso_number}}
												</div>
												<div class="col-5">
														<img src="{{asset('app-assets/images/footer.jpg')}}" style="max-width: 100%;" />
												</div>
												<div class="col-3 text-right text-bold-600 pr-0">

												</div>
										</div>
								</div>
						</div>
				</div>
				@yield('second_paper')
				
				@php
					$mailcenterComposeUrl = $mailcenter_compose_url ?? null;
					if (!$mailcenterComposeUrl && !empty($for_approve_url) && isset($folder) && !str_contains((string) $folder, 'workflow')) {
						$mailcenterComposeUrl = route('mailCenter.compose.related', ['relatedType' => 'inspection_report', 'relatedId' => $for_approve_url]);
					}
				@endphp
				@if($user_id_approved != Null || strpos( $folder, 'workflow' ) || Route::currentRouteName() == "defect.show")
				<div class="card no-print mt-2">
					  <div class="card-content">
						    <div class="card-body">
							      <div class="row" style="direction: rtl;">
										@if($mailcenterComposeUrl && auth()->user()->can('create', App\Models\WorkFlow\MailCenter::class))
											<a class="btn btn-info btn-print btn-lg ml-1" href="{{ $mailcenterComposeUrl }}">Send via Rig MailCenter <i class="la la-envelope-o mr-50"></i></a>
										@endif
										@if (Storage::disk('public')->exists($folder.'/'.$imageurl.'.pdf'))
											<button type="button" id="print" class="btn btn-secondary btn-print btn-lg ml-1">Print Page <i class="la la-paper-plane-o mr-50"></i></button>
											<a class="btn btn-primary btn-print btn-lg ml-1" target="_blank" href="{{URL('storage/'.$folder.'/'.$imageurl.'.pdf')}}">Download PDF <i class="la la-paper-plane-o mr-50"></i></a>
										@endif
										<button type="button" id="uploadpdf" class="btn btn-dark btn-print btn-lg">Upload / Update PDF <i class="la la-paper-plane-o"></i></button>
							      </div>
						    </div>
					  </div>
				</div>
				@endif
		</section>
@endsection

@section('footer')
		<script src="{{asset('app-assets/js/html2canvas.js')}}"></script>
		<script src="{{asset('app-assets/js/jspdf.js')}}"></script>
		<script>

				function take_snap_shot(){
						var array = []
						var captureElement = document.querySelectorAll('.donw'), i
						for (i = 0; i < captureElement.length; ++i) {
								html2canvas(captureElement[i])
									.then(canvas => {
											const image = canvas.toDataURL('image/png').replace('image/png', 'image/octet-stream')
											array.push(image)
											var formData = new FormData();
											formData.append('imageurl', '{{$imageurl}}');
											formData.append('folder', '{{$folder}}')
											formData.append('image', JSON.stringify(array));
											$.ajax({
													headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
													type: 'POST',
													url: "{{route('report.makeImageForPdf', $for_approve_url)}}",
													cache: false,
													data: formData,
													processData: false,
													contentType: false,
													success: function(data){
															var path = image;
															$('.fixed-top').append('<input type="hidden" class="imm" value="'+path+'">');
															if (data)
															{
																	toastr.info('Good Job !', data.success, { positionClass: 'toast-bottom-left', "showMethod": "slideDown", "hideMethod": "slideUp", "progressBar": true, timeOut: 1000, fadeOut: 1000, onHidden: function () { convert_pdf(); } })
															}
													},
											})
								  })
						}
				}

				function convert_pdf()
				{
						var doc = new jspdf.jsPDF('p', 'pt','a4',true);
						var width = doc.internal.pageSize.getWidth();
						var height = doc.internal.pageSize.getHeight();
						var captureElement = document.querySelectorAll('.imm'), i
						for (i = 0; i < captureElement.length; ++i){
								doc.addImage(captureElement[i].value, "PNG", 0, 0, width, height, "alias"+i, 'FAST')
								if (i+1 != captureElement.length)
								{
										doc.addPage()
								}
						}
						var blob = doc.output("blob");
						var formData = new FormData();
						formData.append('pdf', blob);
						formData.append('imageurl', '{{$imageurl}}');
						formData.append('folder', '{{$folder}}');
						$.ajax({
								headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
								type: 'POST',
								url: "{{route('report.generatePdf')}}",
								cache: false,
								data: formData,
								processData: false,
								contentType: false,
								success: function(data){
										toastr.info('Good Job !', data.success, { positionClass: 'toast-bottom-left', "showMethod": "slideDown", "hideMethod": "slideUp", "progressBar": true, timeOut: 1000, fadeOut: 1000, onHidden: function () { window.location.reload(); } });
								},
						});
				}

				function print_pdf()
				{
						printWindow = window.open("{{URL('storage/'.$folder.'/'.$imageurl.'.pdf')}}");
						printWindow.window.print();
				}

				$(document).on('click','#uploadpdf',function(){
						take_snap_shot()
				});

				$('#print').click(function(){
						print_pdf();
				});

				$(document).bind("keyup ", function(e){
					console.log(e.keyCode);
					if (e.keyCode == 80)
					{
						if (document.getElementById("print"))
						{
							print_pdf();
						}
						else
						{
							take_snap_shot();
						}
						return false;
				    }
				});

				$('[data-type="versions"]').each(function(key){
					var id = $('.donw [data-type="code"]').data('id');
					var number = $(this).data('number');
					if(number == id)
					{
						$('.donw [data-type="code"][data-id="'+ id +'"]').append(' - REV: ' + String(++key).padStart(2,"0")).css('font-size', '100%');
					}
				});

		</script>
@endsection
