@section('header-bottom')
<style>
		* {
				-webkit-print-color-adjust: exact !important;   /* Chrome, Safari, Edge */
				color-adjust: exact !important;                 /*Firefox*/
		}
		label{ font-size: 0.8rem; }
		.app-content .wizard.wizard-circle > .steps > ul > li.current ~ li:before, .app-content .wizard.wizard-circle > .steps > ul > li.current ~ li:after, .app-content .wizard.wizard-circle > .steps > ul > li.current:after{ background-color: #fff; }
		p { letter-spacing: inherit; margin-bottom: 0 !important; }
		.custom-control-label{ margin-bottom: 5px;}
		.custom-control-label::after{ top: 0 !important; }
		.skin-square label{ margin-bottom: auto; }
		.bg-dark{ background-color: #d9d9d9 !important; }
		.white{ color: #000 !important;}
		.logo-top{width: 225px; height: 115px; margin-top: -1.5em;}
		.border-dark{ /*padding-top: 3px !important; padding-bottom: 3px !important;*/ }
		.card-body{ padding: 1rem 2rem; }
		.middle{ display: flex; align-items: center; }
		.mid11{ display: flex; align-items: center; }
		.just{ justify-content: center; }
		.noncheckedfrom{ background: url({{asset('app-assets/vendors/css/forms/icheck/square/purple.png')}}) -1px -1px no-repeat; display: inline-block; margin-right: 0.6rem; width: 17px; height: 17px; border: 1px solid #d9d9d9;}
		.noncheckedradiofrom{ background: url({{asset('app-assets/vendors/css/forms/icheck/square/purple.png')}}) -1px -1px no-repeat; display: inline-block; margin-right: 0.6rem; width: 17px; height: 17px; border: 1px solid #d9d9d9; border-radius: 15px;}
		.checked{ background-position: -51px -3px; border-color: #6a5a8c; }
		.mid{ vertical-align: middle; display: flex; padding-top: 3px; padding-bottom: 3px; }
		.text-16, .skin-square label{ font-size: 16px; }
		p.bnew{font-size: 22px !important; font-weight: 600 !important;}
		h1, h2, h3, h4, h5, h6, .h1, .h2, .h3, .h4, .h5, .h6{ color: #000 !important; }
		.h-90{ height: 130px; }
		.h-80{ height: 120px; }
		.h-70{ height: 100px; }
		.h-130{ height: 150px;}
		.h-175{ height: 310px; }
		.hp-250{ height: 250px; }
		.card{ page-break-before: always; counter-increment: page; }
		.inc:after{ content: counter(page) " of " counter(pages); }
		.donw{ max-width: 1150px; height: 1664px; margin: auto; border-radius: 0; box-shadow: none; padding-left: 18px; padding-right: 18px;}
		.emadnew{ font-size: 11px !important; }
		@page{  margin: 0 !important; padding: 0 !important; size: a4;  /* margin-right: 5mm !important; margin-left: 5mm !important;*/ }
</style>
@endsection

@section('content')
		@if(isset($have_edit) && count($have_edit) > 1 )
			<div class="card no-print">
				<div class="card-content">
					<div class="card-body">
						<div class="row">
							<div class="col-12">
								<h5>All Versions</h5>
							</div>
						</div>
						<hr />
						<div class="row">				
							@foreach($have_edit as $key => $edit_report)
								<div class="col-3 mb-1" data-type="versions" data-number="{{$edit_report['id']}}">
									<a href="{{$edit_report['route']}}" class="btn btn-warning btn-print btn-lg waves-effect waves-light">REV{{++$key}}: AT-{{$edit_report['edit_at']}} BY: {{$edit_report['edit_by']}}</a>
								</div>
							@endforeach
						</div>
					</div>
				</div>
			</div>
		@endif
		<section class="validation mb-1">
				<div class="card donw">
						<div class="card-content">
								<div class="card-body">
									@if(Route::currentRouteName() != "drawingInspection.show") <!-- drawing inspection has its own header on its show blade -->
										<div class="row header-top mb-1" style="padding-top: 5px;">
												<div class="col-3 pl-0">
													@if ($model->inspection_logo)
														<img src="{{ asset('storage/' . $model->inspection_logo) }}" class="logo-top" />
													@else
														<img src="{{asset('app-assets/images/logo/combined-logo.png')}}" class="logo-top" />
													@endif
												</div>
												<div class="col-6">
														@if (!str_contains($page_text, 'Invoice'))
																@if (str_contains($page_name, 'Crane'))
																		<h3 class="text-bold-600 text-center mb-0 mt-2">{{$page_name ?? ''}}</h3>
																@elseif (request()->route()->getName() && str_contains(request()->route()->getName(), 'high3Pressure'))
																		<h3 class="text-bold-600 text-center mb-0 mt-2">{{$page_name ?? ''}}</h3>
																		<h4 class="text-bold-600 text-center mb-0">(High Pressure Line)</h4>
																@else
																		<h1 class="text-bold-600 text-center mb-0 mt-2"> {{$page_name ?? ''}}</h1>
																@endif
																<p class="text-center text-bold-600 emadnew" style="margin-bottom: 5px;
																		@if (str_contains($page_name, 'Crane'))
																			font-size: 14px !important;
																		@endif
																">{{$page_text ?? ''}}</p>
														@else
																<h1 class="text-bold-600 text-center white" style="font-size: 5.5rem; margin-bottom: 0;" >{{strtoupper($page_name) ?? ''}}</h1>
																<p class="text-bold-600 text-center mb-0 white" style="font-size: 1.8rem !important;">{{$page_text ?? ''}}</p>
														@endif
												</div>
												<div class="col-3 pr-0 text-right address" style="font-size: 10px;">
													<div class="text-bold-700 white" style="display: flex; flex-direction: column; align-items: flex-end; text-align: right;  width: 105%; margin-left: -12px;">
														<p>Head Office: Block# 3053|Hamdy Ramadan street</p>
														<p>2nd Floor #2 |El-Mearag City|Maadi|Cairo|Egypt</p>
														<p>
															<i class="ft-phone"></i> : +20 2 24477058 |
															<i class="ft-smartphone"></i> : +20 1032703368
														</p>
														<p>
															<i class="ft-mail"></i> : rse@rigsolutionz.com
														</p>
														<p>
															Website: <a href="www.rigsolutionz.com">www.rigsolutionz.com</a>
														</p>
													</div>
												</div>
										</div>
									@endif
										@stack('page_content')
									<div class="row" style="font-size: 12px; color: black; font-weight: 600; margin-top: 3px;">
										<div class="col-1 bg-dark p-0 border-dark">
											<span style="margin-left: 3px;">Form No</span>
										</div>
										<div class="col-2 p-0 pl-1 border-dark">{{$model->footer_values->form_no}}</div>

										<div class="bg-dark col-1 p-0 border-dark">
											<span style="margin-left: 3px;">Issue No</span>
										</div>
										<div class="col-0.5 p-0 pl-1 border-dark" style="width: calc(0.5 * 8.33333333%);">
											<span style="margin:auto">
												{{$model->footer_values->issue_no}}
											</span>
										</div>

										<div class="bg-dark col-1 p-0 border-dark">
											<span style="margin-left: 3px;">Issue Date</span>
										</div>
										<div class="col-1 p-0 pl-1 border-dark">{{$model->footer_values->issue_date}}</div>

										<div class="bg-dark col-1 p-0 border-dark">
											<span style="margin-left: 3px;">Revision No</span>
										</div>
										<div class="col-0.5 p-0 pl-1 border-dark" style="width: calc(0.5 * 8.33333333%);">
											<span style="margin:auto">
												{{$model->footer_values->revision_no}}
											</span>
										</div>

										<div class="bg-dark col-1 p-0 border-dark">
											<span style="margin-left: 3px;">Revision Date</span>
										</div>
										<div class="col-1 p-0 pl-1 border-dark">{{$model->footer_values->revision_date}}</div>

										<div class="bg-dark col-1 p-0 border-dark">
											<span style="margin-left: 3px;">Page No.</span>
										</div>
										<div class="col-1 p-0 pl-1 border-dark">{{$page_number}}</div>
									</div>
										<div class="row mt-1">
												<div class="col-3 text-bold-600 pl-0">{{--{{$iso_number}}--}}</div>
												<div class="col-6">
														<img src="{{asset('app-assets/images/footer-v2.png')}}" style="width: 40em; height: 3.5em;" />
												</div>
												<div class="col-3 text-right text-bold-600 pr-0"></div>
										</div>
								</div>
						</div>
				</div>
				@yield('second_paper')
				@php
					$mailcenterComposeUrl = $mailcenter_compose_url ?? null;
					if (!$mailcenterComposeUrl && !empty($for_approve_url) && isset($folder) && !str_contains((string) $folder, 'workflow')) {
						$mailcenterComposeUrl = route('mailCenter.compose.related', ['relatedType' => 'inspection_report', 'relatedId' => $for_approve_url]);
					}
				@endphp
				<!-- these inspection does require approval before upload the pdf -->
				@if($user_id_approved != Null || strpos( $folder, 'workflow' ) || Route::currentRouteName() == "defect.show" || Route::currentRouteName() == "nregister.show" || Route::currentRouteName() == "drawingInspection.show")
				<div class="card no-print mt-2">
					  <div class="card-content">
						    <div class="card-body">
							      <div class="row" style="direction: rtl;">
										@if($mailcenterComposeUrl && auth()->user()->can('create', App\Models\WorkFlow\MailCenter::class))
											<a class="btn btn-info btn-print btn-lg ml-1" href="{{ $mailcenterComposeUrl }}">Send via Rig MailCenter <i class="la la-envelope-o mr-50"></i></a>
										@endif
										@if (Storage::disk('public')->exists($folder.'/'.$imageurl.'.pdf'))
											<button type="button" id="print" class="btn btn-secondary btn-print btn-lg ml-1">Print Page <i class="la la-paper-plane-o mr-50"></i></button>
											<a class="btn btn-primary btn-print btn-lg ml-1" target="_blank" href="{{URL('storage/'.$folder.'/'.$imageurl.'.pdf')}}">Download PDF <i class="la la-paper-plane-o mr-50"></i></a>
										@endif
										<button type="button" id="uploadpdf" class="btn btn-dark btn-print btn-lg">Upload / Update PDF <i class="la la-paper-plane-o"></i></button>
							      </div>
						    </div>
					  </div>
				</div>
				@endif
		</section>
@endsection

@section('footer')
		<script src="{{asset('app-assets/js/html2canvas.js')}}"></script>
		<script src="{{asset('app-assets/js/jspdf.js')}}"></script>
		<script>

				function take_snap_shot(){
						var captureElements = document.querySelectorAll('.donw');
						var snapshots = Array.prototype.map.call(captureElements, function (element) {
								return html2canvas(element).then(function (canvas) {
										return canvas.toDataURL('image/png').replace('image/png', 'image/octet-stream');
								});
						});

						return Promise.all(snapshots).then(function (images) {
								var formData = new FormData();
								formData.append('imageurl', '{{$imageurl}}');
								formData.append('folder', '{{$folder}}');
								formData.append('image', JSON.stringify(images));
								return $.ajax({
										headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
										type: 'POST',
										url: "{{route('report.makeImageForPdf', $for_approve_url)}}",
										cache: false,
										data: formData,
										processData: false,
										contentType: false
								}).then(function () {
										return images;
								});
						});
				}

				function convert_pdf(images)
				{
				  		const pdf_page_mode = $('#page_mode').val() || 'p';

						var doc = new jspdf.jsPDF(pdf_page_mode, 'pt','a4',true);
						var width = doc.internal.pageSize.getWidth();
						var height = doc.internal.pageSize.getHeight();
						for (var i = 0; i < images.length; ++i){
								doc.addImage(images[i], "PNG", 0, 0, width, height, "alias"+i, 'FAST')
								if (i+1 != images.length)
								{
										doc.addPage()
								}
						}
						var blob = doc.output("blob");
						var formData = new FormData();
						formData.append('pdf', blob);
						formData.append('imageurl', '{{$imageurl}}');
						formData.append('folder', '{{$folder}}');
						@if(!empty($for_approve_url))
						formData.append('report_id', '{{$for_approve_url}}');
						@endif
						$.ajax({
								headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
								type: 'POST',
								url: "{{route('report.generatePdf')}}",
								cache: false,
								data: formData,
								processData: false,
								contentType: false,
								success: function(data){
										toastr.info('Good Job !', data.success, { positionClass: 'toast-bottom-left', "showMethod": "slideDown", "hideMethod": "slideUp", "progressBar": true, timeOut: 1000, fadeOut: 1000, onHidden: function () { window.location.reload(); } });
								},
						});
				}

				function print_pdf()
				{
						printWindow = window.open("{{URL('storage/'.$folder.'/'.$imageurl.'.pdf')}}");
						printWindow.window.print();
				}

				$(document).on('click','#uploadpdf',function(){
						take_snap_shot()
								.then(function (images) {
										return convert_pdf(images);
								})
								.catch(function () {
										toastr.error('Capture failed', 'Unable to build the full PDF', { positionClass: 'toast-bottom-left', "showMethod": "slideDown", "hideMethod": "slideUp", "progressBar": true, timeOut: 3000, fadeOut: 1000 });
								});
				});

				$('#print').click(function(){
						print_pdf();
				});

				$(document).bind("keyup ", function(e){
					console.log(e.keyCode);
					if (e.keyCode == 80)
					{
						if (document.getElementById("print"))
						{
							print_pdf();
						}
						else
						{
							take_snap_shot().then(function (images) {
									return convert_pdf(images);
							});
						}
						return false;
					}
				});

				$('[data-type="versions"]').each(function(key){
					var id = $('.donw [data-type="code"]').data('id');
					var number = $(this).data('number');
					if(number == id)
					{
						$('.donw [data-type="code"][data-id="'+ id +'"]').append(' - REV: ' + String(++key).padStart(2,"0")).css('font-size', '100%');
					}
				});

		</script>
@endsection
