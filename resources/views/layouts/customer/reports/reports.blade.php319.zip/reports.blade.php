@extends('layouts.customer.app')
@section('header')
<link rel="stylesheet" type="text/css" href="{{asset('app-assets/vendors/css/extensions/toastr.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('app-assets/vendors/css/tables/datatable/datatables.min.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('app-assets/vendors/css/tables/extensions/responsive.dataTables.min.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('app-assets/vendors/css/tables/extensions/fixedHeader.dataTables.min.css')}}">
@endsection
@section('header-bottom')
<link rel="stylesheet" type="text/css" href="{{asset('app-assets/css/plugins/extensions/toastr.css')}}">
@endsection
@section('content')
<section class="users-list-wrapper">
    <div class="users-list">

        <div class="card">
            <div class="card-content">
                <div class="card-body">
                    <button type="button" class="btn btn-success mr-1" style="margin-bottom: 15px" onclick="handleDownload()"
                    > Download All
                    </button>
                    <!-- datatable start -->
                    <div class="table-responsive">
                        @php
                            $resolvePdfPath = function ($inspectionReport) {
                                $jobCode = optional($inspectionReport->job_request)->code;
                                $reportCode = (string) ($inspectionReport->code ?? '');
                                $reportableType = (string) ($inspectionReport->reportable_type ?? '');

                                if ($jobCode === null || trim($jobCode) === '' || trim($reportCode) === '' || trim($reportableType) === '') {
                                    return null;
                                }

                                $suffix = trim($jobCode).'/'.trim($reportCode).'.pdf';
                                $cleanType = str_replace('App\\Models\\Inspection\\', '', $reportableType);
                                $segments = array_values(array_filter(explode('\\', $cleanType)));
                                $module = strtolower($segments[0] ?? '');
                                $class = $segments[1] ?? '';
                                $classLower = strtolower($class);
                                $classCamel = $class !== '' ? lcfirst($class) : '';

                                $candidates = [];
                                if ($module !== '' && $classLower !== '') {
                                    $candidates[] = 'pdf/inspection/'.$module.'/'.$classLower.'/'.$suffix;
                                }
                                if ($module !== '' && $classCamel !== '' && $classCamel !== $classLower) {
                                    $candidates[] = 'pdf/inspection/'.$module.'/'.$classCamel.'/'.$suffix;
                                }
                                if ($reportableType === 'App\\Models\\Inspection\\Tubular\\PipesSummaryReport') {
                                    $candidates[] = 'pdf/inspection/tubular/summary/'.$suffix;
                                }

                                foreach (array_values(array_unique($candidates)) as $path) {
                                    if (Storage::disk('public')->exists($path)) {
                                        return $path;
                                    }
                                }

                                return null;
                            };
                        @endphp

                        <table id="users-list" class="table table-striped table-bordered dataex-fixh-responsive row-grouping">
                            <thead>
                                <tr>
                                    <th>Type</th>
                                    <th>Report No.</th>
                                    <th>ID</th>
                                    <th>Equipment</th>
                                    <th>Exam. Date</th>
                                    <th>P.O</th>
                                    <th>Internal S.O</th>
                                    <th>Work Location</th>

                                </tr>
                            </thead>
                            <tbody>
                              @foreach($job_requests as $job_request)
                                @foreach($job_request->inspection_reports as $inspection_report)
                                @php
                                  $pdfPath = $resolvePdfPath($inspection_report);
                                  $typeLabel = trim(preg_replace('/(?<!^)[A-Z]/', ' $0', class_basename((string) $inspection_report->reportable_type)));
                                @endphp
                                @if((int)($inspection_report->publish ?? 0) !== 0 && $inspection_report->reportable != NULL && $pdfPath)
                                  <tr>
                                    <td class="text-center">{{$typeLabel}}</td>
                                    <td class="text-center">
                                      <a class="btn btn-info mr-1" style="width: 50%; z-index: 0;" target="_blank" href="{{Storage::url($pdfPath)}}"
                                         data-path="{{$pdfPath}}"
                                      >
                                        {{$job_request->code}} / {{$inspection_report->code}}
                                      </a>
                                    </td>
                                    <td>
                                      {{$inspection_report->reportable->lcr_12}}
                                      {{$inspection_report->reportable->locr_12}}
                                      {{$inspection_report->reportable->lfr_12}}
                                      @if($inspection_report->reportable->lter_10 != null)
                                        {{$inspection_report->reportable->lter_10['pop1']}}
                                      @endif
                                      {{$inspection_report->reportable->nmpr_28}}
                                      {{$inspection_report->reportable->ntir_13}}
                                      {{$inspection_report->reportable->nvr_6}}
                                      {{$inspection_report->reportable->nur_26}}
                                      {{$inspection_report->reportable->nwhr_15}}
                                      {{$inspection_report->reportable->nhpr_10}}
                                      {{$inspection_report->reportable->nh2pr_10}}
                                      @if($inspection_report->reportable->ldr_8 != null)
                                      <?php
                                        $lcr_10 = '';
                                        foreach (json_decode($inspection_report->reportable->ldr_8) as $key1 => $value1) {
                                          if(json_decode(json_encode($value1))->lcr_10 != null){
                                            $lcr_10 .= json_decode(json_encode($value1))->lcr_10;
                                            $lcr_10 .= ' . <br />';
                                          }
                                        }
                                        echo $lcr_10;
                                      ?>
                                      @endif
																			{{$inspection_report->reportable->tool_number}} <!-- stabilizer  -->
																			{{$inspection_report->reportable->material_no}} <!-- reamer -->
                                      
                                    </td>
                                    <td>
                                      {{$inspection_report->reportable->lcr_10}}
                                      {{$inspection_report->reportable->locr_10}}
                                      {{$inspection_report->reportable->lfr_10}}
                                      @if($inspection_report->reportable->lter_10 != null)
                                        {{$inspection_report->reportable->lter_10['pop20']}}
                                      @endif
                                      {{$inspection_report->reportable->nur_12}}
                                      {{$inspection_report->reportable->desc}}
																			{{$inspection_report->reportable->material_description}} <!-- stabilizer/reamer -->
																			{{$inspection_report->reportable->joint_description}} <!-- drill pipes/Heavy weight/Drill collars -->
																			{{$inspection_report->reportable->description}} <!-- subs/PBL subs -->
                                      
                                    </td>
                                    <td>
                                      {{$inspection_report->reportable->ldr_6}}
                                      {{$inspection_report->reportable->lcr_6}}
                                      {{$inspection_report->reportable->locr_6}}
                                      {{$inspection_report->reportable->lfr_6}}
                                      {{$inspection_report->reportable->lter_6}}
                                      {{$inspection_report->reportable->nmpr_6}}
                                      {{$inspection_report->reportable->ntir_6}}
                                      {{$inspection_report->reportable->nvr_4}}
                                      {{$inspection_report->reportable->nur_6}}
                                      {{$inspection_report->reportable->nsr_4}}
                                      {{$inspection_report->reportable->nwhr_6}}
                                      {{$inspection_report->reportable->nhpr_6}}
                                      {{$inspection_report->reportable->nh2pr_6}}
                                      {{$inspection_report->reportable->nar_4}}
                                      {{$inspection_report->reportable->examination_date}}
                                    </td>
                                    <td>
                                      {{--{{$inspection_report->reportable->ldr_2}}--}}
                                      {{--{{$inspection_report->reportable->lcr_2}}--}}
                                      {{--{{$inspection_report->reportable->locr_2}}--}}
                                      {{--{{$inspection_report->reportable->lfr_2}}--}}
                                      {{--{{$inspection_report->reportable->lter_2}}--}}
                                      {{--{{$inspection_report->reportable->nmpr_2}}--}}
                                      {{--{{$inspection_report->reportable->ntir_2}}--}}
                                      {{--{{$inspection_report->reportable->nvr_2}}--}}
                                      {{--{{$inspection_report->reportable->nur_2}}--}}
                                      {{--{{$inspection_report->reportable->nsr_2}}--}}
                                      {{--{{$inspection_report->reportable->nwhr_2}}--}}
                                      {{--{{$inspection_report->reportable->nhpr_2}}--}}
                                      {{--{{$inspection_report->reportable->nh2pr_2}}--}}
                                      {{--{{$inspection_report->reportable->nar_2}}--}}
                                      {{$job_request->purchase_order}}
                                    </td>
                                    <td>
																			{{$inspection_report->reportable->internal_service_order}} <!-- Internal S.O -->
																		</td>
                                    <td>{{$inspection_report->reportable->job_request->deploc}}</td>

                                  </tr>
                                @endif
                                @endforeach
                                @endforeach
                            </tbody>
                        </table>

                    </div>
                    <!-- datatable ends -->
                </div>
            </div>
        </div>

    </div>
</section>
@endsection
@section('footer')
<!-- BEGIN: Page Vendor JS-->
<script src="{{asset('app-assets/vendors/js/tables/datatable/datatables.min.js')}}"></script>
<script src="{{asset('app-assets/vendors/js/tables/datatable/dataTables.responsive.min.js')}}"></script>
<script src="{{asset('app-assets/vendors/js/tables/datatable/dataTables.fixedHeader.min.js')}}"></script>
<script>

  function handleDownload(e) {
    const filePathes = [];
    document.querySelectorAll('#users-list tbody tr td a').forEach(function (a) {
      filePathes.push(a.getAttribute('data-path').replaceAll('\\', '/'));
    });

    const currentGuard = "{{ \Illuminate\Support\Facades\Auth::guard('clientDepartments')->check() ? 'clientDepartments' : 'customer' }}";
    const url = currentGuard == 'clientDepartments' ? "{{route('department.downloadFiles')}}" : "{{route('client.downloadFiles')}}"
    var downloadLink = document.createElement('a');
    downloadLink.href = url + '?filePaths='+ JSON.stringify(filePathes);
    document.body.appendChild(downloadLink);
    downloadLink.click();
  }
</script>
<!-- END: Page Vendor JS-->
@endsection
@section('ajax')
<script src="{{asset('app-assets/vendors/js/extensions/toastr.min.js')}}"></script>
<script>
$(document).ready(function() {
  $('.dataex-fixh-responsive thead th').each(function (){
    var title = $(this).text();
    $(this).html( '<input type="text" placeholder="'+title+'" />' );
  });
  var groupColumn = 0;
  var tableResponsive = $('.dataex-fixh-responsive').DataTable({
      // responsive: true,
      
      columnDefs: [{ visible: false, targets: groupColumn }],
      order: [[groupColumn, 'asc']],
      drawCallback: function (settings) {
          var api = this.api();
          var rows = api.rows({ page: 'current' }).nodes();
          var last = null;
  
          api.column(groupColumn, { page: 'current' })
              .data()
              .each(function (group, i) {
                  if (last !== group) {
                      $(rows)
                          .eq(i)
                          .before(
                              '<tr class="group"><td colspan="7">' +
                                  group +
                                  '</td></tr>'
                          );
  
                      last = group;
                  }
              });
      },
      // stateSave: true,
      stateLoadParams: function(settings, data) {
        for (i = 0; i < data.columns["length"]; i++) {
          var col_search_val = data.columns[i].search.search;
          if (col_search_val != "") {
            $("input", $(".dataex-fixh-responsive thead th")[i]).val(col_search_val);
          }
        }
      },
      "initComplete": function () {
          // Apply the search
          this.api().columns().every( function () {
              var that = this;
              $( 'input', this.header() ).on( 'keyup change clear', function () {
                  if ( that.search() !== this.value ) {
                      that
                          .search( this.value )
                          .draw();
                  }
              } );
          } );
      },  
  });
  
  new $.fn.dataTable.FixedHeader(tableResponsive,{
      header: true,
      headerOffset: $('.header-navbar').outerHeight()
  });
});
</script>
@endsection
