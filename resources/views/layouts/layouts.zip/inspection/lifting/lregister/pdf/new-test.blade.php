<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
<!-- BEGIN: Head-->
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="description" content="">
    <meta name="keywords" content="KeenDeer">
    <meta name="author" content="Emad Elrouby">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{$page_name ?? ''}} - {{config('app.name')}}</title>
    <link rel="apple-touch-icon" href="{{asset('app-assets/images/ico/apple-icon-120.png')}}">
    <link rel="shortcut icon" type="image/x-icon" href="{{asset('app-assets/images/ico/favicon.ico')}}">

    <link rel="stylesheet" type="text/css" href="{{asset('app-assets/fonts/material-icons/material-icons.css')}}">

    <!-- BEGIN: Vendor CSS-->
    <link rel="stylesheet" type="text/css" href="{{asset('app-assets/vendors/css/material-vendors.min.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('app-assets/vendors/css/extensions/toastr.css')}}">
    <!-- END: Vendor CSS-->
@yield('header')
<!-- BEGIN: Theme CSS-->
    <link rel="stylesheet" type="text/css" href="{{asset('app-assets/css/material.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('app-assets/css/components.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('app-assets/css/bootstrap-extended.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('app-assets/css/material-extended.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('app-assets/css/material-colors.css')}}">
    <!-- END: Theme CSS-->

    <!-- BEGIN: Page CSS-->
    <link rel="stylesheet" type="text/css"
          href="{{asset('app-assets/css/core/menu/menu-types/material-vertical-compact-menu.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('app-assets/css/core/colors/material-palette-gradient.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('app-assets/fonts/mobiriseicons/24px/mobirise/style.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('app-assets/fonts/simple-line-icons/style.min.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('app-assets/css/pages/page-users.css')}}">
    <!-- END: Page CSS-->

    <link rel="stylesheet" type="text/css" href="{{asset('app-assets/css/plugins/extensions/toastr.css')}}">
    @yield('header-bottom')
    <link rel="stylesheet" type="text/css" href="{{asset('app-assets/css/custom.css')}}">

</head>
<!-- END: Head-->

<!-- BEGIN: Body-->
<body class="vertical-layout vertical-compact-menu material-vertical-layout material-layout 2-columns fixed-navbar"
      data-open="click" data-menu="vertical-compact-menu" data-col="2-columns">


<div class="card no-print mt-2">
    <div class="card-content fixed-top">
        <div class="card-body">
            <div class="row" style="direction: rtl;">
                @if (Storage::disk('public')->exists($folder.'/'.$imageurl.'.pdf'))
                    <button type="button" id="print" class="btn btn-secondary btn-print btn-lg ml-1">Print Page <i class="la la-paper-plane-o mr-50"></i></button>
                    <a class="btn btn-primary btn-print btn-lg ml-1" target="_blank" href="{{URL('storage/'.$folder.'/'.$imageurl.'.pdf')}}">Download PDF <i class="la la-paper-plane-o mr-50"></i></a>
                @endif
                <button type="button" id="uploadpdf" class="btn btn-dark btn-print btn-lg">Upload / Update PDF <i class="la la-paper-plane-o"></i></button>
            </div>
        </div>
    </div>
</div>
<br/>
<!-- BEGIN: Content-->
@php  $index = 1; @endphp
@foreach($subCollections as $subCollection)
@include('layouts.inspection.lifting.lregister.pdf.pdf-page', ['r' => $subCollection, 'page_number' => 'Page '.$index.' of '.$total, 'id'=> 'page_'.$index])
@php $index++; @endphp
@endforeach
<!-- END: Content-->
<div class="sidenav-overlay"></div>
<div class="drag-target"></div>
<!-- BEGIN: Vendor JS-->
<script src="{{asset('app-assets/vendors/js/material-vendors.min.js')}}"></script>
<script src="{{asset('app-assets/vendors/js/extensions/sweetalert2.all.min.js')}}"></script>
<!-- BEGIN Vendor JS-->

@yield('footer')

<script src="{{asset('app-assets/vendors/js/extensions/toastr.min.js')}}"></script>


<!-- BEGIN: Theme JS-->
<script src="{{asset('app-assets/js/core/app-menu.js')}}"></script>
<script src="{{asset('app-assets/js/core/app.js')}}"></script>
<!-- END: Theme JS-->

<!-- BEGIN: Page JS-->
<script src="{{asset('app-assets/js/scripts/pages/material-app.js')}}"></script>
<script src="{{asset('app-assets/js/scripts/navs/navs.js')}}"></script>
<!-- END: Page JS-->
<!-- <script src="{{asset('js/app.js')}}"></script> -->
<!-- <script src="{{asset('build/assets/app.e80b3859.js')}}"></script> -->
@yield('ajax')

<script src="{{asset('app-assets/js/html2canvas.js')}}"></script>
<script src="{{asset('app-assets/js/jspdf.js')}}"></script>
<script>

  function take_snap_shot() {
    $('#uploadpdf i').removeClass('la la-paper-plane-o').addClass('la la-refresh spinner');
    $('#uploadpdf').prop('disabled', true);
    var array = [];
    var captureElements = document.querySelectorAll('.donw');

    // Function to capture elements recursively
    function captureElementsRecursively(index) {
      console.log("UPLOAD IMAGES>>>", index, captureElements[index]);
      if (index >= captureElements.length) {
        // If all elements are captured, proceed to upload
        uploadImages(array);
        return;
      }

      // Capture the current element using html2canvas
      html2canvas(captureElements[index]).then(function (canvas) {
        const image = canvas.toDataURL('image/png').replace('image/png', 'image/octet-stream');
        array.push(image);
        $('.fixed-top').append('<input type="hidden" class="imm" value="' + image + '">');

        // Capture the next element recursively
        captureElementsRecursively(index + 1);
      }).catch(function (error) {
        console.error('Error capturing element:', error);
        // Handle errors if needed
        captureElementsRecursively(index + 1); // Move to the next element even if there's an error
      });
    }

    // Function to upload images using Ajax
    function uploadImages(imagesArray) {
      var formData = new FormData();
      formData.append('imageurl', '{{$imageurl}}');
      formData.append('folder', '{{$folder}}');
      formData.append('image', JSON.stringify(imagesArray));

      $.ajax({
        headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
        type: 'POST',
        url: "{{ route('report.makeImageForPdf', $for_approve_url) }}",
        cache: false,
        data: formData,
        processData: false,
        contentType: false,
        success: function (data) {
          if (data) {
            toastr.info('Good Job !', data.success, {
              positionClass: 'toast-bottom-left',
              "showMethod": "slideDown",
              "hideMethod": "slideUp",
              "progressBar": true,
              timeOut: 1000,
              fadeOut: 1000,
              onHidden: function () {
                convert_pdf();
              }
            });
          }
        },
        error: function (xhr, status, error) {
          console.error('Error uploading images:', error);
        },
        complete: function () {
          $('#uploadpdf i').removeClass('la la-refresh spinner').addClass('la la-paper-plane-o');
          $('#uploadpdf').prop('disabled', false);
        }
      });
    }

    //*** Start capturing elements recursively ***//
    captureElementsRecursively(0);
  }

  function convert_pdf()
  {
    var doc = new jspdf.jsPDF('p', 'mm', 'a4',true);

    // Function to add images to the PDF
    function addImageToPdf(imageUrl) {
      // Fixed dimensions for A4 page
      const pageWidth = 210; // mm
      const pageHeight = 297; // mm

      // Add image to PDF
      doc.addImage(imageUrl, 'PNG', 0, 0, pageWidth, pageHeight);
    }

    // Loop through each image URL and add it to the PDF
    var captureElements = document.querySelectorAll('.donw');
    for (i = 0; i < captureElements.length; i++) {
      const imageURL =  "{{URL('/')}}" + '/storage/images/'+ '{{$folder.'/'.$imageurl}}' +'/file' + i +'.png';
      addImageToPdf(imageURL);
      if(i < captureElements.length -1){
        doc.addPage();
      }
    }
    var blob = doc.output("blob");

    var formData = new FormData();
    formData.append('folder', '{{$folder}}');
    formData.append('imageurl', '{{$imageurl}}');
    formData.append('pdf', blob);
    @if(!empty($for_approve_url))
    formData.append('report_id', '{{$for_approve_url}}');
    @endif
    $.ajax({
      headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
      type: 'POST',
      url: "{{route('report.generatePdf')}}",
      cache: false,
      data: formData,
      processData: false,
      contentType: false,
      success: function(data){
        toastr.info('Good Job !', data.success, { positionClass: 'toast-bottom-left', "showMethod": "slideDown", "hideMethod": "slideUp", "progressBar": true, timeOut: 1000, fadeOut: 1000, onHidden: function () {
          window.location.reload();
        } });
      },
    });
  }

  function print_pdf()
  {
    printWindow = window.open("{{URL('storage/'.$folder.'/'.$imageurl.'.pdf')}}");
    printWindow.window.print();
  }

  $(document).on('click','#uploadpdf',function(){
    take_snap_shot()
  });

  $('#print').click(function(){
    print_pdf();
  });

  $(document).bind("keyup ", function(e){
    console.log(e.keyCode);
    if (e.keyCode == 80)
    {
      if (document.getElementById("print"))
      {
        print_pdf();
      }
      else
      {
        take_snap_shot();
      }
      return false;
    }
  });

  $('[data-type="versions"]').each(function(key){
    var id = $('.donw [data-type="code"]').data('id');
    var number = $(this).data('number');
    if(number == id)
    {
      $('.donw [data-type="code"][data-id="'+ id +'"]').append(' - REV: ' + String(++key).padStart(2,"0")).css('font-size', '100%');
    }
  });

</script>

</body>
<!-- END: Body-->

</html>
