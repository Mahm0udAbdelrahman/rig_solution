@section('footer')
		<script src="{{asset('app-assets/vendors/js/extensions/jquery.steps.min.js')}}"></script>
		<script src="{{asset('app-assets/vendors/js/forms/validation/jqBootstrapValidation.js')}}"></script>
		<script src="{{asset('app-assets/vendors/js/forms/spinner/jquery.bootstrap-touchspin.js')}}"></script>
		<script src="{{asset('app-assets/vendors/js/forms/icheck/icheck.min.js')}}"></script>
		<script src="{{asset('app-assets/vendors/js/forms/toggle/bootstrap-switch.min.js')}}"></script>
		<script src="{{asset('app-assets/vendors/js/forms/toggle/switchery.min.js')}}"></script>
		<script src="{{asset('app-assets/vendors/js/forms/select/select2.full.min.js')}}"></script>
		<script src="{{asset('app-assets/vendors/js/forms/validation/jquery.validate.min.js')}}"></script>
		<script src="{{asset('app-assets/js/core/libraries/jquery_ui/jquery-ui.min.js')}}"></script>
@endsection
@section('ajax')
		<script src="{{asset('app-assets/js/scripts/ui/jquery-ui/date-pickers.js')}}"></script>
		<script>
				var form = $(".steps-validation").show();
				window.form = form;

				window.getWizardFieldLabel = function ($field) {
						if (!$field || !$field.length) {
								return '';
						}

						var id = $field.attr('id');
						if (id) {
								var $forLabel = $('label[for="' + id + '"]').first();
								if ($forLabel.length) {
										return $.trim($forLabel.text());
								}
						}

						var $containerLabel = $field.closest('.controls, .form-group').find('label').first();
						if ($containerLabel.length) {
								return $.trim($containerLabel.text());
						}

						return $field.attr('name') || '';
				};

				window.showWizardValidationMessage = function ($form, $firstInvalid) {
						var label = window.getWizardFieldLabel($firstInvalid);
						var message = label ? ('Please complete required field: ' + label) : 'Please complete required fields in this step to continue.';

						if ($firstInvalid && $firstInvalid.length) {
								var offset = $firstInvalid.offset();
								if (offset && typeof offset.top !== 'undefined') {
										$('html, body').animate({ scrollTop: Math.max(offset.top - 120, 0) }, 250);
								}
								try {
										$firstInvalid.focus();
								} catch (e) {
										// no-op: hidden/non-focusable elements should not break wizard flow
								}
						}

						if (typeof Swal !== 'undefined') {
								Swal.fire({
										title: 'Missing Required Data',
										text: message,
										type: 'warning',
										icon: 'warning',
										confirmButtonText: 'OK',
								});
								return;
						}

						if (typeof toastr !== 'undefined') {
								toastr.warning(message, 'Validation');
								return;
						}

						console.warn('Wizard validation message:', message);
				};

				window.getWizardCurrentStepContainer = function ($form) {
						var $currentBody = $form.find('.body.current').first();
						if ($currentBody.length) {
								return $currentBody;
						}

						var $visibleBody = $form.find('.body:visible').first();
						if ($visibleBody.length) {
								return $visibleBody;
						}

						var $visibleFieldset = $form.find('fieldset:visible').first();
						if ($visibleFieldset.length) {
								return $visibleFieldset;
						}

						return $();
				};

				window.manualValidateWizardVisibleStep = function ($form) {
						var $stepContainer = window.getWizardCurrentStepContainer($form);
						if (!$stepContainer.length) {
								return { valid: true, firstInvalid: $() };
						}

						var invalid = [];
						var checkedRadioGroups = {};

						$stepContainer.find(':input[required]').each(function () {
								var $input = $(this);
								if ($input.prop('disabled')) {
										return;
								}
								if ($input.is(':hidden') && !$input.hasClass('select2-hidden-accessible')) {
										return;
								}

								var type = ($input.attr('type') || '').toLowerCase();
								if (type === 'radio') {
										var name = $input.attr('name');
										if (!name || checkedRadioGroups[name]) {
												return;
										}
										checkedRadioGroups[name] = true;
										var groupSelector = 'input[type="radio"][name="' + name.replace(/"/g, '\\"') + '"]';
										var $group = $stepContainer.find(groupSelector).filter(function () {
												return !$(this).prop('disabled');
										});
										if (!$group.is(':checked')) {
												invalid.push($input[0]);
										}
										return;
								}

								if (type === 'checkbox') {
										if (!$input.is(':checked')) {
												invalid.push($input[0]);
										}
										return;
								}

								var value = ($input.val() || '').toString().trim();
								if (value === '') {
										invalid.push($input[0]);
								}
						});

						return {
								valid: invalid.length === 0,
								firstInvalid: invalid.length ? $(invalid[0]) : $()
						};
				};

				window.validateWizardCurrentStep = function (formElement) {
						try {
								var $form = formElement && formElement.jquery ? formElement : $(formElement || '.steps-validation').first();
								if ($form.length && !$form.is('form')) {
										$form = $form.closest('form.steps-validation');
								}
								if (!$form.length) {
										$form = $('.steps-validation').first();
								}
								if (!$form.length) {
										return true;
								}

								window.form = $form;
								form = $form;

								$form.validate().settings.ignore = ":disabled,:hidden";
								var validatorResult = $form.valid();
								var manualResult = window.manualValidateWizardVisibleStep($form);

								// Fallback: if plugin validator fails because of non-visible artifacts
								// but all required inputs in current visible step are valid, allow moving on.
								if (!validatorResult && manualResult.valid) {
										return true;
								}

								if (!manualResult.valid) {
										window.showWizardValidationMessage($form, manualResult.firstInvalid);
										return false;
								}

								return validatorResult;
						} catch (error) {
								console.error('Wizard validation exception:', error);
								// Fail-open to avoid silent stuck wizard state.
								return true;
						}
				};

				var makeSelect2AwareIgnore = function (ignoreValue) {
						if (typeof ignoreValue !== 'string') {
								return ignoreValue;
						}

						if (ignoreValue.indexOf(':hidden') === -1 || ignoreValue.indexOf('select2-hidden-accessible') !== -1) {
								return ignoreValue;
						}

						return ignoreValue.replace(':hidden', ':hidden:not(.select2-hidden-accessible)');
				};

				if (typeof $.validator !== 'undefined' && $.validator.prototype && !$.validator.prototype._rigSelect2AwarePatchApplied) {
						var originalValidatorElements = $.validator.prototype.elements;
						$.validator.prototype.elements = function () {
								var originalIgnore = this.settings.ignore;
								this.settings.ignore = makeSelect2AwareIgnore(originalIgnore);
								try {
										return originalValidatorElements.call(this);
								} finally {
										this.settings.ignore = originalIgnore;
								}
						};
						$.validator.prototype._rigSelect2AwarePatchApplied = true;
				}

				if (typeof $.fn.select2 === 'function') {
						window.initSearchableSelect = function($select){
								if (!$select || !$select.length) {
										return;
								}
								if ($select.hasClass('select2-hidden-accessible')) {
										var initializedInstance = $select.data('select2');
										if (initializedInstance && initializedInstance.$container) {
												initializedInstance.$container.attr('data-searchable-select', '1');
										}
										return;
								}
								var placeholderText = $select.attr('data-placeholder') || $select.find('option[value=""]').first().text() || 'Select Value';
								$select.select2({
										width: '100%',
										placeholder: placeholderText,
										allowClear: !$select.prop('required'),
										minimumResultsForSearch: 0,
										dropdownCssClass: 'searchable-select-dropdown'
								});
								var instance = $select.data('select2');
								if (instance && instance.$container) {
										instance.$container.attr('data-searchable-select', '1');
								}
						};

						window.initAllSearchableSelects = function(scope){
								var $scope = scope ? $(scope) : $(document);
								$scope.find('select.searchable-select').each(function () {
										window.initSearchableSelect($(this));
								});
						};

						window.refreshSearchableSelect = function(selector){
								var $select = selector instanceof jQuery ? selector : $(selector);
								if (!$select.length) {
										return;
								}
								if (!$select.hasClass('select2-hidden-accessible')) {
										window.initSearchableSelect($select);
										return;
								}
								$select.trigger('change.select2');
						};

						$(document).off('mousedown.searchableSelect').on('mousedown.searchableSelect', '.select2-container[data-searchable-select="1"] .select2-selection--single', function (event) {
								var $container = $(this).closest('.select2-container');
								var $select = $container.prev('select.searchable-select');
								if (!$select.length || $select.prop('disabled') || $container.hasClass('select2-container--open')) {
										return;
								}
								event.preventDefault();
								$select.select2('open');
						});

						$(document).off('select2:open.searchableSelect').on('select2:open.searchableSelect', function () {
								var searchField = document.querySelector('.select2-container--open .select2-search__field');
								if (searchField) {
										searchField.focus();
										searchField.select();
								}
						});
				}

				$('.steps-validation').on('click','.delete', function(){
			    Swal.fire({
			      title: 'Are You Sure ?',
			      text: "This item will be permanently deleted!",
			      type: 'error',
			      showCancelButton: true,
			      confirmButtonColor: '#3085d6',
			      cancelButtonColor: '#d33',
			      confirmButtonText: 'Yes, Delete It !',
			      confirmButtonClass: 'btn btn-danger',
			      cancelButtonClass: 'btn btn-dark ml-1',
			      cancelButtonText: 'Cancel',
			      buttonsStyling: false,
			    }).then(function (result) {
			      if (result.value) {
			        $('#imagedata').val("");
                    if ($('#previewimagedata').length) {
                      $('#previewimagedata').attr('src', "#");
                    }
			      } else if (result.dismiss === Swal.DismissReason.cancel) {
			        Swal.fire({
			          title: 'Cancelled',
			          text: 'Your data is safe :)',
			          type: 'error',
			          confirmButtonClass: 'btn btn-success',
			        })
			      }
			    })
			  });
		</script>
		@stack('child-scripts')
		<script>
				if (typeof window.initAllSearchableSelects === 'function') {
						window.initAllSearchableSelects($('.steps-validation'));
				}
		</script>
		<script>
				$(".steps-validation").validate({
						ignore: 'input[type=hidden]:not(.select2-hidden-accessible)', // ignore hidden fields except select2-backed selects
						errorClass: 'danger',
						successClass: 'success',
						highlight: function (element, errorClass) {
								$(element).removeClass(errorClass);
						},
						unhighlight: function (element, errorClass) {
								$(element).removeClass(errorClass);
						},
						errorPlacement: function (error, element) {
								error.insertAfter(element);
						},
						rules: {
								email: {
										email: true
								}
						}
				});
		</script>
		@stack('bottom-child-scripts')
		<script src="{{asset('app-assets/js/scripts/forms/validation/form-validation.js')}}"></script>
@endsection
