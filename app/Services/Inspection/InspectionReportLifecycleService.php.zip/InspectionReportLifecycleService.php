<?php

namespace App\Services\Inspection;

use App\Models\Inspection\InspectionReport;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Schema;

class InspectionReportLifecycleService
{
    public function persistForOwner($reportOwner, array $attributes): bool
    {
        if (!is_object($reportOwner) || !method_exists($reportOwner, 'report')) {
            return false;
        }

        $report = $reportOwner->report()->first();
        if (!$report) {
            return false;
        }

        return $this->persistReport($report, $attributes);
    }

    public function persistReport(InspectionReport $report, array $attributes): bool
    {
        $reportableChanged = array_key_exists('reportable_id', $attributes) || array_key_exists('reportable_type', $attributes);
        $editorStateChanged = array_key_exists('user_id_edit', $attributes);
        $isDuplicatedClone = stripos((string) ($attributes['code'] ?? $report->code), 'duplicated') !== false
            || stripos((string) $report->code, 'duplicated') !== false;
        $isPublishTransition = ((int) ($attributes['publish'] ?? 0) === 1);

        if ($isPublishTransition && empty($attributes['user_id_approved'])) {
            $attributes['user_id_approved'] = $this->resolveInheritedApprovedBy($report);
        }

        if ($isDuplicatedClone && ($reportableChanged || $editorStateChanged) && !$isPublishTransition) {
            if (empty($attributes['user_id_approved'])) {
                $attributes['user_id_approved'] = $this->resolveInheritedApprovedBy($report);
            }

            $attributes['publish'] = null;
        }

        if ($isDuplicatedClone && $isPublishTransition) {
            $nextNaturalCode = $this->resolveNextNaturalCode(
                (int) $report->job_request_id,
                (int) $report->id
            );

            if ($nextNaturalCode !== '') {
                $attributes['code'] = $nextNaturalCode;
                $this->syncReportableCode(
                    (string) ($attributes['reportable_type'] ?? $report->reportable_type),
                    (int) ($attributes['reportable_id'] ?? $report->reportable_id),
                    $nextNaturalCode
                );
            }

            // Duplicated reports use the publish action as a finalize-to-review step:
            // they leave the duplicated code state, then return to approval queue.
            $attributes['publish'] = null;
            $attributes['user_id_approved'] = null;
        }

        return (bool) InspectionReport::query()
            ->whereKey($report->id)
            ->update($attributes);
    }

    public function createDuplicateRecord(InspectionReport $sourceReport, Model $duplicatedReportable, ?int $actorId = null): InspectionReport
    {
        return $duplicatedReportable->report()->create([
            'job_request_id' => $sourceReport->job_request_id,
            'code' => $sourceReport->code . ' - Duplicated',
            'status' => 1,
            'publish' => null,
            'user_id_approved' => $this->resolveInheritedApprovedBy($sourceReport),
            'sync' => 1,
            'user_id' => $actorId,
        ]);
    }

    public function markPublished(InspectionReport $report): bool
    {
        return $this->persistReport($report, [
            'publish' => 1,
            'user_id_approved' => $report->user_id_approved ?: $this->resolveInheritedApprovedBy($report),
        ]);
    }

    public function resolveInheritedApprovedBy(InspectionReport $sourceReport): ?int
    {
        $approvedBy = (int) ($sourceReport->user_id_approved ?? 0);
        if ($approvedBy > 0) {
            return $approvedBy;
        }

        $fallback = (int) ($sourceReport->user_id_edit ?: $sourceReport->user_id);
        if ($fallback > 0) {
            return $fallback;
        }

        return null;
    }

    public function resolveNextNaturalCode(int $jobRequestId, int $excludeReportId = 0): string
    {
        if ($jobRequestId <= 0) {
            return '';
        }

        $max = InspectionReport::query()
            ->where('job_request_id', $jobRequestId)
            ->when($excludeReportId > 0, function ($query) use ($excludeReportId) {
                $query->where('id', '!=', $excludeReportId);
            })
            ->where('code', 'not like', '%Duplicated%')
            ->pluck('code')
            ->map(function ($code) {
                if (preg_match('/(\d+)$/', (string) $code, $matches)) {
                    return (int) $matches[1];
                }

                return is_numeric($code) ? (int) $code : 0;
            })
            ->max();

        $next = ((int) $max) + 1;

        return $next > 999 ? (string) $next : str_pad((string) $next, 3, '0', STR_PAD_LEFT);
    }

    public function syncReportableCode(string $reportableType, int $reportableId, string $code): void
    {
        if ($reportableType === '' || $reportableId <= 0 || $code === '' || !class_exists($reportableType)) {
            return;
        }

        $reportable = $reportableType::query()->find($reportableId);
        if (!$reportable || !method_exists($reportable, 'getTable')) {
            return;
        }

        $table = (string) $reportable->getTable();
        if ($table === '' || !Schema::hasColumn($table, 'code')) {
            return;
        }

        if ((string) ($reportable->code ?? '') === $code) {
            return;
        }

        $reportable->forceFill(['code' => $code])->save();
    }
}
