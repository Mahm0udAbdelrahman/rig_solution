<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\Inspection\InspectionReport;
use App\Models\WorkFlow\JobRequest;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;

class PortalController extends Controller
{
    public function customerOverview()
    {
        return $this->renderOverview('customer');
    }

    public function customerReports()
    {
        return $this->renderReports('customer');
    }

    public function departmentOverview()
    {
        return $this->renderOverview('department');
    }

    public function departmentReports()
    {
        return $this->renderReports('department');
    }

    private function renderOverview(string $scope)
    {
        $jobRequests = $this->baseScopeQuery($scope)
            ->with([
                'clientDepartment:id,name',
                'inspection_reports' => function ($query) {
                    $query->with(['job_request:id,code', 'reportable'])
                        ->orderByDesc('updated_at');
                },
                'invoice.payments',
                'payments',
                'qutation',
                'packingSlip',
                'serviceTicket',
            ])
            ->orderByDesc('id')
            ->get();

        $publishedReports = $this->publishedReportsFromJobRequests($jobRequests);
        $invoiceSnapshots = $this->buildInvoiceSnapshots($jobRequests);
        $payments = $jobRequests->flatMap(function (JobRequest $jobRequest) {
            return $jobRequest->payments;
        })->sortByDesc(function ($payment) {
            return $payment->payment_date ?: optional($payment->created_at)->timestamp;
        })->values();

        $viewData = [
            'page_name' => 'Customer Overview',
            'portal_scope' => $scope,
            'portal_scope_label' => $scope === 'department' ? 'Department Portal' : 'Customer Portal',
            'overview_cards' => [
                [
                    'label' => 'Published Inspections',
                    'value' => $publishedReports->count(),
                    'note' => 'Certificates currently visible in the portal.',
                ],
                [
                    'label' => 'Open JCFs',
                    'value' => $jobRequests->count(),
                    'note' => 'Job control forms linked to this portal scope.',
                ],
                [
                    'label' => 'Unpaid Invoices',
                    'value' => $invoiceSnapshots->where('due_amount', '>', 0)->count(),
                    'note' => 'Invoices with remaining balance.',
                ],
                [
                    'label' => 'Received Payments',
                    'value' => number_format((float) $payments->sum(function ($payment) {
                        return (float) ($payment->amount ?? 0);
                    }), 2, '.', ','),
                    'note' => 'Total recorded payment amount.',
                ],
            ],
            'inspection_section_cards' => $this->buildInspectionSectionCards($publishedReports),
            'recent_published_reports' => $publishedReports
                ->sortByDesc(function (InspectionReport $report) {
                    return optional($report->updated_at)->timestamp ?: optional($report->created_at)->timestamp;
                })
                ->take(8)
                ->values(),
            'invoice_snapshots' => $invoiceSnapshots->take(8)->values(),
            'recent_payments' => $payments->take(8),
            'workflow_rows' => $this->buildWorkflowRows($jobRequests),
        ];

        return view('layouts.customer.overview', $viewData);
    }

    private function renderReports(string $scope)
    {
        $jobRequests = $this->baseScopeQuery($scope)
            ->with([
                'inspection_reports' => function ($query) {
                    $query->whereNotNull('publish')
                        ->where('publish', '!=', 0)
                        ->with(['job_request', 'reportable'])
                        ->orderByDesc('updated_at');
                },
            ])
            ->orderByDesc('id')
            ->get()
            ->filter(function (JobRequest $jobRequest) {
                return $jobRequest->inspection_reports->isNotEmpty();
            })
            ->values();

        return view('layouts.customer.reports.reports', [
            'page_name' => 'Published Inspection Certificates',
            'job_requests' => $jobRequests,
        ]);
    }

    private function baseScopeQuery(string $scope): Builder
    {
        $jobRequests = JobRequest::query();

        if ($scope === 'department') {
            $departmentId = (int) Auth::guard('clientDepartments')->id();
            return $jobRequests->where('client_department_id', $departmentId);
        }

        $customerId = (int) Auth::guard('customer')->id();
        return $jobRequests->where('client_id', $customerId);
    }

    private function publishedReportsFromJobRequests(Collection $jobRequests): Collection
    {
        return $jobRequests->flatMap(function (JobRequest $jobRequest) {
            return $jobRequest->inspection_reports;
        })->filter(function (InspectionReport $report) {
            return (int) ($report->publish ?? 0) !== 0 && $report->reportable !== null;
        })->values();
    }

    private function buildInspectionSectionCards(Collection $publishedReports): Collection
    {
        return $publishedReports
            ->groupBy(function (InspectionReport $report) {
                return $this->resolveInspectionSectionLabel((string) $report->reportable_type);
            })
            ->map(function (Collection $reports, string $label) {
                $latestReport = $reports->sortByDesc(function (InspectionReport $report) {
                    return optional($report->updated_at)->timestamp ?: optional($report->created_at)->timestamp;
                })->first();

                $latestCode = optional($latestReport)->code;
                if ($latestReport && optional($latestReport->job_request)->code) {
                    $latestCode = $latestReport->job_request->code.'/'.$latestReport->code;
                }

                return [
                    'label' => $label,
                    'count' => $reports->count(),
                    'latest_code' => $latestCode,
                ];
            })
            ->sortByDesc('count')
            ->values();
    }

    private function resolveInspectionSectionLabel(string $reportableType): string
    {
        $cleanType = str_replace('App\\Models\\Inspection\\', '', $reportableType);
        $segments = array_values(array_filter(explode('\\', $cleanType)));
        return $segments[0] ?? 'Inspection';
    }

    private function resolveInspectionTypeLabel(string $reportableType): string
    {
        $cleanType = str_replace('App\\Models\\Inspection\\', '', $reportableType);
        $segments = array_values(array_filter(explode('\\', $cleanType)));
        $className = end($segments) ?: 'Report';

        return trim(preg_replace('/(?<!^)[A-Z]/', ' $0', $className));
    }

    private function buildInvoiceSnapshots(Collection $jobRequests): Collection
    {
        return $jobRequests
            ->map(function (JobRequest $jobRequest) {
                $invoice = $jobRequest->invoice;
                if (!$invoice) {
                    return null;
                }

                $paidAmount = (float) $invoice->payments->sum(function ($payment) {
                    return (float) ($payment->amount ?? 0);
                });
                $totalAmount = (float) ($invoice->total ?? 0);
                $dueAmount = max($totalAmount - $paidAmount, 0);

                return [
                    'job_request_code' => $jobRequest->code,
                    'invoice_code' => $invoice->code,
                    'invoice_type' => (string) ($invoice->invoice_company_type ?? ''),
                    'total_amount' => $totalAmount,
                    'paid_amount' => $paidAmount,
                    'due_amount' => $dueAmount,
                    'created_at' => $invoice->created_at,
                ];
            })
            ->filter()
            ->sortByDesc(function (array $invoice) {
                return optional($invoice['created_at'])->timestamp;
            })
            ->values();
    }

    private function buildWorkflowRows(Collection $jobRequests): Collection
    {
        return $jobRequests
            ->map(function (JobRequest $jobRequest) {
                $publishedCount = $jobRequest->inspection_reports
                    ->filter(function (InspectionReport $report) {
                        return (int) ($report->publish ?? 0) !== 0;
                    })
                    ->count();

                return [
                    'job_request_code' => $jobRequest->code,
                    'department' => optional($jobRequest->clientDepartment)->name ?: '-',
                    'location' => $jobRequest->deploc ?: ($jobRequest->work_location ?: '-'),
                    'quotation' => $jobRequest->qutation !== null,
                    'packing_slip' => $jobRequest->packingSlip !== null,
                    'service_ticket' => $jobRequest->serviceTicket !== null,
                    'invoice' => $jobRequest->invoice !== null,
                    'payment' => $jobRequest->payments->isNotEmpty(),
                    'published_inspections' => $publishedCount,
                ];
            })
            ->sortByDesc('job_request_code')
            ->values();
    }
}
