<?php

namespace App\Models\Inspection\Tubular;

use App\Models\GeneralInfo\FooterValue;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\WorkFlow\JobRequest;
use App\Models\Inspection\InspectionReport;
use App\Traits\HasInspectionLogo;

class StabilizerInspection extends Model
{
    use HasFactory, HasInspectionLogo;

    protected $fillable = [
        'job_request_id',
        'code',
        'sync',
        'updated',
        'user_id_approved',
        'examination_date',
        'edition',
        'specification',
        'other_specification',
        'inspection_method',
        'other_inspection_method',
        'equipment_no',
        'material_description',
        'tool_number',
        'condition',
        'inspection_applied',
//        'dimensions_unit',
//        'front',
//        'middle',
//        'back',
//        'input_a',
//        'input_b',
//        'input_c',
//        'input_d',
//        'input_e',
//        'input_e',
        'dimensions_data',
        'pipe_type',
        'inspection_data',
        'body_condition',
        'blades_condition',
        'hf_condition',
        'blades_diameter',
        'comment'
    ];

    protected $dates = ['examination_date'];

    protected $hidden = ['created_at', 'updated_at'];

    public static $INSPECTION_METHOD = ['WET', 'DRY', 'EAI', 'EMI', 'UT-EAI', 'VTI', 'WT', 'TGI'];

    public static $EQUIPMENTS = ['UV light', 'AC yoke', 'DC coil', 'EMI Unit', 'UT-EA', 'WT'];

    public static $PIPE_TYPE_OPTIONS = [
        'type_1'=> 'BOX - BOX',
        'type_2'=> 'BOX - PIN',
    ];

    public function job_request()
    {
        return $this->belongsTo(JobRequest::class);
    }

    public function report()
    {
        return $this->morphOne(InspectionReport::class, 'reportable');
    }

    // Mutators to JSON-encode array fields
    public function setSpecificationAttribute($value)
    {
        $this->attributes['specification'] = json_encode($value);
    }

    public function setInspectionMethodAttribute($value)
    {
        $this->attributes['inspection_method'] = json_encode($value);
    }

    public function setEquipmentNoAttribute($value)
    {
        $this->attributes['equipment_no'] = json_encode($value);
    }

    public function setInspectionDataAttribute($value)
    {
        $this->attributes['inspection_data'] = json_encode($value);
    }

    public function setDimensionsDataAttribute($value)
    {
        $this->attributes['dimensions_data'] = json_encode($value);
    }

    // Accessors to JSON-decode array fields
    public function getSpecificationAttribute($value)
    {
        $decodedArray = json_decode($value ?? '[]', true);
        if (!is_array($decodedArray)) {
            $decodedArray = [];
        }

        // Check if 'S-008' code for other specification exists in the array
        if (($key = array_search('S-008', $decodedArray, true)) !== false) {
            // Remove 'S-008' from its current position
            unset($decodedArray[$key]);
            // Push 'S-008' to the end of the array
            $decodedArray[] = 'S-008';
        }

        return array_values($decodedArray);
    }

    public function getInspectionMethodAttribute($value)
    {
        $decodedArray = json_decode($value ?? '[]', true);
        return is_array($decodedArray) ? $decodedArray : [];
    }

    public function getEquipmentNoAttribute($value)
    {
        $decodedArray = json_decode($value ?? '[]', true);
        return is_array($decodedArray) ? $decodedArray : [];
    }

    public function getInspectionDataAttribute($value)
    {
        $defaults = [];
        for ($i = 1; $i <= 20; $i++) {
            $defaults['input_'.$i] = '';
        }

        $decodedArray = json_decode($value ?? '[]', true);
        if (!is_array($decodedArray)) {
            return $defaults;
        }

        return array_merge($defaults, $decodedArray);
    }

    public function getDimensionsDataAttribute($value)
    {
        $defaults = [
            'unit' => '',
            'front' => '',
            'middle' => '',
            'back' => '',
            'input_a' => '',
            'input_b' => '',
            'input_c' => '',
            'input_d' => '',
            'input_e' => '',
        ];

        $decodedArray = json_decode($value ?? '[]', true);
        if (!is_array($decodedArray)) {
            return $defaults;
        }

        return array_merge($defaults, $decodedArray);
    }

    // Accessor method to format examination_date attribute
    public function getExaminationDateAttribute($value)
    {
        $date = new Carbon($value);
        return $value ? $date->format('d-m-Y') : null;
    }

    // Define the virtual attribute accessor for related Footer Values
    public function getFooterValuesAttribute()
    {
        $footerValues = FooterValue::query()
            ->where('related_inspection', $this->getMorphClass())
            ->get()->first();
        return $footerValues;
    }
}
