<?php

namespace App\Models\Inspection\Ndt;

use App\Models\GeneralInfo\FooterValue;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

use App\Models\WorkFlow\JobRequest;
use App\Models\Inspection\InspectionReport;
use App\Traits\HasInspectionLogo;

class WitnessHydro extends Model
{
    use HasFactory, HasInspectionLogo;

    protected $fillable = [
       'job_request_id',
       'nwhr_2',
       'code',
       'nwhr_6',
       'nwhr_7',
			 'nwhr_8',
       'nwhr_9',
       'nwhr_10',
       // 'nwhr_11',
       // 'nwhr_12',
       'acceptance',
       'desc',
       'nwhr_15',
       'nwhr_16',
       'nwhr_17',
       'nwhr_18',
       'nwhr_19',
       'nwhr_20',
       'nwhr_21',
       'nwhr_22',
       'nwhr_23',
       'nwhr_24',
       'nwhr_25',
       'nwhr_26',
       'nwhr_27',
       'nwhr_28',
       'nwhr_29',
       'nwhr_30',
       'nwhr_31',
       'nwhr_32',
       'nwhr_33',
       'nwhr_34',
       'nwhr_35',
       'nwhr_36',
       'nwhr_37',
       'nwhr_38',
       'nwhr_39',
     ];

     protected $hidden = ['created_at', 'updated_at'];

     public function job_request()
     {
         return $this->belongsTo(JobRequest::class);
     }

     public function report()
     {
         return $this->morphOne(InspectionReport::class, 'reportable');
     }

     public function checkbox_yes($checkbox_id){
       if(strstr($checkbox_id, '_y')){
         return "checked";
       }
     }

     public function checkbox_no($checkbox_id){
       if(strstr($checkbox_id, '_n')){
         return "checked";
       }
     }

    // Define the virtual attribute accessor for related Footer Values
    public function getFooterValuesAttribute()
    {
        $footerValues = FooterValue::query()
            ->where('related_inspection', $this->getMorphClass())
            ->get()->first();
        return $footerValues;
    }
}
