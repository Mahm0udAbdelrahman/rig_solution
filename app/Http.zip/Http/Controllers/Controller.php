<?php

namespace App\Http\Controllers;

use App\Models\Inspection\InspectionReport;
use App\Models\WorkFlow\FileManager;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Storage;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function action_message($type, $page_name)
	{
		$action = '';
		$message = '';
		switch ($type)
		{
			case 0:
				$action = ' Created ';
				break;
			case 1:
				$action = ' Updated ';
				break;
			case 2:
				$action = ' Deleted ';
				break;
		}
		$message = $page_name.$action.'Successfully !';
		return $message;
	}

	public function page_name($type, $page_name)
	{
		$action = '';
		$message = '';
		if ($type == 'All')
		{
			$message = 'All '.$page_name.'s';
		}
		else
		{
			switch ($type)
			{
				case 0:
				$action = 'Create ';
				break;
				case 1:
				$action = 'Edit ';
				break;
			}
			$message = $action.$page_name;
		}
		return $message;
	}

	public function remove_snap_shots_pdf($pdf, $snap)
	{
		$message = "";
		if (\Storage::disk('public')->exists($snap))
		{
			\Storage::disk('public')->deleteDirectory($snap);
			FileManager::query()->where('disk', 'public')->where('path', 'like', trim($snap, '/').'%')->delete();
			$message .= "Snap , ";
		}
		if (\Storage::disk('public')->exists($pdf))
		{
			\Storage::disk('public')->delete($pdf);
			FileManager::query()->where('disk', 'public')->where('path', ltrim($pdf, '/'))->delete();
			$message .= "PDF , ";
		}

		return $message;
	}

	public function check_if_report_edit($report, $current_report)
	{
		$have_edit = new \stdClass();
		
		$select_report = $report::Select('id', 'created_at')
									->Where('job_request_id', $current_report->job_request->id)
									->Where('code', $current_report->code)
									->where('code', 'NOT LIKE', '%Duplicated%');

		$reports_related = $select_report->get();

        if (count($reports_related) === 0) {
            // handle case duplicated and not published yet
            // there only one related report but it has code duplicated
            // so need to omit code not like duplicated condition
            $select_report = $report::Select('id', 'created_at')
                ->Where('job_request_id', $current_report->job_request->id)
                ->Where('code', $current_report->code);
            $reports_related = $select_report->get();
        }

		if(count($reports_related) != 0)
		{	
			$have_edit->default = $select_report->latest()->first()->report;	

			foreach($reports_related as $key => $report_data){
				$have_edit->edited[$key]['id'] = $report_data->id;
				$have_edit->edited[$key]['route'] = route(\Route::currentRouteName(), $report_data->id);
				$have_edit->edited[$key]['edit_at'] = $report_data->created_at->toDateString();
				$have_edit->edited[$key]['edit_by'] = '';
			}
		}

		return $have_edit;
	}

	public function check_edited_reports_for_delete($report)
	{
		$reports = $report::Where('job_request_id', $report->job_request->id)
			->Where('code', $report->code)
			->get();
		
		foreach ($reports as $key => $report) {
			$report->forceDelete();
		}	

		return true;
	}

	public function getUploadedCodes($dir, $returnArr = false) {
        $path = Storage::disk('public')->path('pdf/inspection/'.trim($dir, '/'));
        $pathes = glob($path.'/*/*.pdf') ?: [];

        array_walk($pathes, function (&$item) use ($path) {
            $prefix = rtrim($path, DIRECTORY_SEPARATOR).DIRECTORY_SEPARATOR;
            $item = str_replace($prefix, '', $item);
            $item = str_replace(['\\', '/'], '/', $item);
            $item = preg_replace('/\.pdf$/i', '', $item);
        });

        if ($returnArr) {
            return $pathes;
        }

        return empty($pathes) ? "''" : "'" . implode("','", $pathes) . "'";
    }

    public function applyInspectionGlobalSearch($query, $searchValue, $inspectionDataColumn = 'inspection_data')
    {
        $searchValue = trim((string) $searchValue);
        if ($searchValue === '') {
            return;
        }

        $model = method_exists($query, 'getModel') ? $query->getModel() : null;
        $table = $model && method_exists($model, 'getTable') ? (string) $model->getTable() : '';

        $searchDataColumn = $this->resolveInspectionSearchColumn($query, $inspectionDataColumn, $table);
        $searchCodeColumn = $this->resolveInspectionSearchColumn($query, 'code', $table);

        $query->where(function ($builder) use ($searchValue, $searchDataColumn, $searchCodeColumn) {
            $hasSearchClause = false;

            if ($searchDataColumn !== null) {
                $builder->where($searchDataColumn, 'like', "%{$searchValue}%");
                $hasSearchClause = true;
            }

            if ($searchCodeColumn !== null) {
                if ($hasSearchClause) {
                    $builder->orWhere($searchCodeColumn, 'like', "%{$searchValue}%");
                } else {
                    $builder->where($searchCodeColumn, 'like', "%{$searchValue}%");
                }
                $hasSearchClause = true;
            }

            if (method_exists($builder, 'orWhereHas')) {
                if ($hasSearchClause) {
                    $builder->orWhereHas('job_request', function ($jobRequestQuery) use ($searchValue) {
                        $jobRequestQuery->where('code', 'like', "%{$searchValue}%");
                    });
                } else {
                    $builder->whereHas('job_request', function ($jobRequestQuery) use ($searchValue) {
                        $jobRequestQuery->where('code', 'like', "%{$searchValue}%");
                    });
                }
            }
        });
    }

    public function applyInspectionApprovalPresetFilter($query, ?string $smartPreset = null): void
    {
        $preset = $this->normalizeInspectionPreset($smartPreset ?? request('smart_preset', ''));
        if (!in_array($preset, ['approved', 'unapproved', 'need_publish', 'published', 'unpublished'], true)) {
            $this->applyInspectionRequestedOrdering($query);
            return;
        }

        if (method_exists($query, 'whereHas')) {
            $query->whereHas('report', function ($reportQuery) use ($preset) {
                $this->applyInspectionPresetToReportQuery($reportQuery, $preset);
            });
            $this->applyInspectionRequestedOrdering($query);
            return;
        }

        if ($preset === 'approved') {
            $query->whereNotNull('inspection_reports.user_id_approved');
            $this->applyInspectionRequestedOrdering($query);
            return;
        }

        if ($preset === 'unapproved') {
            $query->whereNull('inspection_reports.user_id_approved');
            $this->applyInspectionRequestedOrdering($query);
            return;
        }

        if ($preset === 'published') {
            $this->applyPublishedConstraint($query, 'inspection_reports.publish');
            $this->applyInspectionRequestedOrdering($query);
            return;
        }

        if ($preset === 'need_publish') {
            $query->whereNotNull('inspection_reports.user_id_approved');
            $this->applyUnpublishedConstraint($query, 'inspection_reports.publish');
            $this->applyInspectionRequestedOrdering($query);
            return;
        }

        $this->applyUnpublishedConstraint($query, 'inspection_reports.publish');
        $this->applyInspectionRequestedOrdering($query);
    }

    public function inspectionApprovalStatusValueByRow($row): string
    {
        return $this->resolveInspectionApprovedByUserIdFromRow($row) ? 'approved' : 'unapproved';
    }

    public function inspectionPublishStatusValueByRow($row): string
    {
        return $this->resolveInspectionPublishValueFromRow($row) ? 'published' : 'unpublished';
    }

    public function inspectionRevisionCountValueByRow($row): int
    {
        $meta = $this->resolveInspectionRevisionMetaFromRow($row);
        if (!$meta) {
            return 1;
        }

        return $this->resolveInspectionRevisionCount($meta['reportable_type'], $meta['job_request_id'], $meta['code']);
    }

    private function resolveInspectionApprovedByUserIdFromRow($row): ?int
    {
        if (is_object($row)) {
            if (isset($row->user_id_approved) && $row->user_id_approved) {
                return (int) $row->user_id_approved;
            }

            if (isset($row->report_user_id_approved) && $row->report_user_id_approved) {
                return (int) $row->report_user_id_approved;
            }

            $relatedReport = $this->resolveInspectionReportRelationFromRow($row);
            if ($relatedReport && isset($relatedReport->user_id_approved) && $relatedReport->user_id_approved) {
                return (int) $relatedReport->user_id_approved;
            }

            if (isset($row->report_id) && $row->report_id) {
                return $this->resolveInspectionApprovedByReportId((int) $row->report_id);
            }
        }

        if (is_array($row)) {
            if (!empty($row['user_id_approved'])) {
                return (int) $row['user_id_approved'];
            }

            if (!empty($row['report_user_id_approved'])) {
                return (int) $row['report_user_id_approved'];
            }

            if (!empty($row['report']['user_id_approved'])) {
                return (int) $row['report']['user_id_approved'];
            }

            if (!empty($row['report_id'])) {
                return $this->resolveInspectionApprovedByReportId((int) $row['report_id']);
            }
        }

        return null;
    }

    private function resolveInspectionApprovedByReportId(int $reportId): ?int
    {
        static $approvalCache = [];

        if ($reportId <= 0) {
            return null;
        }

        if (array_key_exists($reportId, $approvalCache)) {
            return $approvalCache[$reportId];
        }

        $approvedBy = InspectionReport::query()
            ->where('id', $reportId)
            ->value('user_id_approved');

        $approvalCache[$reportId] = $approvedBy ? (int) $approvedBy : null;

        return $approvalCache[$reportId];
    }

    private function resolveInspectionPublishValueFromRow($row): ?int
    {
        if (is_object($row)) {
            if (isset($row->publish) && $row->publish !== null) {
                return (int) $row->publish;
            }

            if (isset($row->report_publish) && $row->report_publish !== null) {
                return (int) $row->report_publish;
            }

            $relatedReport = $this->resolveInspectionReportRelationFromRow($row);
            if ($relatedReport && isset($relatedReport->publish) && $relatedReport->publish !== null) {
                return (int) $relatedReport->publish;
            }

            if (isset($row->report_id) && $row->report_id) {
                return $this->resolveInspectionPublishByReportId((int) $row->report_id);
            }
        }

        if (is_array($row)) {
            if (array_key_exists('publish', $row) && $row['publish'] !== null) {
                return (int) $row['publish'];
            }

            if (array_key_exists('report_publish', $row) && $row['report_publish'] !== null) {
                return (int) $row['report_publish'];
            }

            if (isset($row['report']) && is_array($row['report']) && array_key_exists('publish', $row['report']) && $row['report']['publish'] !== null) {
                return (int) $row['report']['publish'];
            }

            if (!empty($row['report_id'])) {
                return $this->resolveInspectionPublishByReportId((int) $row['report_id']);
            }
        }

        return null;
    }

    private function resolveInspectionPublishByReportId(int $reportId): ?int
    {
        static $publishCache = [];

        if ($reportId <= 0) {
            return null;
        }

        if (array_key_exists($reportId, $publishCache)) {
            return $publishCache[$reportId];
        }

        $publish = InspectionReport::query()
            ->where('id', $reportId)
            ->value('publish');

        $publishCache[$reportId] = $publish !== null ? (int) $publish : null;

        return $publishCache[$reportId];
    }

    private function resolveInspectionRevisionMetaFromRow($row): ?array
    {
        if (is_object($row)) {
            if ($row instanceof Model
                && isset($row->job_request_id, $row->code)
                && $row->job_request_id
                && trim((string) $row->code) !== '') {
                return [
                    'reportable_type' => get_class($row),
                    'job_request_id' => (int) $row->job_request_id,
                    'code' => trim((string) $row->code),
                ];
            }

            $relatedReport = $this->resolveInspectionReportRelationFromRow($row);
            if ($relatedReport
                && isset($relatedReport->reportable_type, $relatedReport->job_request_id, $relatedReport->code)
                && $relatedReport->reportable_type
                && $relatedReport->job_request_id
                && trim((string) $relatedReport->code) !== '') {
                return [
                    'reportable_type' => (string) $relatedReport->reportable_type,
                    'job_request_id' => (int) $relatedReport->job_request_id,
                    'code' => trim((string) $relatedReport->code),
                ];
            }

            if (isset($row->report_id) && $row->report_id) {
                return $this->resolveInspectionRevisionMetaByReportId((int) $row->report_id);
            }
        }

        if (is_array($row)) {
            if (!empty($row['reportable_type']) && !empty($row['job_request_id']) && !empty($row['code'])) {
                return [
                    'reportable_type' => (string) $row['reportable_type'],
                    'job_request_id' => (int) $row['job_request_id'],
                    'code' => trim((string) $row['code']),
                ];
            }

            if (!empty($row['report']) && is_array($row['report'])
                && !empty($row['report']['reportable_type'])
                && !empty($row['report']['job_request_id'])
                && !empty($row['report']['code'])) {
                return [
                    'reportable_type' => (string) $row['report']['reportable_type'],
                    'job_request_id' => (int) $row['report']['job_request_id'],
                    'code' => trim((string) $row['report']['code']),
                ];
            }

            if (!empty($row['report_id'])) {
                return $this->resolveInspectionRevisionMetaByReportId((int) $row['report_id']);
            }
        }

        return null;
    }

    private function resolveInspectionReportRelationFromRow($row): ?Model
    {
        if (!is_object($row) || !($row instanceof Model)) {
            return null;
        }

        try {
            $report = $row->getRelationValue('report');
        } catch (\Throwable $e) {
            $report = null;
        }

        return $report instanceof Model ? $report : null;
    }

    private function resolveInspectionRevisionMetaByReportId(int $reportId): ?array
    {
        static $metaCache = [];

        if ($reportId <= 0) {
            return null;
        }

        if (array_key_exists($reportId, $metaCache)) {
            return $metaCache[$reportId];
        }

        $report = InspectionReport::query()
            ->select('reportable_type', 'job_request_id', 'code')
            ->where('id', $reportId)
            ->first();

        if (!$report || !$report->reportable_type || !$report->job_request_id || trim((string) $report->code) === '') {
            $metaCache[$reportId] = null;
            return null;
        }

        $metaCache[$reportId] = [
            'reportable_type' => (string) $report->reportable_type,
            'job_request_id' => (int) $report->job_request_id,
            'code' => trim((string) $report->code),
        ];

        return $metaCache[$reportId];
    }

    private function resolveInspectionRevisionCount(string $reportableType, int $jobRequestId, string $code): int
    {
        static $countCache = [];

        $reportableType = trim($reportableType);
        $code = trim($code);
        if ($reportableType === '' || $jobRequestId <= 0 || $code === '') {
            return 1;
        }

        $cacheKey = $reportableType.'|'.$jobRequestId.'|'.$code;
        if (array_key_exists($cacheKey, $countCache)) {
            return $countCache[$cacheKey];
        }

        if (!class_exists($reportableType) || !is_subclass_of($reportableType, Model::class)) {
            $countCache[$cacheKey] = 1;
            return 1;
        }

        /** @var class-string<Model> $reportableType */
        $model = new $reportableType();
        $table = method_exists($model, 'getTable') ? (string) $model->getTable() : '';

        if ($table === ''
            || !Schema::hasColumn($table, 'job_request_id')
            || !Schema::hasColumn($table, 'code')) {
            $countCache[$cacheKey] = 1;
            return 1;
        }

        $count = $reportableType::query()
            ->where('job_request_id', $jobRequestId)
            ->where('code', $code)
            ->where('code', 'NOT LIKE', '%Duplicated%')
            ->count();

        $countCache[$cacheKey] = max(1, (int) $count);

        return $countCache[$cacheKey];
    }

    private function applyInspectionRequestedOrdering($query): void
    {
        $smartSortColumn = trim((string) request('smart_sort_column', ''));
        $orderDirection = strtolower((string) request('smart_sort_dir', request('order.0.dir', 'desc')));
        if (!in_array($orderDirection, ['asc', 'desc'], true)) {
            $orderDirection = 'desc';
        }

        $columnName = $smartSortColumn;
        if ($columnName === '') {
            $orderIndex = request('order.0.column');
            if ($orderIndex === null || $orderIndex === '') {
                return;
            }
            $columnName = (string) (request("columns.$orderIndex.name") ?: request("columns.$orderIndex.data"));
        }

        if ($columnName === '' || in_array($columnName, ['action', 'approval_status', 'publish_status', 'revision_count'], true)) {
            return;
        }

        if (method_exists($query, 'reorder')) {
            $query->reorder();
        }

        $model = method_exists($query, 'getModel') ? $query->getModel() : null;
        $table = $model && method_exists($model, 'getTable') ? (string) $model->getTable() : '';

        if ($table !== '') {
            if (in_array($columnName, ['code', 'report_code'], true)
                && Schema::hasColumn($table, 'job_request_id')
                && Schema::hasColumn($table, 'code')) {
                $baseCodeExpression = "TRIM(SUBSTRING_INDEX({$table}.code, ' - Duplicated', 1))";
                $duplicatedRankExpression = "CASE WHEN {$table}.code LIKE '%Duplicated%' THEN 1 ELSE 0 END";

                $query->orderBy(
                    DB::table('job_requests')
                        ->select('code')
                        ->whereColumn('job_requests.id', $table.'.job_request_id')
                        ->limit(1),
                    $orderDirection
                );
                $query->orderByRaw("{$baseCodeExpression} {$orderDirection}");
                $query->orderByRaw("{$duplicatedRankExpression} asc");
                $query->orderBy($table.'.code', $orderDirection);
                return;
            }

            if (in_array($columnName, ['deploc', 'work_location', 'location'], true)
                && Schema::hasColumn($table, 'job_request_id')) {
                $query->orderBy(
                    DB::table('job_requests')
                        ->select('deploc')
                        ->whereColumn('job_requests.id', $table.'.job_request_id')
                        ->limit(1),
                    $orderDirection
                );
                return;
            }

            if ($columnName === 'client_department' && Schema::hasColumn($table, 'job_request_id')) {
                $query->orderBy(
                    DB::table('job_requests')
                        ->leftJoin('client_departments', 'client_departments.id', '=', 'job_requests.client_department_id')
                        ->select('client_departments.name')
                        ->whereColumn('job_requests.id', $table.'.job_request_id')
                        ->limit(1),
                    $orderDirection
                );
                return;
            }

            if (in_array($columnName, ['client', 'client_supplier'], true)
                && Schema::hasColumn($table, 'job_request_id')) {
                $query->orderBy(
                    DB::table('job_requests')
                        ->leftJoin('clients', 'clients.id', '=', 'job_requests.client_id')
                        ->leftJoin('suppliers', 'suppliers.id', '=', 'job_requests.supplier_id')
                        ->selectRaw('COALESCE(clients.name, suppliers.name)')
                        ->whereColumn('job_requests.id', $table.'.job_request_id')
                        ->limit(1),
                    $orderDirection
                );
                return;
            }

            if (Schema::hasColumn($table, $columnName)) {
                $query->orderBy($table.'.'.$columnName, $orderDirection);
                return;
            }
        }

        $selectedAliases = $this->extractSelectedAliases($query);
        if (in_array($columnName, $selectedAliases, true) && preg_match('/^[A-Za-z0-9_]+$/', $columnName)) {
            $query->orderBy($columnName, $orderDirection);
        }
    }

    private function extractSelectedAliases($query): array
    {
        $queryObject = method_exists($query, 'getQuery') ? $query->getQuery() : $query;
        $columns = is_object($queryObject) && property_exists($queryObject, 'columns') ? ($queryObject->columns ?: []) : [];

        $aliases = [];
        foreach ($columns as $column) {
            $columnSql = '';
            if (is_string($column)) {
                $columnSql = $column;
            } elseif (is_object($column) && method_exists($column, 'getValue')) {
                $columnSql = (string) $column->getValue(DB::connection()->getQueryGrammar());
            } elseif (is_object($column) && method_exists($column, '__toString')) {
                $columnSql = (string) $column;
            }

            if ($columnSql === '') {
                continue;
            }

            if (preg_match('/\bas\s+`?([A-Za-z0-9_]+)`?/i', $columnSql, $matches)) {
                $aliases[] = $matches[1];
                continue;
            }

            $normalized = trim(str_replace('`', '', $columnSql));
            if (preg_match('/^[A-Za-z0-9_]+$/', $normalized)) {
                $aliases[] = $normalized;
            }
        }

        return array_values(array_unique($aliases));
    }

    private function normalizeInspectionPreset(?string $preset): string
    {
        $normalized = strtolower(trim((string) $preset));
        $normalized = str_replace([' ', '-'], '_', $normalized);

        if (in_array($normalized, ['aprroved'], true)) {
            return 'approved';
        }

        if (in_array($normalized, ['not_approved', 'notapproved'], true)) {
            return 'unapproved';
        }

        if (in_array($normalized, ['not_aprroved', 'notaprroved'], true)) {
            return 'unapproved';
        }

        if (in_array($normalized, ['need_approve', 'needapprove'], true)) {
            return 'unapproved';
        }

        if (in_array($normalized, ['punlished'], true)) {
            return 'published';
        }

        if (in_array($normalized, ['not_published', 'notpublished'], true)) {
            return 'unpublished';
        }

        if (in_array($normalized, ['not_punlished', 'notpunlished'], true)) {
            return 'unpublished';
        }

        if (in_array($normalized, ['need_publish', 'needpublish'], true)) {
            return 'need_publish';
        }

        return $normalized;
    }

    private function applyInspectionPresetToReportQuery($reportQuery, string $preset): void
    {
        if ($preset === 'approved') {
            $reportQuery->whereNotNull('user_id_approved');
            return;
        }

        if ($preset === 'unapproved') {
            $reportQuery->whereNull('user_id_approved');
            return;
        }

        if ($preset === 'published') {
            $this->applyPublishedConstraint($reportQuery, 'publish');
            return;
        }

        if ($preset === 'need_publish') {
            $reportQuery->whereNotNull('user_id_approved');
            $this->applyUnpublishedConstraint($reportQuery, 'publish');
            return;
        }

        if ($preset === 'unpublished') {
            $this->applyUnpublishedConstraint($reportQuery, 'publish');
        }
    }

    private function applyPublishedConstraint($query, string $column): void
    {
        $query->whereNotNull($column)
            ->where($column, '!=', 0);
    }

    private function applyUnpublishedConstraint($query, string $column): void
    {
        $query->where(function ($builder) use ($column) {
            $builder->whereNull($column)
                ->orWhere($column, 0);
        });
    }

    protected function buildInspectionUnpublishedActionButtons($row, string $modelClass, int $modelId, string $showRoute, string $publishRoute, ?string $editRoute = null): string
    {
        $approvalStatus = $this->inspectionApprovalStatusValueByRow($row);
        $record = class_exists($modelClass) ? $modelClass::find($modelId) : null;

        if ($approvalStatus === 'approved') {
            $canPublish = auth()->user()->can('create', $modelClass)
                || ($record && auth()->user()->can('create', $record));

            return $canPublish
                ? '<a href="' . route($publishRoute, $modelId) . '" class="btn btn-icon btn-info mr-1">Publish</a>'
                : '';
        }

        $btn = '<a class="btn btn-dark mr-1" href="' . route($showRoute, $modelId) . '">Open Report</a>';

        if ($editRoute !== null && $record && auth()->user()->can('update', $record)) {
            $btn .= '<a href="' . route($editRoute, $modelId) . '" class="btn btn-icon btn-info mr-1"><i class="la la-pencil"></i></a>';
        }

        return $btn;
    }

    private function resolveInspectionSearchColumn($query, string $columnName, string $defaultTable = ''): ?string
    {
        $columnName = trim($columnName);
        if ($columnName === '') {
            return null;
        }

        $candidate = str_replace('`', '', $columnName);
        if (strpos($candidate, '.') !== false) {
            [$table, $column] = explode('.', $candidate, 2);
            if ($table !== '' && $column !== '' && Schema::hasColumn($table, $column)) {
                return $table.'.'.$column;
            }
            return null;
        }

        if ($defaultTable !== '' && Schema::hasColumn($defaultTable, $candidate)) {
            return $defaultTable.'.'.$candidate;
        }

        $aliases = $this->extractSelectedAliases($query);
        if (in_array($candidate, $aliases, true) && preg_match('/^[A-Za-z0-9_]+$/', $candidate)) {
            return $candidate;
        }

        return null;
    }

}
