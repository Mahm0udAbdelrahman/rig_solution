<?php

namespace App\Http\Controllers\Dashboard\Persons;
use App\Http\Controllers\Controller;

// Illuminate\Http
use Illuminate\Http\Request;

// Illuminate\Support
// use Illuminate\Support\Facades\Hash;
// use Illuminate\Support\Facades\Crypt;
// use Illuminate\Support\Facades\Storage;

// App\Models
use App\Models\Persons\Client;
use App\Models\User;

// Other
use DB, DataTables, Auth, Storage, Crypt, Hash;

class ClientController extends Controller
{
    public $page_name = 'Client';
    public $person_type = 'c';

    public function __construct()
    {
	      $this->middleware('auth');
	      $this->authorizeResource(Client::class, 'client');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $clients = Client::count();
        return view('layouts.persons.client.index', [
            'page_name' => $this->page_name('All', $this->page_name),
            'clients' => $clients,
            'route' => 'client',
            'model' => 'App\Models\Persons\Client',
            'type' => $this->person_type,
        ]);
    }

    public function getDataForDataTable()
		{
        $data = Client::query();
        return  Datatables::eloquent($data)
              ->addColumn('action', function ($row) {
                    $btn = "";

                    if (Auth::user()->can('view', Client::find($row->id)))
                    {
                        $btn .= '<a href="'.route('client.show', $row->id).'" class="btn btn-icon btn-success mr-1 btn11">Contact Persons</a>';
                    }

                    if (Auth::user()->can('update', Client::find($row->id)))
                    {
                        $btn .= '<a href="'.route('client.edit', $row->id).'" class="btn btn-icon btn-info mr-1"><i class="la la-pencil"></i></a>';
                    }

                    if (Auth::user()->can('delete', Client::find($row->id)))
                    {
                        $btn .= '<button type="button" data-id="'.$row->id.'" class="btn btn-icon btn-danger delete"><i class="la la-trash"></i></button>';
                    }
                    if ($btn === '') {
                        return '';
                    }
                    return '<div class="wf-inline-actions">'.$btn.'</div>';
                })
              ->editColumn('logo', function($row){
										return '<img class="media-object" src="'.Storage::url('persons/clients/').$row->logo.'" alt="" width="64">';
								})
              ->editColumn('code', function($row){
                    $report_code = "";
                    if(Auth::user()->can('view', Client::find($row->id)))
                    {
                        $report_code .= "<a href=".route('client.show', $row->id).">";
                    }

                    $report_code .= $row->code;

                    if(Auth::user()->can('view', Client::find($row->id)))
                    {
                        $report_code .= "</a>";
                    }
                    return $report_code;
								})
              ->rawColumns(['logo', 'code' ,'action'])
              ->make('true');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $last = Client::orderBy('id', 'desc')->latest()->first();
        $last_id = 'CLI-000';
        if (!$last)
        {
            $last_id;
        }
        else
        {
            $last_id = $last->code;
        }
        return view('layouts.persons.client.add', [
            'page_name' => $this->page_name(0, $this->page_name),
            'last_id' => $last_id,
            'route' => 'client.store'
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $path = $request->file('logo');
        $path_crypt = NULL;
        if ($path != NULL)
        {
            $path_crypt = Crypt::encryptString($path->getClientOriginalName());
            $store = $path->storeAs(
                'public/persons/clients',
                $path_crypt
            );
        }

        $store_client = Client::create([
            'code' => $request->code,
            'name' => $request->uname,
            'password' => Hash::make($request->upassword),
            'email' => $request->uemail,
            'tel' => $request->utel,
            'tax_card' => $request->tax_card,
            'fax' => $request->fax,
            'location' => $request->address,
            'url' => $request->url,
            'desc' => $request->desc,
            'logo' => $path_crypt,
        ]);

        if($store_client){
            return response()->json([
                'success' => $this->action_message(0, $this->page_name)
            ]);
        }
    }

    public function contactPersonStore(Request $request, Client $client)
    {
        $store_contact_person = $client->conatctPerson()->create([
            'name' => $request->sname,
            'email' => $request->semail,
            'tel' => $request->stel,
            'postion' => $request->stitle,
        ]);

        if($store_contact_person)
        {
            return response()->json([
                'success' => 'Contact Person Created successfully.'
            ]);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Client  $client
     * @return \Illuminate\Http\Response
     */
    public function show(Client $client)
    {
        return view('layouts.persons.client.show', ['page_name' => $this->page_name, 'route' => 'client', 'client' => $client]);
    }

    public function contactPersonShow(Client $client)
    {
        return response()->json([
            'contactperson' => $client->conatctPerson,
            'code' => $client->code,
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Client  $client
     * @return \Illuminate\Http\Response
     */
    public function edit(Client $client)
    {
        return view('layouts.persons.client.edit', [
            'page_name' => $this->page_name(1, $this->page_name),
            'route' => 'client.update',
            'client' => $client
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Client  $client
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Client $client)
    {
        $password = $request->upassword;
        if ($password != NULL)
        {
            $password = Hash::make($password);
        }
        else
        {
            $password = $client->password;
        }

        $path = $request->file('logo');
        if ($path != NULL)
        {
            Storage::disk('public')->delete('persons/clients/'.$client->logo);
            $path_crypt = Crypt::encryptString($path->getClientOriginalName());
            $store = $path->storeAs(
                'public/persons/clients',
                $path_crypt
            );
        }
        else
        {
            if($request->imagedata == '')
            {
                Storage::disk('public')->delete('persons/clients/'.$client->logo);
            }
            $path_crypt = $request->imagedata;
        }

        $update = $client->update([
            'name' => $request->uname,
            'password' => $password,
            'email' => $request->uemail,
            'tel' => $request->utel,
            'tax_card' => $request->tax_card,
            'fax' => $request->fax,
            'location' => $request->address,
            'url' => $request->url,
            'desc' => $request->desc,
            'logo' => $path_crypt,
        ]);

        if ($update)
        {
            return response()->json([
                'success' => $this->action_message(1, $this->page_name)
            ]);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Client  $client
     * @return \Illuminate\Http\Response
     */
    public function destroy(Client $client)
    {
        if (Storage::disk('public')->exists('persons/clients/'.$client->logo))
        {
            Storage::disk('public')->delete('persons/clients/'.$client->logo);
        }
        $remove = $client->forceDelete();
        if ($remove)
        {
            return response()->json([
                'success' => $this->action_message(2, $this->page_name)
            ]);
        }
    }

    public function departmentStore(Request $request, Client $client)
    {
        $store_department = $client->departments()->create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'description' => $request->description,
        ]);

        if($store_department)
        {
            return response()->json([
                'success' => 'Department Created successfully.'
            ]);
        }
    }

    public function departmentShow(Client $client)
    {
        return response()->json([
            'departments' => $client->departments,
            'code' => $client->code,
        ]);
    }
}
