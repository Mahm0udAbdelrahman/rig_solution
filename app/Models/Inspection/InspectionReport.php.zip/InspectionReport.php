<?php

namespace App\Models\Inspection;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

use App\Models\WorkFlow\JobRequest;
use App\Models\User;

class InspectionReport extends Model
{
    use HasFactory;

    protected $fillable = [
      'job_request_id',
      'code',
      'status',
      'publish',
      'user_id',
      'user_id_edit',
      'user_id_approved',
      'reportable_id',
      'reportable_type',
      'sync',
      'updated',
    ];

    // protected $hidden = ['id', 'created_at', 'updated_at', 'images'];

    public function reportable()
    {
        return $this->morphTo();
    }

    protected static function booted()
    {
        static::creating(function (InspectionReport $report) {
            // Publish status is controlled by PDF upload flow only.
            if ((int) ($report->publish ?? 0) === 1) {
                $report->publish = null;
            }
        });

        static::updating(function (InspectionReport $report) {
            $approvalWasCleared = $report->isDirty('user_id_approved')
                && !empty($report->getOriginal('user_id_approved'))
                && empty($report->user_id_approved);

            $reportableChanged = $report->isDirty('reportable_id') || $report->isDirty('reportable_type');
            $editorStateChanged = $report->isDirty('user_id_edit');

            // Block model-level publish=1 writes; publish is set only by PDF upload endpoint.
            if ($report->isDirty('publish') && (int) $report->publish === 1) {
                $report->publish = $report->getOriginal('publish');
            }

            // When an approved report is edited into a new reportable record,
            // force publish back to null to require an explicit re-publish.
            if ($approvalWasCleared && $reportableChanged) {
                $report->publish = null;
            }

            // Any report edit/revision state transition should invalidate publish
            // until a new PDF is uploaded via the dedicated upload endpoint.
            if ($reportableChanged || $editorStateChanged) {
                $report->publish = null;
            }
        });
    }

    public function job_request()
    {
        return $this->belongsTo(JobRequest::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
