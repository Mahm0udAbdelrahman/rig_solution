<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\Inspection\InspectionReport;
use App\Models\WorkFlow\FileManager;
use App\Models\WorkFlow\JobRequest;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class PortalController extends Controller
{
    public function customerOverview()
    {
        return $this->renderOverview('customer');
    }

    public function customerReports()
    {
        return $this->renderReports('customer');
    }

    public function departmentOverview()
    {
        return $this->renderOverview('department');
    }

    public function departmentReports()
    {
        return $this->renderReports('department');
    }

    private function renderOverview(string $scope)
    {
        $publishedReports = $this->overviewPublishedReportsQuery($scope)->get();

        $viewData = [
            'page_name' => 'Customer Overview',
            'portal_scope' => $scope,
            'portal_scope_label' => $scope === 'department' ? 'Department Portal' : 'Customer Portal',
            'overview_cards' => [
                [
                    'label' => 'Published Inspections',
                    'value' => $publishedReports->count(),
                    'note' => 'Certificates currently visible in the portal.',
                ],
            ],
            'inspection_section_cards' => $this->buildInspectionSectionCards($publishedReports),
            'recent_published_reports' => $publishedReports->take(8)->values(),
        ];

        return view('layouts.customer.overview', $viewData);
    }

    private function renderReports(string $scope)
    {
        $perPage = (int) request('per_page', 25);
        if (!in_array($perPage, [10, 25, 50, 100], true)) {
            $perPage = 25;
        }

        $search = trim((string) request('q', ''));
        $reportNoFilter = trim((string) request('report_no', ''));
        $identifierFilter = trim((string) request('identifier', ''));
        $equipmentFilter = trim((string) request('equipment', ''));
        $examDateFilter = trim((string) request('exam_date', ''));
        $purchaseOrderFilter = trim((string) request('purchase_order', ''));
        $workLocationFilter = trim((string) request('work_location', ''));
        $sortBy = (string) request('sort_by', 'updated_at');
        $sortDirection = strtolower((string) request('sort_direction', 'desc')) === 'asc' ? 'asc' : 'desc';

        $reportsQuery = InspectionReport::query()
            ->select([
                'inspection_reports.id',
                'inspection_reports.job_request_id',
                'inspection_reports.code',
                'inspection_reports.publish',
                'inspection_reports.reportable_type',
                'inspection_reports.reportable_id',
                'inspection_reports.updated_at',
            ])
            ->join('job_requests', 'inspection_reports.job_request_id', '=', 'job_requests.id')
            ->whereNotNull('publish')
            ->where('publish', '!=', 0)
            ->whereNotNull('reportable_type')
            ->whereNotNull('reportable_id')
            ->where(function (Builder $query) use ($scope) {
                if ($scope === 'department') {
                    $query->where('job_requests.client_department_id', (int) Auth::guard('clientDepartments')->id());
                    return;
                }

                $query->where('job_requests.client_id', (int) Auth::guard('customer')->id());
            });

        if ($search !== '') {
            $reportsQuery->where(function (Builder $query) use ($search) {
                $query->where('inspection_reports.code', 'like', '%'.$search.'%')
                    ->orWhere('inspection_reports.reportable_type', 'like', '%'.$search.'%')
                    ->orWhere('job_requests.code', 'like', '%'.$search.'%')
                    ->orWhere('job_requests.purchase_order', 'like', '%'.$search.'%')
                    ->orWhere('job_requests.deploc', 'like', '%'.$search.'%')
                    ->orWhereHasMorph('reportable', '*', function (Builder $reportableQuery) use ($search) {
                        $candidateColumns = array_values(array_unique(array_merge(
                            $this->customerReportIdentifierColumns(),
                            $this->customerReportEquipmentColumns()
                        )));
                        $this->applyCustomerReportableTextFilter($reportableQuery, $search, $candidateColumns);
                    });
            });
        }

        if ($reportNoFilter !== '') {
            $reportsQuery->where(function (Builder $query) use ($reportNoFilter) {
                $query->where('inspection_reports.code', 'like', '%'.$reportNoFilter.'%')
                    ->orWhere('job_requests.code', 'like', '%'.$reportNoFilter.'%')
                    ->orWhereRaw("CONCAT(job_requests.code, '/', inspection_reports.code) like ?", ['%'.$reportNoFilter.'%']);
            });
        }

        if ($identifierFilter !== '') {
            $reportsQuery->whereHasMorph('reportable', '*', function (Builder $reportableQuery) use ($identifierFilter) {
                $this->applyCustomerReportableTextFilter($reportableQuery, $identifierFilter, $this->customerReportIdentifierColumns());
            });
        }

        if ($equipmentFilter !== '') {
            $reportsQuery->whereHasMorph('reportable', '*', function (Builder $reportableQuery) use ($equipmentFilter) {
                $this->applyCustomerReportableTextFilter($reportableQuery, $equipmentFilter, $this->customerReportEquipmentColumns());
            });
        }

        if ($examDateFilter !== '') {
            $reportsQuery->whereHasMorph('reportable', '*', function (Builder $reportableQuery) use ($examDateFilter) {
                $this->applyCustomerReportableTextFilter($reportableQuery, $examDateFilter, $this->customerReportExaminationDateColumns());
            });
        }

        if ($purchaseOrderFilter !== '') {
            $reportsQuery->where('job_requests.purchase_order', 'like', '%'.$purchaseOrderFilter.'%');
        }

        if ($workLocationFilter !== '') {
            $reportsQuery->where('job_requests.deploc', 'like', '%'.$workLocationFilter.'%');
        }

        switch ($sortBy) {
            case 'type':
                $reportsQuery->orderBy('inspection_reports.reportable_type', $sortDirection);
                break;
            case 'report_no':
                $reportsQuery
                    ->orderBy('job_requests.code', $sortDirection)
                    ->orderBy('inspection_reports.code', $sortDirection);
                break;
            case 'purchase_order':
                $reportsQuery->orderBy('job_requests.purchase_order', $sortDirection);
                break;
            case 'work_location':
                $reportsQuery->orderBy('job_requests.deploc', $sortDirection);
                break;
            default:
                $reportsQuery->orderBy('inspection_reports.updated_at', $sortDirection);
                break;
        }

        $reports = $reportsQuery
            ->with([
                'job_request:id,code,purchase_order,deploc',
                'reportable',
            ])
            ->paginate($perPage)
            ->withQueryString();

        $reportRows = $this->buildPublishedReportRows(collect($reports->items()));
        $reports->setCollection($reportRows);

        return view('layouts.customer.reports.reports', [
            'page_name' => 'Published Inspection Certificates',
            'report_rows' => $reports,
        ]);
    }

    private function baseScopeQuery(string $scope): Builder
    {
        return $this->applyPortalScopeToJobRequestQuery(JobRequest::query(), $scope);
    }

    private function applyPortalScopeToJobRequestQuery(Builder $query, string $scope): Builder
    {
        if ($scope === 'department') {
            $departmentId = (int) Auth::guard('clientDepartments')->id();
            return $query->where('client_department_id', $departmentId);
        }

        $customerId = (int) Auth::guard('customer')->id();
        return $query->where('client_id', $customerId);
    }

    private function overviewPublishedReportsQuery(string $scope): Builder
    {
        $query = InspectionReport::query()
            ->select([
                'id',
                'job_request_id',
                'code',
                'publish',
                'reportable_type',
                'reportable_id',
                'updated_at',
                'created_at',
            ])
            ->whereNotNull('publish')
            ->where('publish', '!=', 0)
            ->whereNotNull('reportable_type')
            ->whereNotNull('reportable_id')
            ->whereHas('job_request', function (Builder $query) use ($scope) {
                $this->applyPortalScopeToJobRequestQuery($query, $scope);
            })
            ->with(['job_request:id,code'])
            ->orderByDesc('updated_at')
            ->orderByDesc('created_at');

        return $query;
    }

    private function buildInspectionSectionCards(Collection $publishedReports): Collection
    {
        return $publishedReports
            ->groupBy(function (InspectionReport $report) {
                return $this->resolveInspectionSectionLabel((string) $report->reportable_type);
            })
            ->map(function (Collection $reports, string $label) {
                $latestReport = $reports->sortByDesc(function (InspectionReport $report) {
                    return optional($report->updated_at)->timestamp ?: optional($report->created_at)->timestamp;
                })->first();

                $latestCode = optional($latestReport)->code;
                if ($latestReport && optional($latestReport->job_request)->code) {
                    $latestCode = $latestReport->job_request->code.'/'.$latestReport->code;
                }

                return [
                    'label' => $label,
                    'count' => $reports->count(),
                    'latest_code' => $latestCode,
                ];
            })
            ->sortByDesc('count')
            ->values();
    }

    private function resolveInspectionSectionLabel(string $reportableType): string
    {
        $cleanType = str_replace('App\\Models\\Inspection\\', '', $reportableType);
        $segments = array_values(array_filter(explode('\\', $cleanType)));
        return $segments[0] ?? 'Inspection';
    }

    private function resolveInspectionTypeLabel(string $reportableType): string
    {
        $cleanType = str_replace('App\\Models\\Inspection\\', '', $reportableType);
        $segments = array_values(array_filter(explode('\\', $cleanType)));
        $className = end($segments) ?: 'Report';

        return trim(preg_replace('/(?<!^)[A-Z]/', ' $0', $className));
    }

    private function buildPublishedReportRows(Collection $reports): Collection
    {
        return $reports
            ->map(function (InspectionReport $report) {
                $jobRequest = $report->job_request;
                $jobCode = (string) optional($jobRequest)->code;
                $pdfPath = $this->resolveCustomerReportPdfPath($report, $jobCode);

                return [
                    'type' => $this->customerReportTypeLabel((string) $report->reportable_type),
                    'section' => $this->customerReportSectionLabel((string) $report->reportable_type),
                    'report_no' => $jobCode.'/'.$report->code,
                    'identifier' => $this->customerReportIdentifier($report->reportable),
                    'equipment' => $this->customerReportEquipment($report->reportable),
                    'examination_date' => $this->customerReportExaminationDate($report->reportable),
                    'purchase_order' => (string) ($jobRequest->purchase_order ?? ''),
                    'internal_service_order' => (string) data_get($report->reportable, 'internal_service_order', ''),
                    'work_location' => (string) ($jobRequest->deploc ?? ''),
                    'pdf_path' => $pdfPath,
                    'pdf_url' => $pdfPath ? Storage::disk('public')->url($pdfPath) : null,
                ];
            })
            ->values();
    }

    private function customerReportSectionLabel(?string $reportableType): string
    {
        $segments = $this->customerReportableSegments($reportableType);

        return ucfirst(strtolower((string) ($segments[0] ?? 'Inspection')));
    }

    private function customerReportTypeLabel(?string $reportableType): string
    {
        $basename = class_basename((string) $reportableType);
        if ($basename === '') {
            return 'Unknown';
        }

        return trim((string) preg_replace('/(?<!^)[A-Z]/', ' $0', $basename));
    }

    private function customerReportIdentifier($reportable): string
    {
        if (!$reportable) {
            return '';
        }

        if (isset($reportable->lter_10) && !empty($reportable->lter_10) && isset($reportable->lter_10['pop1'])) {
            return (string) $reportable->lter_10['pop1'];
        }

        if (isset($reportable->ldr_8) && !empty($reportable->ldr_8)) {
            $parts = [];
            $decoded = json_decode((string) $reportable->ldr_8);
            foreach ((array) $decoded as $item) {
                $value = data_get($item, 'lcr_10');
                if (!empty($value)) {
                    $parts[] = (string) $value;
                }
            }
            if (!empty($parts)) {
                return implode(' | ', $parts);
            }
        }

        return $this->customerReportFirstNonEmptyField($reportable, $this->customerReportIdentifierColumns());
    }

    private function customerReportEquipment($reportable): string
    {
        if (!$reportable) {
            return '';
        }

        if (isset($reportable->lter_10) && !empty($reportable->lter_10) && isset($reportable->lter_10['pop20'])) {
            return (string) $reportable->lter_10['pop20'];
        }

        return $this->customerReportFirstNonEmptyField($reportable, $this->customerReportEquipmentColumns());
    }

    private function customerReportExaminationDate($reportable): string
    {
        if (!$reportable) {
            return '';
        }

        return $this->customerReportFirstNonEmptyField($reportable, $this->customerReportExaminationDateColumns());
    }

    private function customerReportIdentifierColumns(): array
    {
        return [
            'lter_10',
            'ldr_8',
            'identification_no',
            'joint_no',
            'joint_number',
            'joint_id',
            'tool_joint_id',
            'joint_size',
            'equipment_no',
            'serial_number',
            'device_serial_number',
            'material_no',
            'tool_number',
            'lcr_12',
            'locr_12',
            'lfr_12',
            'nmpr_28',
            'ntir_13',
            'nvr_6',
            'nur_26',
            'nwhr_15',
            'nhpr_10',
            'nh2pr_10',
        ];
    }

    private function customerReportEquipmentColumns(): array
    {
        return [
            'lter_10',
            'name',
            'equipment_name',
            'item_name',
            'desc',
            'description',
            'joint_description',
            'material_description',
            'dc_description',
            'inspection_description',
            'pipe_description',
            'equipment_description',
            'device_description',
            'lcr_10',
            'locr_10',
            'lfr_10',
            'nur_12',
        ];
    }

    private function customerReportExaminationDateColumns(): array
    {
        return [
            'examination_date',
            'ldr_6',
            'lcr_6',
            'locr_6',
            'lfr_6',
            'lter_6',
            'nmpr_6',
            'ntir_6',
            'nvr_4',
            'nur_6',
            'nsr_4',
            'nwhr_6',
            'nhpr_6',
            'nh2pr_6',
            'nar_4',
        ];
    }

    private function applyCustomerReportableTextFilter(Builder $reportableQuery, string $search, array $candidateColumns): void
    {
        $table = $reportableQuery->getModel()->getTable();
        $columns = \Illuminate\Support\Facades\Schema::getColumnListing($table);
        $availableColumns = array_values(array_intersect($candidateColumns, $columns));
        $searchTokens = array_values(array_filter(preg_split('/\s+/', trim($search))));

        if (empty($availableColumns)) {
            $reportableQuery->whereRaw('1 = 0');
            return;
        }

        $reportableQuery->where(function (Builder $query) use ($availableColumns, $searchTokens, $search) {
            $tokens = !empty($searchTokens) ? $searchTokens : [$search];

            foreach ($tokens as $token) {
                $query->where(function (Builder $tokenQuery) use ($availableColumns, $token) {
                    foreach ($availableColumns as $column) {
                        $tokenQuery->orWhere($column, 'like', '%'.$token.'%');
                    }
                });
            }
        });
    }

    private function resolveCustomerReportPdfPath(InspectionReport $report, string $jobCode): ?string
    {
        if ($jobCode === '' || empty($report->code) || empty($report->reportable_type)) {
            return null;
        }

        $relativePdfPath = 'pdf/' . strtolower(str_replace('\\', '/', str_replace('App\\Models\\', '', (string) $report->reportable_type))) . '/' . $jobCode . '/' . $report->code . '.pdf';
        if (Storage::disk('public')->exists($relativePdfPath)) {
            return $relativePdfPath;
        }

        $fileRow = FileManager::query()
            ->select(['path'])
            ->where('module', 'inspection')
            ->where('is_inspection', 1)
            ->where('is_available', 1)
            ->where('extension', 'pdf')
            ->where('job_request_code', $jobCode)
            ->where(function (Builder $query) use ($report, $relativePdfPath) {
                $query
                    ->where('entity_code', $report->code)
                    ->orWhere('path', 'like', '%/'.basename(str_replace('\\', '/', $relativePdfPath)));
            })
            ->first();

        return $fileRow?->path;
    }

    private function customerReportableSegments(?string $reportableType): array
    {
        $clean = str_replace('App\\Models\\Inspection\\', '', (string) $reportableType);

        return array_values(array_filter(explode('\\', $clean), function ($segment) {
            return $segment !== '';
        }));
    }

    private function customerReportFirstNonEmptyField($reportable, array $fields): string
    {
        foreach ($fields as $field) {
            $value = data_get($reportable, $field);
            if (is_array($value) || is_object($value)) {
                $value = json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            }

            if ($value !== null && trim((string) $value) !== '') {
                return trim((string) $value);
            }
        }

        return '';
    }
}
