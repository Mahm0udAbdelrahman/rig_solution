<?php

namespace App\Http\Controllers\Dashboard\Inspection\Ndt;

use App\Http\Controllers\Controller;
use App\Http\Controllers\CustomController;
use App\Models\GeneralInfo\Specification;
use App\Models\Inspection\Ndt\DrawingInspection;
use App\Models\Persons\Client;
use App\Models\Persons\Supplier;
use App\Models\WorkFlow\JobRequest;
use Illuminate\Http\Request;

// Other
use DB, DataTables, Storage, Auth, Crypt;
use function Symfony\Component\String\length;

class DrawingInspectionController extends Controller
{
    public $page_name = 'Drawing Inspection Report';
    public function __construct()
    {
        $this->middleware('auth');
        $this->authorizeResource(DrawingInspection::class, 'drawingInspection');
    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $reports = DrawingInspection::count();
        return view('layouts.inspection.ndt.drawingInspection.index', ['page_name' => $this->page_name('All', $this->page_name), 'reports' => $reports]);
    }

    public function getDataForDataTable()
    {
        $data = DrawingInspection::query()
            ->has('report')
            ->withAggregate('job_request','code')
            ->orderBy('job_request_code', 'Desc');

        $this->applyInspectionApprovalPresetFilter($data, request('smart_preset'));

        return Datatables::eloquent($data)

            ->addColumn('approval_status', function ($row) {
                return $this->inspectionApprovalStatusValueByRow($row);
            })
            ->addColumn('client', function ($row) {
                $report_code = "";
                if ($row->job_request->client) {
                    if (Auth::user()->can('view', Client::find($row->job_request->client->id))) {
                        $report_code .= "<a href=" . route('client.show', $row->job_request->client->id) . ">";
                    }

                    $report_code .= $row->job_request->client->name;

                    if (Auth::user()->can('view', Client::find($row->job_request->client->id))) {
                        $report_code .= "</a>";
                    }
                } else {
                    if (Auth::user()->can('view', Supplier::find($row->job_request->supplier->id))) {
                        $report_code .= "<a href=" . route('supplier.show', $row->job_request->supplier->id) . ">";
                    }

                    $report_code .= $row->job_request->supplier->name;

                    if (Auth::user()->can('view', Supplier::find($row->job_request->supplier->id))) {
                        $report_code .= "</a>";
                    }

                }
                return $report_code;
            })
            ->addColumn('code', function ($row) {
                $report_code = "";
                if (Auth::user()->can('view', DrawingInspection::find($row->id)) ) {
                    $report_code .= "<a href=" . route('drawingInspection.show', $row->id) . ">";
                }

                $report_code .= $row->job_request->code . '/' . $row->code;

                if (Auth::user()->can('view', DrawingInspection::find($row->id)) ) {
                    $report_code .= "</a>";
                }
                return $report_code;
            })
            ->addColumn('deploc', function ($row) {
                return $row->job_request->deploc;
            })
            ->addColumn('identification_no', function ($row) {
                return $row->identification_no;
            })
            ->addColumn('description', function ($row) {

                return $row->description;
            })
            ->addColumn('client_department', function ($row) {

                return $row->job_request->clientDepartment ? $row->job_request->clientDepartment->name : '';
            })
            ->addColumn('action', function ($row) {
                $btn = "";
                if (Auth::user()->can('create', DrawingInspection::class) ) {
                    $btn .= '<button data-id="' . $row->report->id . '" class="btn btn-primary mr-1 duplicate"><i class="la la-clone"></i></button>';
                }

                if ($row->report->publish != NULL) {
                    if (Storage::disk('public')->exists('pdf/inspection/ndt/drawinginspection/' . $row->job_request->code . '/' . $row->code . '.pdf')) {
                        $btn .= '<a class="btn btn-secondary mr-1" target="_blank" href="' . Storage::url('pdf/inspection/ndt/drawinginspection/' . $row->job_request->code . '/' . $row->code . '.pdf') . '">Download PDF</a>';
                    } else {
                        $btn .= '<a class="btn btn-dark mr-1" href="' . route('drawingInspection.show', $row->id) . '">Open Report</a>';
                    }

                    if (Auth::user()->can('update', DrawingInspection::find($row->id))) {
                        $btn .= '<a href="' . route('drawingInspection.edit', $row->id) . '" class="btn btn-icon btn-info mr-1"><i class="la la-pencil"></i></a>';
                    }
                } else {
                    if (Auth::user()->can('create', DrawingInspection::find($row->id))) {
                        $btn .= '<a href="' . route('publish.drawingInspection', $row->id) . '" class="btn btn-icon btn-info mr-1">Publish</a>';
                    }
                }


                if (Auth::user()->can('delete', DrawingInspection::find($row->id))) {
                    $btn .= '<button type="button" data-id="' . $row->id . '" class="btn btn-icon btn-danger delete mr-1"><i class="la la-trash"></i></button>';
                }
                return $btn;
            })
            ->filterColumn('acceptance', function ($query, $keyword) {
                $query->whereRaw("acceptance like ?", ["%{$keyword}%"]);
            })
            ->filterColumn('identification_no', function ($query, $keyword) {
                $query->whereRaw("identification_no like ?", ["%{$keyword}%"]);
            })
            ->filterColumn('description', function ($query, $keyword) {
                $query->whereRaw("description like ?", ["%{$keyword}%"]);
            })
            ->filterColumn('code', function ($query, $keyword) {
                $query->whereRaw("code like ?", ["%{$keyword}%"])
                    ->orWhereHas('job_request', function ($row) use (&$keyword) {
                        $row->where("code", "like", ["%{$keyword}%"]);
                    });
            })
            ->filterColumn('deploc', function ($query, $keyword) {
                $query->whereHas('job_request', function ($row) use (&$keyword) {
                    // $row->whereHas('client', function($row1) use (&$keyword){
                    $row->where("deploc", "like", ["%{$keyword}%"]);
                    // });
                });
            })
            ->filterColumn('client_department', function ($query, $keyword) {
                $query->whereHas('job_request', function ($row) use (&$keyword) {
                    $row->whereHas('clientDepartment', function ($row1) use (&$keyword) {
                        $row1->where("name", "like", ["%{$keyword}%"]);
                    });
                });
            })
            ->filterColumn('client', function ($query, $keyword) {
                $query->whereHas('job_request', function ($row) use (&$keyword) {
                    $row->whereHas('client', function ($row1) use (&$keyword) {
                        $row1->where("name", "like", ["%{$keyword}%"]);
                    });
                });
            })
            ->filterColumn('action', function ($query, $keyword) {
                $codes = $this->getUploadedCodes('/ndt/drawinginspection', true);
                switch ($keyword) {
                    case 'publish':
                        $query->whereHas('report', function ($q) {
                            $q->where('publish', null);
                        });
                        break;
                    case 'download':
                        $query->whereHas('job_request', function ($q) use ($codes) {
                            $q->whereIn(DB::raw("CONCAT(job_requests.code, '/', drawing_inspections.code)"), $codes);
                        });
                        break;
                    case 'upload':
                        $query->whereHas('report', function ($q) {
                            $q->whereNot('publish', null);
                        });
                        $query->whereHas('job_request', function ($q) use ($codes) {
                            $q->whereNotIn(DB::raw("CONCAT(job_requests.code, '/', drawing_inspections.code)"), $codes);
                        });

                        break;
                }
            })
            ->rawColumns(['code', 'client', 'action'])
            ->make('true');
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $jobrequests = DB::table('job_requests')->select('id','code')->orderBy('id', 'desc')->get();

        return view('layouts.inspection.ndt.drawingInspection.add', [
            'page_name' => $this->page_name(0, $this->page_name),
            'jobrequests' => $jobrequests,
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data  = $request->all();
				$data['report_image'] = null;
				if ($request->hasFile('report_image')) {
					$file = $request->file('report_image');
					$uniqueFileName =  time() . '.' . $file->getClientOriginalExtension();
					$directory = 'camera/inspection/ndt/drawinginspection';
					$file->storeAs($directory, $uniqueFileName, 'public');
					$data['report_image'] = $uniqueFileName;
				}				
        $created = DrawingInspection::create($data);
        $code = $data['code'];
        if ($created) {
            $created->report()->create([
                'job_request_id' => $request->job_request_id,
                'code' => $code,
                'status' => 1,
                'publish' => 1,
                'sync' => 1,
                'user_id' => Auth::id(),
            ]);
            return response()->redirectToRoute('drawingInspection.index');
        }
        return response()->json([$data]);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Inspection\Ndt\DrawingInspection drawingInspection
     * @return \Illuminate\Http\Response
     */
    public function show(DrawingInspection $drawingInspection)
    {
        $have_edit = $this->check_if_report_edit(DrawingInspection::class, $drawingInspection);
        $drawingInspection->report = $have_edit->default;
        $footerData = [
            'formNo' => 'RS-RF-F18',
            'issueNo' => '04',
            'issueDate' => '1-Mar-2024',
            'revisionNo'=> '00',
            'revisionDate' => '1-Mar-2024',
            'pageNo' => '1 of 1',
        ];

        return view('layouts.inspection.ndt.drawingInspection.show', [
            'page_name' => $this->page_name,
            'page_text' => '',
            'model' => $drawingInspection,
            'model2' => false,
            'code' => $drawingInspection->job_request->code . '/' . $drawingInspection->code,
            'report_created_at' => $drawingInspection->created_at->format('d/m/Y'),
            'footerData'=> $footerData,
            'pdfurl' => 'storage/pdf/inspection/ndt/drawinginspection/' . $drawingInspection->job_request->code . '/' . $drawingInspection->code . '.pdf',
            'hasPermission' => Auth::user()->can('approve', $drawingInspection),
            'imageurl' => $drawingInspection->job_request->code . '/' . $drawingInspection->code,
            'folder' => 'pdf/inspection/ndt/drawinginspection',
            'iso_number' => 'Form # RSE-RF-07 - ISSUE 07 / Jul 2023',
            'page_number' => '1 of 1',
            'have_edit' => $have_edit->edited,
            'user_id_approved' => $have_edit->default->user_id_approved,
            'for_approve_url' => $have_edit->default->id,
            'esign' => $have_edit->default->user->employee->esign,
            'person_make_report' => $have_edit->default->user->employee->name,
            'person_make_report_desc' => $have_edit->default->user->employee->desc,
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Inspection\Ndt\DrawingInspection $drawingInspection
     * @return \Illuminate\Http\Response
     */
    public function edit(DrawingInspection $drawingInspection)
    {
        // return $drawingInspection;
        $jobrequests = DB::table('job_requests')->select('id', 'code')->orderBy('id', 'desc')->get();
        return view('layouts.inspection.ndt.drawingInspection.edit', [
            'model' => $drawingInspection,
            'page_name' => $this->page_name(1, $this->page_name),
            'jobrequests' => $jobrequests,
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \App\Models\Inspection\Ndt\DrawingInspection $drawingInspection
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, DrawingInspection $drawingInspection)
    {
		$data = $request->all();
		// dd($data);
		// $data['report_image'] = null;
		if ($request->hasFile('report_image')) {
			$file = $request->file('report_image');
			$uniqueFileName =  time() . '.' . $file->getClientOriginalExtension();
			$directory = 'camera/inspection/ndt/drawinginspection';
			$file->storeAs($directory, $uniqueFileName, 'public');
			$data['report_image'] = $uniqueFileName;
		}	
        if ($drawingInspection->report->user_id_approved != NULL) {
            $data['job_request_id'] = $drawingInspection->job_request_id;
            $createdCert = $drawingInspection->create($data);
            $reportUpdateData = [
                'reportable_id' => $createdCert->id,
                'user_id_edit' => Auth::id(),
                'user_id_approved' => null,
            ];
        } else {
            $drawingInspection->update($data);
            $reportUpdateData = [
                'user_id_edit' => Auth::id(),
            ];
        }

        $drawingInspection->report()->update($reportUpdateData);
        return response()->redirectToRoute('drawingInspection.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Inspection\Ndt\DrawingInspection $drawingInspection
     * @return \Illuminate\Http\Response
     */
    public function destroy(DrawingInspection $drawingInspection)
    {
        $remove = $this->check_edited_reports_for_delete($drawingInspection);

        if ($remove) {
            $drawingInspection->report->delete();
            $pdf = 'inspection/ndt/drawinginspection/' . $drawingInspection->job_request->code . '/' . $drawingInspection->code . '.pdf';
            $snap = 'images/inspection/ndt/drawinginspection/' . $drawingInspection->job_request->code . '/' . $drawingInspection->code;
            $remove_snap_shots_pdf = $this->remove_snap_shots_pdf($pdf, $snap);
            return response()->json([
                'success' => $remove_snap_shots_pdf . $this->action_message(2, $this->page_name)
            ]);
        }
    }

    public function publish(DrawingInspection $drawingInspection)
    {
        $jobrequests = DB::table('job_requests')->select('id','code')->orderBy('id', 'desc')->get();
        return view('layouts.inspection.ndt.drawingInspection.publish', [
            'page_name' => $this->page_name(0, $this->page_name).' (Publish)',
            'model' => $drawingInspection,
            'jobrequests' => $jobrequests,
        ]);
    }

    public function publishSubmit(Request $request, DrawingInspection $drawingInspection)
    {
        $data = $request->all();
		// $data['report_image'] = null;
		if ($request->hasFile('report_image')) {
			$file = $request->file('report_image');
			$uniqueFileName =  time() . '.' . $file->getClientOriginalExtension();
			$directory = 'camera/inspection/ndt/drawinginspection';
			$file->storeAs($directory, $uniqueFileName, 'public');
			$data['report_image'] = $uniqueFileName;
		}	
        $job_request = JobRequest::find($request->job_request_id);
        $code = json_decode(json_encode(CustomController::getReportData($job_request)))->original->lastcode;
        $data['code'] = $code;
        $drawingInspection->update($data);
        $drawingInspection->report()->update([
            'code' => $code,
            'status' => 1,
            'publish' => 1,
            'user_id_approved' => null,
            'user_id_edit' => null,
        ]);
        return response()->redirectToRoute('drawingInspection.index');
    }
}


