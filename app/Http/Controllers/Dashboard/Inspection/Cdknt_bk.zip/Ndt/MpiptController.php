<?php
namespace App\Http\Controllers\Dashboard\Inspection\Ndt;

use App\Http\Controllers\Controller;
use App\Http\Controllers\CustomController;

// Illuminate\Http
use Illuminate\Http\Request;

// App\Models
use App\Models\Inspection\Ndt\Mpipt;
use App\Models\GeneralInfo\Specification;
use App\Models\Persons\Client;
use App\Models\Persons\Supplier;
use App\Models\WorkFlow\JobRequest;
use App\Models\Inspection\InspectionReport;

// Other
use DB, DataTables, Storage, Auth, Crypt;

class MpiptController extends Controller
{
    public $page_name = 'MT or PT Inspection Report';

    public function __construct()
    {
        $this->middleware('auth');
        $this->authorizeResource(Mpipt::class, 'mpipt');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $mpipts = Mpipt::count();
        return view('layouts.inspection.ndt.mpipt.index', ['page_name' => $this->page_name('All', $this->page_name), 'mpipts' => $mpipts]);
    }

    public function getDataForDataTable()
    {
        $data = Mpipt::query()
            ->has('report')
            ->with([
                'job_request.client',
                'job_request.supplier',
                'job_request.clientDepartment',
                'report',
            ])
            ->withAggregate('job_request', 'code')
            ->orderBy('job_request_code', 'Desc');

        $this->applyInspectionApprovalPresetFilter($data, request('smart_preset'));

        return Datatables::eloquent($data)
            
            ->addColumn('approval_status', function ($row) {
                return $this->inspectionApprovalStatusValueByRow($row);
            })
            ->addColumn('publish_status', function ($row) {
                return $this->inspectionPublishStatusValueByRow($row);
            })
            ->addColumn('revision_count', function ($row) {
                return $this->inspectionRevisionCountValueByRow($row);
            })
            ->addColumn('client', function ($row) {
                $jobRequest = $row->job_request;
                if (!$jobRequest) {
                    return '';
                }

                $client = $jobRequest->client;
                if ($client) {
                    $label = e($client->name);
                    return Auth::user()->can('view', $client)
                        ? '<a href="' . route('client.show', $client->id) . '">' . $label . '</a>'
                        : $label;
                }

                $supplier = $jobRequest->supplier;
                if ($supplier) {
                    $label = e($supplier->name);
                    return Auth::user()->can('view', $supplier)
                        ? '<a href="' . route('supplier.show', $supplier->id) . '">' . $label . '</a>'
                        : $label;
                }

                return '';
            })
            ->addColumn('code', function ($row) {
                $jobRequestCode = optional($row->job_request)->code;
                $reportCode = trim(($jobRequestCode ? $jobRequestCode . '/' : '') . $row->code, '/');
                if ($reportCode === '') {
                    return '';
                }

                $reportCode = e($reportCode);

                return Auth::user()->can('view', $row)
                    ? '<a href="' . route('mpipt.show', $row->id) . '">' . $reportCode . '</a>'
                    : $reportCode;
            })
            ->addColumn('deploc', function ($row) {
                return (string) optional($row->job_request)->deploc;
            })
            ->addColumn('client_department', function ($row) {
                return optional(optional($row->job_request)->clientDepartment)->name ?: '';
            })
            ->addColumn('action', function ($row) {
                $btn = "";
                $report = $row->report;
                $jobRequestCode = optional($row->job_request)->code;

                if (Auth::user()->can('create', Mpipt::class)) {
                    if ($report) {
                        $btn .= '<button data-id="' . $report->id . '" class="btn btn-primary mr-1 duplicate"><i class="la la-clone"></i></button>';
                    }
                }

                if (!$report) {
                    return $btn;
                }

                if (!is_null($report->publish)) {
                    if ($jobRequestCode && Storage::disk('public')->exists('pdf/inspection/ndt/mpipt/' . $jobRequestCode . '/' . $row->code . '.pdf')) {
                        $btn .= '<a class="btn btn-secondary mr-1" target="_blank" href="' . Storage::url('pdf/inspection/ndt/mpipt/' . $jobRequestCode . '/' . $row->code . '.pdf') . '">Download PDF</a>';
                    } else {
                        $btn .= '<a class="btn btn-dark mr-1" href="' . route('mpipt.show', $row->id) . '">Open Report</a>';
                    }

                    if (Auth::user()->can('update', $row)) {
                        $btn .= '<a href="' . route('mpipt.edit', $row->id) . '" class="btn btn-icon btn-info mr-1"><i class="la la-pencil"></i></a>';
                    }
                } else {
                    $btn .= $this->buildInspectionUnpublishedActionButtons($row, Mpipt::class, (int) ($row->id), 'mpipt.show', 'publish.mpipt', 'mpipt.edit');
                }


                if (Auth::user()->can('delete', $row)) {
                    $btn .= '<button type="button" data-id="' . $row->id . '" class="btn btn-icon btn-danger delete mr-1"><i class="la la-trash"></i></button>';
                }
                return $btn;
            })
            ->filterColumn('nmpr_28', function ($query, $keyword) {
                $query->whereRaw("nmpr_28 like ?", ["%{$keyword}%"]);
            })
            ->filterColumn('acceptance', function ($query, $keyword) {
                $query->whereRaw("acceptance like ?", ["%{$keyword}%"]);
            })
            ->filterColumn('code', function ($query, $keyword) {
                $query->whereRaw("code like ?", ["%{$keyword}%"])
                    ->orWhereHas('job_request', function ($row) use (&$keyword) {
                        $row->where("code", "like", ["%{$keyword}%"]);
                    });
            })
            ->filterColumn('deploc', function ($query, $keyword) {
                $query->whereHas('job_request', function ($row) use (&$keyword) {
                    $row->where("deploc", "like", ["%{$keyword}%"]);
                });
            })
            ->filterColumn('client_department', function ($query, $keyword) {
                $query->whereHas('job_request', function ($row) use (&$keyword) {
                    $row->whereHas('clientDepartment', function ($row1) use (&$keyword) {
                        $row1->where("name", "like", ["%{$keyword}%"]);
                    });
                });
            })
            ->filterColumn('client', function ($query, $keyword) {
                $query->whereHas('job_request', function ($row) use (&$keyword) {
                    $row->where(function ($jobRequestQuery) use (&$keyword) {
                        $jobRequestQuery->whereHas('client', function ($row1) use (&$keyword) {
                            $row1->where("name", "like", ["%{$keyword}%"]);
                        })->orWhereHas('supplier', function ($row1) use (&$keyword) {
                            $row1->where("name", "like", ["%{$keyword}%"]);
                        });
                    });
                });
            })
            ->filterColumn('action', function ($query, $keyword) {
                $codes = $this->getUploadedCodes('/ndt/mpipt', true);
                switch ($keyword) {
                    case 'publish':
                        $query->whereHas('report', function ($q) {
                            $q->where('publish', null);
                        });
                        break;
                    case 'download':
                        $query->whereHas('job_request', function ($q) use ($codes) {
                            $q->whereIn(DB::raw("CONCAT(job_requests.code, '/', mpipts.code)"), $codes);
                        });
                        break;
                    case 'upload':
                        $query->whereHas('report', function ($q) {
                            $q->whereNotNull('publish');
                        })->whereHas('job_request', function ($q) use ($codes) {
                            $q->whereNotIn(DB::raw("CONCAT(job_requests.code, '/', mpipts.code)"), $codes);
                        });
                        break;
                }
            })
            
            ->filter(function ($query) {
                $this->applyInspectionGlobalSearch($query, request('search.value'));
            })
            ->rawColumns(['code', 'client', 'action'])
            ->toJson();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $specifications = DB::table('specifications')->select('id', 'name')->get();
        $jobrequests = DB::table('job_requests')->select('id', 'code')->orderBy('id', 'desc')->get();
        return view('layouts.inspection.ndt.mpipt.add', [
            'page_name' => $this->page_name(0, $this->page_name),
            'jobrequests' => $jobrequests,
            'specifications' => $specifications
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $newone = [];
        foreach ($request['payments'] as $key => $value) {
            $newone[$key]['nmpr_49'] = $value['nmpr_49'];
            $path_crypt = '';
            if (isset($value['nmpr_50']) && $value['nmpr_50'] != NULL) {
                $path_crypt = Crypt::encryptString($value['nmpr_50']->getClientOriginalName());
                $store = $value['nmpr_50']->storeAs(
                    'public/camera/inspection/ndt/mpipts',
                    $path_crypt
                );
                $newone[$key]['nmpr_50'] = $path_crypt;
            } else {
                $newone[$key]['nmpr_50'] = '';
            }
        }

        $job_request = JobRequest::find($request->lcr_1);
        $code = json_decode(json_encode(CustomController::getReportData($job_request)))->original->lastcode;

        $store = Mpipt::create([
            'job_request_id' => $request->lcr_1,
            'nmpr_2' => $request->nmpr_2,
            'code' => $code,
            'nmpr_6' => $request->nmpr_6,
            'nmpr_7' => $request->nmpr_7,
            'nmpr_8' => $request->nmpr_8,
            'nmpr_10' => $request->nmpr_10,
            'acceptance' => $request->nmpr_11,
            'nmpr_12' => $request->nmpr_12,
            'nmpr_13' => $request->nmpr_13,
            'desc' => $request->nmpr_47,
            'nmpr_28' => $request->nmpr_48,
            'nmpr_29' => json_encode($newone),
            'nmpr_30' => $request->nmpr_51,
            'nmpr_800' => $request->nmpr_800,
            'nmpr_900' => $request->nmpr_900,
//            'temperature' => $request->temperature,
            'sync' => 0,
        ]);

        if ($store) {
            $store->report()->create([
                'job_request_id' => $request->lcr_1,
                'code' => $code,
                'status' => 1,
                'publish' => null,
                'sync' => 1,
                'user_id' => Auth::id(),
            ]);
            return response()->json([
                'last_id' => $store->id,
                'success' => $this->action_message(0, $this->page_name)
            ]);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Mpipt  $mpipt
     * @return \Illuminate\Http\Response
     */
    public function show(Mpipt $mpipt)
    {
        $have_edit = $this->check_if_report_edit(Mpipt::class, $mpipt);
        $mpipt->report = $have_edit->default;

        // return $have_edit->default->user_id_approved;

        return view('layouts.inspection.ndt.mpipt.show', [
            'page_name' => $this->page_name,
            'page_text' => '',
            'mpipt' => $mpipt,
            'model' => $mpipt,
            'code' => $mpipt->job_request->code . '/' . $mpipt->code,
            'report_created_at' => $mpipt->created_at->format('d/m/Y'),
            'pdfurl' => 'storage/pdf/inspection/ndt/mpipt/' . $mpipt->job_request->code . '/' . $mpipt->code . '.pdf',
            'hasPermission' => Auth::user()->hasPermission('mpipt', 'approve'),
            'imageurl' => $mpipt->job_request->code . '/' . $mpipt->code,
            'folder' => 'pdf/inspection/ndt/mpipt',
            'iso_number' => 'Form # RSE-RF-07 - ISSUE 07 / Jul 2023',
            'page_number' => '1 of 1',
            'have_edit' => $have_edit->edited,
            'user_id_approved' => data_get($mpipt, 'report.user_id_approved'),
            'for_approve_url' => data_get($mpipt, 'report.id'),
            'esign' => data_get($mpipt, 'report.user.employee.esign'),
            'person_make_report' => data_get($mpipt, 'report.user.employee.name'),
            'person_make_report_desc' => data_get($mpipt, 'report.user.employee.desc'),
        ]);
    }

    public function publish(Mpipt $mpipt)
    {
        $this->authorize('create', Mpipt::class);
        $specifications = DB::table('specifications')->select('id', 'name')->get();
        $jobrequests = DB::table('job_requests')->select('id', 'code')->orderBy('id', 'desc')->get();
        return view('layouts.inspection.ndt.mpipt.publish', [
            'page_name' => $this->page_name(0, $this->page_name) . ' (Publish)',
            'mpipt' => $mpipt,
            'jobrequests' => $jobrequests,
            'specifications' => $specifications
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Mpipt  $mpipt
     * @return \Illuminate\Http\Response
     */
    public function edit(Mpipt $mpipt)
    {
        $specifications = DB::table('specifications')->select('id', 'name')->get();
        $jobrequests = DB::table('job_requests')->select('id', 'code')->orderBy('id', 'desc')->get();
        return view('layouts.inspection.ndt.mpipt.edit', [
            'page_name' => $this->page_name(1, $this->page_name),
            'mpipt' => $mpipt,
            'jobrequests' => $jobrequests,
            'specifications' => $specifications
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Mpipt  $mpipt
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Mpipt $mpipt)
    {
        if ($request->publish == 'yes') {
            $job_request = JobRequest::find($request->lcr_1);
            $code = json_decode(json_encode(CustomController::getReportData($job_request)))->original->lastcode;
        } else {
            $code = $request->code;
        }

        $newone = [];
        foreach ($request['payments'] as $key => $value) {
            $newone[$key]['nmpr_49'] = $value['nmpr_49'];
            $path_crypt = '';
            if (isset($value['nmpr_50']) && $value['nmpr_50'] != NULL) {
                $path_crypt = Crypt::encryptString($value['nmpr_50']->getClientOriginalName());
                $store = $value['nmpr_50']->storeAs(
                    'public/camera/inspection/ndt/mpipts',
                    $path_crypt
                );
                $newone[$key]['nmpr_50'] = $path_crypt;
            } else {
                $newone[$key]['nmpr_50'] = $value['lcr_140'];
            }
        }

        $data = [
            'job_request_id' => $request->lcr_1,
            'nmpr_2' => $request->nmpr_2,
            'code' => $code,
            'nmpr_6' => $request->nmpr_6,
            'nmpr_7' => $request->nmpr_7,
            'nmpr_8' => $request->nmpr_8,
            'nmpr_10' => $request->nmpr_10,
            'acceptance' => $request->nmpr_11,
            'nmpr_12' => $request->nmpr_12,
            'nmpr_13' => $request->nmpr_13,
            'desc' => $request->nmpr_47,
            'nmpr_28' => $request->nmpr_48,
            'nmpr_29' => json_encode($newone),
            'nmpr_30' => $request->nmpr_51,
            'nmpr_800' => $request->nmpr_800,
            'nmpr_900' => $request->nmpr_900,
            'sync' => 0,
//            'temperature' => $request->temperature
        ];

        $user_approved = NULL;

        if ($mpipt->report->user_id_approved != NULL) {
            $update = $mpipt->create($data);
            $report_id = $update->id;
        } else {
            $update = $mpipt->update($data);
            $report_id = $mpipt->id;
            $user_approved = $mpipt->report->user_id_approved;
        }

        if ($update) {
            $user = Auth::id();
            if ($request->publish == 'yes') {
                $user = NULL;
                $last = InspectionReport::where('job_request_id', $request->lcr_1)->orderBy('code', 'DESC')->where('code', 'not LIKE', "%Duplicated")->first();
            }

            $this->persistInspectionReportState($mpipt, [
                'code' => $code,
                'status' => 1,
                'publish' => $request->publish == 'yes' ? 1 : $mpipt->report->publish,
                'user_id_approved' => $user_approved,
                'reportable_id' => $report_id,
                'user_id_edit' => $user,
            ]);

            return response()->json([
                'success' => $this->action_message(1, $this->page_name)
            ]);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Mpipt  $mpipt
     * @return \Illuminate\Http\Response
     */
    public function destroy(Mpipt $mpipt)
    {
        $remove = $this->check_edited_reports_for_delete($mpipt);

        if ($remove) {
            $mpipt->report->delete();
            $pdf = 'inspection/ndt/mpipt/' . $mpipt->job_request->code . '/' . $mpipt->code . '.pdf';
            $snap = 'images/inspection/ndt/mpipt/' . $mpipt->job_request->code . '/' . $mpipt->code;
            $remove_snap_shots_pdf = $this->remove_snap_shots_pdf($pdf, $snap);
            return response()->json([
                'success' => $remove_snap_shots_pdf . $this->action_message(2, $this->page_name)
            ]);
        }
    }
}
