<?php

namespace App\Http\Controllers\Dashboard\Organization;

use App\Http\Controllers\Controller;
use App\Models\Inspection\InspectionReport;
use App\Models\User;
use App\Models\WorkFlow\JobRequest;
use Carbon\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;

class StaffPerformanceController extends Controller
{
    public function index()
    {
        $user = Auth::user();
        abort_unless($user && (bool) $user->isSuperAdmin(), 403);

        $windowOptions = [
            '7d' => ['label' => '7 Days', 'seconds' => 604800],
            '30d' => ['label' => '30 Days', 'seconds' => 2592000],
            '90d' => ['label' => '90 Days', 'seconds' => 7776000],
            '180d' => ['label' => '180 Days', 'seconds' => 15552000],
        ];

        $selectedWindow = (string) request('window', '30d');
        if (!array_key_exists($selectedWindow, $windowOptions)) {
            $selectedWindow = '30d';
        }

        $selectedUserId = max(0, (int) request('user_id', 0));
        $selectedSection = strtolower(trim((string) request('section', 'all')));
        $sectionOptions = $this->inspectionSectionOptions();
        if ($selectedSection !== 'all' && !$sectionOptions->contains(fn (array $row) => $row['key'] === $selectedSection)) {
            $selectedSection = 'all';
        }

        $windowStartedAt = now()->subSeconds((int) ($windowOptions[$selectedWindow]['seconds'] ?? 2592000));
        $windowEndedAt = now();

        $inspectionBaseQuery = InspectionReport::query()
            ->whereNotNull('user_id')
            ->where('created_at', '>=', $windowStartedAt)
            ->where('code', 'not like', '%Duplicated%')
            ->whereNotNull('reportable_type');

        if ($selectedUserId > 0) {
            $inspectionBaseQuery->where('user_id', $selectedUserId);
        }

        if ($selectedSection !== 'all') {
            $inspectionBaseQuery->where('reportable_type', 'like', 'App\\Models\\Inspection\\'.ucfirst($selectedSection).'\\%');
        }

        $jcfBaseQuery = JobRequest::query()
            ->whereNotNull('user_id')
            ->where('created_at', '>=', $windowStartedAt);

        if ($selectedUserId > 0) {
            $jcfBaseQuery->where('user_id', $selectedUserId);
        }

        $reportCount = (int) (clone $inspectionBaseQuery)->count();
        $jcfCount = (int) (clone $jcfBaseQuery)->count();
        $activeInspectionEmployees = (int) (clone $inspectionBaseQuery)->distinct('user_id')->count('user_id');
        $activeJcfEmployees = (int) (clone $jcfBaseQuery)->distinct('user_id')->count('user_id');

        $sectionRows = (clone $inspectionBaseQuery)
            ->selectRaw('reportable_type, COUNT(*) as total')
            ->groupBy('reportable_type')
            ->get()
            ->reduce(function (array $carry, InspectionReport $row) {
                $section = $this->resolveInspectionSectionMeta((string) $row->reportable_type);
                if (!isset($carry[$section['key']])) {
                    $carry[$section['key']] = [
                        'key' => $section['key'],
                        'label' => $section['label'],
                        'count' => 0,
                    ];
                }
                $carry[$section['key']]['count'] += (int) ($row->total ?? 0);
                return $carry;
            }, []);

        $sectionRows = collect($sectionRows)->sortByDesc('count')->values();

        $typeRows = (clone $inspectionBaseQuery)
            ->selectRaw('reportable_type, COUNT(*) as total')
            ->groupBy('reportable_type')
            ->orderByDesc('total')
            ->limit(10)
            ->get()
            ->map(function ($row) {
                return [
                    'type' => $this->resolveInspectionTypeLabel((string) $row->reportable_type),
                    'section' => $this->resolveInspectionSectionMeta((string) $row->reportable_type)['label'],
                    'count' => (int) ($row->total ?? 0),
                ];
            })
            ->values();

        $jcfSubjectRows = (clone $jcfBaseQuery)
            ->selectRaw("COALESCE(NULLIF(subject, ''), NULLIF(job_requierd_details, ''), 'Unspecified') as subject_label, COUNT(*) as total")
            ->groupBy('subject_label')
            ->orderByDesc('total')
            ->limit(10)
            ->get()
            ->map(function ($row) {
                return [
                    'subject' => (string) ($row->subject_label ?? 'Unspecified'),
                    'count' => (int) ($row->total ?? 0),
                ];
            })
            ->values();

        $jcfByUser = (clone $jcfBaseQuery)
            ->selectRaw('user_id, COUNT(*) as total, MAX(created_at) as last_created_at')
            ->groupBy('user_id')
            ->get()
            ->keyBy('user_id');

        $reportsByUser = (clone $inspectionBaseQuery)
            ->selectRaw('user_id, COUNT(*) as total, MAX(created_at) as last_created_at')
            ->groupBy('user_id')
            ->get()
            ->keyBy('user_id');

        $employeeBreakdowns = (clone $inspectionBaseQuery)
            ->selectRaw('user_id, reportable_type, COUNT(*) as total')
            ->groupBy('user_id', 'reportable_type')
            ->get()
            ->groupBy('user_id')
            ->map(function (Collection $rows) {
                $sectionCounts = [];
                $typeCounts = [];
                foreach ($rows as $row) {
                    $section = $this->resolveInspectionSectionMeta((string) $row->reportable_type)['label'];
                    $type = $this->resolveInspectionTypeLabel((string) $row->reportable_type);
                    $sectionCounts[$section] = ($sectionCounts[$section] ?? 0) + (int) ($row->total ?? 0);
                    $typeCounts[$type] = ($typeCounts[$type] ?? 0) + (int) ($row->total ?? 0);
                }
                arsort($sectionCounts);
                arsort($typeCounts);
                return [
                    'sections' => $sectionCounts,
                    'types' => $typeCounts,
                ];
            });

        $activityUserIds = collect($jcfByUser->keys())
            ->merge($reportsByUser->keys())
            ->filter()
            ->unique()
            ->values();

        $creators = User::query()
            ->whereIn('id', $activityUserIds)
            ->where('is_active', 1)
            ->with('employee:id,name')
            ->get(['id', 'employee_id'])
            ->map(function (User $candidate) {
                return [
                    'id' => (int) $candidate->id,
                    'name' => optional($candidate->employee)->name ?: ('User #'.$candidate->id),
                ];
            })
            ->sortBy('name')
            ->values();

        $creatorMap = $creators->keyBy('id');

        $employeeRows = $activityUserIds
            ->map(function ($userId) use ($jcfByUser, $reportsByUser, $creatorMap, $employeeBreakdowns) {
                $userId = (int) $userId;
                $jcf = $jcfByUser->get($userId);
                $report = $reportsByUser->get($userId);
                $breakdown = $employeeBreakdowns->get($userId, ['sections' => [], 'types' => []]);
                $latestJcfAt = !empty($jcf?->last_created_at) ? Carbon::parse($jcf->last_created_at) : null;
                $latestReportAt = !empty($report?->last_created_at) ? Carbon::parse($report->last_created_at) : null;
                $lastActivityAt = $latestJcfAt && $latestReportAt
                    ? ($latestJcfAt->greaterThan($latestReportAt) ? $latestJcfAt : $latestReportAt)
                    : ($latestJcfAt ?: $latestReportAt);

                return [
                    'user_id' => $userId,
                    'name' => $creatorMap->get($userId)['name'] ?? ('User #'.$userId),
                    'jcf_count' => (int) ($jcf->total ?? 0),
                    'report_count' => (int) ($report->total ?? 0),
                    'total_activity' => (int) ($jcf->total ?? 0) + (int) ($report->total ?? 0),
                    'sections_count' => count($breakdown['sections']),
                    'top_section' => array_key_first($breakdown['sections']) ?: '-',
                    'top_type' => array_key_first($breakdown['types']) ?: '-',
                    'last_activity_at' => $lastActivityAt,
                ];
            })
            ->sortByDesc('total_activity')
            ->take(20)
            ->values();

        $topEmployee = $employeeRows->first();
        $topSection = $sectionRows->first();
        $topJcfSubject = $jcfSubjectRows->first();

        return view('layouts.organization.staff-performance.index', [
            'page_name' => 'Staff Performance',
            'window_options' => $windowOptions,
            'selected_window' => $selectedWindow,
            'selected_user_id' => $selectedUserId,
            'selected_section' => $selectedSection,
            'window_started_at' => $windowStartedAt,
            'window_ends_at' => $windowEndedAt,
            'creators' => $creators,
            'section_options' => $sectionOptions,
            'jcf_count' => $jcfCount,
            'report_count' => $reportCount,
            'active_jcf_employees' => $activeJcfEmployees,
            'active_inspection_employees' => $activeInspectionEmployees,
            'top_employee' => $topEmployee,
            'top_section' => $topSection,
            'top_jcf_subject' => $topJcfSubject,
            'employee_rows' => $employeeRows,
            'section_rows' => $sectionRows,
            'type_rows' => $typeRows,
            'jcf_subject_rows' => $jcfSubjectRows,
        ]);
    }

    private function inspectionSectionOptions(): Collection
    {
        return InspectionReport::query()
            ->whereNotNull('reportable_type')
            ->distinct()
            ->pluck('reportable_type')
            ->map(function ($type) {
                return $this->resolveInspectionSectionMeta((string) $type);
            })
            ->unique('key')
            ->sortBy('label')
            ->values();
    }

    private function resolveInspectionSectionMeta(string $reportableType): array
    {
        $cleanType = str_replace('App\\Models\\Inspection\\', '', $reportableType);
        $segments = array_values(array_filter(explode('\\', $cleanType)));
        $sectionKey = strtolower((string) ($segments[0] ?? 'inspection'));
        $sectionLabel = trim((string) preg_replace('/(?<!^)[A-Z]/', ' $0', $segments[0] ?? 'Inspection'));

        return [
            'key' => $sectionKey !== '' ? $sectionKey : 'inspection',
            'label' => $sectionLabel !== '' ? $sectionLabel : 'Inspection',
        ];
    }

    private function resolveInspectionTypeLabel(string $reportableType): string
    {
        $cleanType = str_replace('App\\Models\\Inspection\\', '', $reportableType);
        $segments = array_values(array_filter(explode('\\', $cleanType)));
        $className = end($segments) ?: 'Report';

        return trim((string) preg_replace('/(?<!^)[A-Z]/', ' $0', $className));
    }
}
