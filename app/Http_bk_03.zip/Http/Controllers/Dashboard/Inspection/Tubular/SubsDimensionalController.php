<?php

namespace App\Http\Controllers\Dashboard\Inspection\Tubular;

use App\Http\Controllers\Controller;
use App\Http\Controllers\CustomController;
use App\Models\GeneralInfo\Specification;
use App\Models\Inspection\Tubular\SubsDimensional;
use App\Models\Persons\Client;
use App\Models\Persons\Supplier;
use App\Models\WorkFlow\JobRequest;
use Illuminate\Http\Request;

// Other
use DB, DataTables, Storage, Auth, Crypt;
use function Symfony\Component\String\length;

class SubsDimensionalController extends Controller
{
    public $page_name = 'Subs Dimensional Inspection Report';
    public function __construct()
    {
        $this->middleware('auth');
        $this->authorizeResource(SubsDimensional::class, 'subsDimensional');
    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $reports = SubsDimensional::count();
        return view('layouts.inspection.tubular.subsDimensional.index', ['page_name' => $this->page_name('All', $this->page_name), 'reports' => $reports]);
    }

    public function getDataForDataTable(Request $request)
    {
        $data = SubsDimensional::query()
            ->has('report')
            ->withAggregate('job_request','code')
            ->orderBy('job_request_code', 'Desc');

        $this->applyInspectionApprovalPresetFilter($data, request('smart_preset'));

        return Datatables::eloquent($data)

            ->addColumn('approval_status', function ($row) {
                return $this->inspectionApprovalStatusValueByRow($row);
            })
            ->addColumn('client', function ($row) {
                $report_code = "";
                if ($row->job_request->client) {
                    if (Auth::user()->can('view', Client::find($row->job_request->client->id))) {
                        $report_code .= "<a href=" . route('client.show', $row->job_request->client->id) . ">";
                    }

                    $report_code .= $row->job_request->client->name;

                    if (Auth::user()->can('view', Client::find($row->job_request->client->id))) {
                        $report_code .= "</a>";
                    }
                } else {
                    if (Auth::user()->can('view', Supplier::find($row->job_request->supplier->id))) {
                        $report_code .= "<a href=" . route('supplier.show', $row->job_request->supplier->id) . ">";
                    }

                    $report_code .= $row->job_request->supplier->name;

                    if (Auth::user()->can('view', Supplier::find($row->job_request->supplier->id))) {
                        $report_code .= "</a>";
                    }

                }
                return $report_code;
            })
            ->addColumn('code', function ($row) {
                $report_code = "";
                if (Auth::user()->can('view', SubsDimensional::find($row->id)) ) {
                    $report_code .= "<a href=" . route('subsDimensional.show', $row->id) . ">";
                }

                $report_code .= $row->job_request->code . '/' . $row->code;

                if (Auth::user()->can('view', SubsDimensional::find($row->id)) ) {
                    $report_code .= "</a>";
                }
                return $report_code;
            })
            ->addColumn('deploc', function ($row) {

                return $row->job_request->deploc;
            })
            ->addColumn('client_department', function ($row) {

                return $row->job_request->clientDepartment ? $row->job_request->clientDepartment->name : '';
            })
            ->addColumn('action', function ($row) {
                $btn = "";
                if (Auth::user()->can('create', SubsDimensional::class) ) {
                    $btn .= '<button data-id="' . $row->report->id . '" class="btn btn-primary mr-1 duplicate"><i class="la la-clone"></i></button>';
                }

                if ($row->report->publish != NULL) {
                    if (Storage::disk('public')->exists('pdf/inspection/tubular/subsdimensional/' . $row->job_request->code . '/' . $row->code . '.pdf')) {
                        $btn .= '<a class="btn btn-secondary mr-1" target="_blank" href="' . Storage::url('pdf/inspection/tubular/subsdimensional/' . $row->job_request->code . '/' . $row->code . '.pdf') . '">Download PDF</a>';
                    } else {
                        $btn .= '<a class="btn btn-dark mr-1" href="' . route('subsDimensional.show', $row->id) . '">Open Report</a>';
                    }

                    if (Auth::user()->can('update', SubsDimensional::find($row->id))) {
                        $btn .= '<a href="' . route('subsDimensional.edit', $row->id) . '" class="btn btn-icon btn-info mr-1"><i class="la la-pencil"></i></a>';
                    }
                } else {
                    if (Auth::user()->can('create', SubsDimensional::find($row->id))) {
                        $btn .= '<a href="' . route('publish.subsDimensional', $row->id) . '" class="btn btn-icon btn-info mr-1">Publish</a>';
                    }
                }


                if (Auth::user()->can('delete', SubsDimensional::find($row->id))) {
                    $btn .= '<button type="button" data-id="' . $row->id . '" class="btn btn-icon btn-danger delete mr-1"><i class="la la-trash"></i></button>';
                }
                return $btn;
            })
            ->filterColumn('code', function ($query, $keyword) {
                $query->whereRaw("code like ?", ["%{$keyword}%"])
                    ->orWhereHas('job_request', function ($row) use (&$keyword) {
                        $row->where("code", "like", ["%{$keyword}%"]);
                    });
            })
            ->filterColumn('deploc', function ($query, $keyword) {
                $query->whereHas('job_request', function ($row) use (&$keyword) {
                    // $row->whereHas('client', function($row1) use (&$keyword){
                    $row->where("deploc", "like", ["%{$keyword}%"]);
                    // });
                });
            })
            ->filterColumn('client_department', function ($query, $keyword) {
                $query->whereHas('job_request', function ($row) use (&$keyword) {
                    $row->whereHas('clientDepartment', function ($row1) use (&$keyword) {
                        $row1->where("name", "like", ["%{$keyword}%"]);
                    });
                });
            })
            ->filterColumn('client', function ($query, $keyword) {
                $query->whereHas('job_request', function ($row) use (&$keyword) {
                    $row->whereHas('client', function ($row1) use (&$keyword) {
                        $row1->where("name", "like", ["%{$keyword}%"]);
                    });
                });
            })
            ->filterColumn('action', function ($query, $keyword) {
                $codes = $this->getUploadedCodes('/tubular/subsdimensional', true);
                switch ($keyword) {
                    case 'publish':
                        $query->whereHas('report', function ($q) {
                            $q->where('publish', null);
                        });
                        break;
                    case 'download':
                        $query->whereHas('job_request', function ($q) use ($codes) {
                            $q->whereIn(DB::raw("CONCAT(job_requests.code, '/', subs_dimensionals.code)"), $codes);
                        });
                        break;
                    case 'upload':
                        $query->whereHas('report', function ($q) {
                            $q->whereNot('publish', null);
                        });
                        $query->whereHas('job_request', function ($q) use ($codes) {
                            $q->whereNotIn(DB::raw("CONCAT(job_requests.code, '/', subs_dimensionals.code)"), $codes);
                        });

                        break;
                }
            })
			->filter(function ($query) use ($request) {
				$this->applyInspectionGlobalSearch($query, $request->input('search.value'));
			})
            ->rawColumns(['code', 'client', 'action'])
            ->make('true');
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $jobrequests = DB::table('job_requests')->select('id','code')->orderBy('id', 'desc')->get();
        $specifications = Specification::getTubularSpecifications();

        return view('layouts.inspection.tubular.subsDimensional.add', [
            'page_name' => $this->page_name(0, $this->page_name),
            'jobrequests' => $jobrequests,
            'specificationOptions' => $specifications,
            'inspectionMethods' => SubsDimensional::$INSPECTION_METHOD,
            'equipments' => SubsDimensional::$EQUIPMENTS,
            'pipeTypeOptions' => SubsDimensional::$PIPE_TYPE_OPTIONS,
            'pipeTypeStandards' => SubsDimensional::$PIPE_TYPES_STANDARDS,
            'inspection_data_template' => [
                array_combine(array_map(function ($i) {
                    return "input_$i";
                }, range(1, 37)), array_fill(0, 37, ''))
            ],
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data  = $request->all();
        $created = SubsDimensional::create($data);
        $code = $data['code'];
        if ($created) {
            $created->report()->create([
                'job_request_id' => $request->job_request_id,
                'code' => $code,
                'status' => 1,
                'publish' => 1,
                'sync' => 1,
                'user_id' => Auth::id(),
            ]);
            return response()->redirectToRoute('subsDimensional.index');
        }
        return response()->json([$data]);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Inspection\Tubular\SubsDimensional subsDimensional
     * @return \Illuminate\Http\Response
     */
    public function show(SubsDimensional $subsDimensional)
    {

        $have_edit = $this->check_if_report_edit(SubsDimensional::class, $subsDimensional);
        $subsDimensional->report = $have_edit->default;
        $specifications = Specification::getTubularSpecifications()->pluck('name', 'code')->toArray();
        $footerData = [
            'formNo' => 'RS-RF-F18',
            'issueNo' => '04',
            'issueDate' => '1-Mar-2024',
            'revisionNo'=> '00',
            'revisionDate' => '1-Mar-2024',
            'pageNo' => '1 of 1',
        ];

        /** add empty rows to inspection data array & be sure to allow only 10 row on the inspection data*/
        $oldArray = $subsDimensional->inspection_data ? $subsDimensional->inspection_data : [];
        $newArray = (count($oldArray) > 10) ? array_slice($oldArray, 0, 10) : $oldArray;
        for ($i = count($newArray); $i < 10; $i++) {
            $newArray[] = array_combine(array_map(function ($i) {
                return "input_$i";
            }, range(1, 37)), array_fill(0, 37, ''));
        }
        $subsDimensional->inspection_data = $newArray;
        /** **************************************** */

        return view('layouts.inspection.tubular.subsDimensional.show', [
            'page_name' => $this->page_name,
            'page_text' => '',
            'model' => $subsDimensional,
            'code' => $subsDimensional->job_request->code . '/' . $subsDimensional->code,
            'report_created_at' => $subsDimensional->created_at->format('d/m/Y'),
            'specificationOptions' => $specifications,
            'inspectionMethods' => SubsDimensional::$INSPECTION_METHOD,
            'equipments' => SubsDimensional::$EQUIPMENTS,
            'pipeTypeOptions' => SubsDimensional::$PIPE_TYPE_OPTIONS,
            'pipeTypeStandards' => SubsDimensional::$PIPE_TYPES_STANDARDS,
            'footerData'=> $footerData,
            'pdfurl' => 'storage/pdf/inspection/tubular/subsdimensional/' . $subsDimensional->job_request->code . '/' . $subsDimensional->code . '.pdf',
            'hasPermission' => Auth::user()->hasPermission('subsdimensional', 'approve'),
            'imageurl' => $subsDimensional->job_request->code . '/' . $subsDimensional->code,
            'folder' => 'pdf/inspection/tubular/subsdimensional',
            'iso_number' => 'Form # RSE-RF-07 - ISSUE 07 / Jul 2023',
            'page_number' => '1 of 1',
            'have_edit' => $have_edit->edited,
            'user_id_approved' => $have_edit->default->user_id_approved,
            'for_approve_url' => $have_edit->default->id,
            'esign' => $have_edit->default->user->employee->esign,
            'person_make_report' => $have_edit->default->user->employee->name,
            'person_make_report_desc' => $have_edit->default->user->employee->desc,
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Inspection\Tubular\SubsDimensional $subsDimensional
     * @return \Illuminate\Http\Response
     */
    public function edit(SubsDimensional $subsDimensional)
    {
        $jobrequests = DB::table('job_requests')->select('id', 'code')->orderBy('id', 'desc')->get();
        $specifications = Specification::getTubularSpecifications();
        return view('layouts.inspection.tubular.subsDimensional.edit', [
            'model' => $subsDimensional,
            'page_name' => $this->page_name(1, $this->page_name),
            'jobrequests' => $jobrequests,
            'specificationOptions' => $specifications,
            'inspectionMethods' => SubsDimensional::$INSPECTION_METHOD,
            'equipments' => SubsDimensional::$EQUIPMENTS,
            'pipeTypeOptions' => SubsDimensional::$PIPE_TYPE_OPTIONS,
            'pipeTypeStandards' => SubsDimensional::$PIPE_TYPES_STANDARDS,
            'inspection_data_template' => [
                array_combine(array_map(function ($i) {
                    return "input_$i";
                }, range(1, 37)), array_fill(0, 37, ''))
            ],        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \App\Models\Inspection\Tubular\SubsDimensional $subsDimensional
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, SubsDimensional $subsDimensional)
    {
        $data = $request->all();
        if ($subsDimensional->report->user_id_approved != NULL) {
            $data['job_request_id'] = $subsDimensional->job_request_id;
            $createdCert = $subsDimensional->create($data);
            $reportUpdateData = [
                'reportable_id' => $createdCert->id,
                'user_id_edit' => Auth::id(),
                'user_id_approved' => null,
            ];
        } else {
            $subsDimensional->update($data);
            $reportUpdateData = [
                'user_id_edit' => Auth::id(),
            ];
        }

        $subsDimensional->report()->update($reportUpdateData);
        return response()->redirectToRoute('subsDimensional.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Inspection\Tubular\SubsDimensional $subsDimensional
     * @return \Illuminate\Http\Response
     */
    public function destroy(SubsDimensional $subsDimensional)
    {
        $remove = $this->check_edited_reports_for_delete($subsDimensional);

        if ($remove) {
            $subsDimensional->report->delete();
            $pdf = 'inspection/tubular/subsdimensional/' . $subsDimensional->job_request->code . '/' . $subsDimensional->code . '.pdf';
            $snap = 'images/inspection/tubular/subsdimensional/' . $subsDimensional->job_request->code . '/' . $subsDimensional->code;
            $remove_snap_shots_pdf = $this->remove_snap_shots_pdf($pdf, $snap);
            return response()->json([
                'success' => $remove_snap_shots_pdf . $this->action_message(2, $this->page_name)
            ]);
        }
    }

    public function publish(SubsDimensional $subsDimensional)
    {
        $jobrequests = DB::table('job_requests')->select('id','code')->orderBy('id', 'desc')->get();
        $specifications = Specification::getTubularSpecifications();
        return view('layouts.inspection.tubular.subsDimensional.publish', [
            'page_name' => $this->page_name(0, $this->page_name).' (Publish)',
            'model' => $subsDimensional,
            'jobrequests' => $jobrequests,
            'specificationOptions' => $specifications,
            'inspectionMethods' => SubsDimensional::$INSPECTION_METHOD,
            'equipments' => SubsDimensional::$EQUIPMENTS,
            'pipeTypeOptions' => SubsDimensional::$PIPE_TYPE_OPTIONS,
            'pipeTypeStandards' => SubsDimensional::$PIPE_TYPES_STANDARDS
        ]);
    }

    public function publishSubmit(Request $request, SubsDimensional $subsDimensional)
    {
        $data = $request->all();
        $job_request = JobRequest::find($request->job_request_id);
        $code = json_decode(json_encode(CustomController::getReportData($job_request)))->original->lastcode;
        $data['code'] = $code;
        $subsDimensional->update($data);
        $subsDimensional->report()->update([
            'code' => $code,
            'status' => 1,
            'publish' => 1,
            'user_id_approved' => null,
            'user_id_edit' => null,
        ]);
        return response()->redirectToRoute('subsDimensional.index');
    }
}


