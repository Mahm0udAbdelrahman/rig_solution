<?php

namespace App\Http\Controllers\Auth\Customer;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

// use App\Models\Organization\Employee;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::CUSTOMER;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
//        $this->middleware('guest:customer')->except('logout');
    }

    public function showCustomerLogin()
    {
      return view('auth.customer.login');
    }

    protected function attemptLogin(Request $request)
    {
        $credentials = $request->only('code', 'password');
        if (Auth::guard('customer')->attempt($credentials)) {
           $request->session()->regenerate();
           return redirect()->intended('customer');
        } else {
            $credentials2 = ['email' => $credentials['code'], 'password' => $credentials['password']];
            if (Auth::guard('clientDepartments')->attempt($credentials2)) {
                $request->session()->regenerate();
                return redirect()->intended('department');
            }

        }

    }

    public function logout(Request $request)
    {
        Auth::guard('customer')->logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect()->route('customer.login');
    }

    public function username()
    {
        return 'code';
    }

}
